package com.example.examen.clicker9000;

import android.os.AsyncTask;

class MiTareaAsincronaDialog extends AsyncTask<Void, Integer, Boolean> {

    @Override
    protected Boolean doInBackground(Void... params) {

        while(true) {

            try {
                Thread.sleep(250);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Clicker.score=Clicker.score+Clicker.dps;
            publishProgress(Clicker.score);

            if(isCancelled())
                break;
        }

        return true;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {

        Clicker.txtScore.setText("Score: "+Clicker.score);
    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(Boolean result) {
    }

    @Override
    protected void onCancelled() {
    }
}