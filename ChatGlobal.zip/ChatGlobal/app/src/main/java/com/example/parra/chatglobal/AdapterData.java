package com.example.parra.chatglobal;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class AdapterData extends RecyclerView.Adapter<AdapterData.ViewHolderData> {

    public AdapterData() {
    }

    @NonNull
    @Override
    public ViewHolderData onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_list,viewGroup,false);
        return new ViewHolderData(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderData viewHolderData, int i) {
        viewHolderData.AsignarDatos(ChatCR.chats.get(i));
    }

    @Override
    public int getItemCount() {
        return ChatCR.chats.size();
    }

    //------------------------------------------------------------------------------------
    class ViewHolderData extends RecyclerView.ViewHolder{
        private final Context context;
        TextView nombre, mensaje;

        ViewHolderData(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();

            mensaje=itemView.findViewById(R.id.mensaje);
            nombre=itemView.findViewById(R.id.nombre);
        }

        void AsignarDatos(Chat chat){
            mensaje.setText(chat.getMensaje());
            nombre.setText(chat.getNombre()+":");
        }

    }
}
