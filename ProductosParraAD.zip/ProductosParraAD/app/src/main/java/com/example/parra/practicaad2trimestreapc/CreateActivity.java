package com.example.parra.practicaad2trimestreapc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import Modelo.IProductoDao;
import Modelo.ProductoDaoImpl;
import Modelo.Productos;

public class CreateActivity extends AppCompatActivity {

    IProductoDao productoDao;
    TextView codigo, nombre, fecha, url, descripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        //objeto para manipular el dao
        productoDao = new ProductoDaoImpl();
        codigo = (TextView) findViewById(R.id.codigo);
        nombre = (TextView) findViewById(R.id.nombre);
        fecha = (TextView) findViewById(R.id.fecha);
        url = (TextView) findViewById(R.id.url);
        descripcion = (TextView) findViewById(R.id.descripcio);
    }

    public void BackOnClick(View v){
        volver(v);
    }

    public void OkayOnClick(View v){
        System.out.println("preparando creación");
        productoDao.crearProducto(new Productos(Integer.parseInt(codigo.getText().toString()), nombre.getText()+"", fecha.getText()+"", url.getText()+"", descripcion.getText()+""));
        volver(v);
    }

    private void volver(View v){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}
