package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Handler;
import android.view.View;

import com.google.firebase.database.DatabaseReference;

public class ParraAsyncTask extends AsyncTask<Void, Integer, Boolean> {

    //region VARIABLES
    private DatabaseReference bd = LoginActivity.dbUsers.child(LoginActivity.user.getName());

    private int contGuardado;

    private Handler hadler;

    private Runnable runneableReinicioCofre, runneableObtenerOro, runneableBajaMundo, runneableSubeMundo, runneableAvisoMove, runneableReinicioAvisos;

    boolean seguir, guardado;

    //endregion

    ParraAsyncTask() {
        InitComponents();
    }

    //region MÉTODOS

    /** Inicializa los componentes */
    private void InitComponents(){
        hadler = new Handler();
        contGuardado=0;
        seguir=true;
        guardado = false;
        //region RUNNEABLES

        runneableReinicioCofre = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //animaciones del cofre y su vida para que aparezcan otra vez
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(Clicker.txtVida, "translationY", 500, 0);
                transAnimatio1.setDuration(100).start();
                ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(Clicker.ivChest, "translationY", -500, 0);
                transAnimatio2.setDuration(100).start();
                //vuelve activo el cofre de nuevo para que se pueda activar su onClick
                Clicker.ivChest.setEnabled(true);
                //vuelve visibles el cofre y su vida
                Clicker.ivChest.setVisibility(View.VISIBLE);
                Clicker.txtVida.setVisibility(View.VISIBLE);
                //reinicia la explosión del cofre secundario
                Clicker.explosionField.clear();
                //escribe la vida del cofre actual
                Clicker.txtVida.setText(Clicker.vidaChest + "");
            }
        };

        runneableObtenerOro = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //controla si la capacidad no va a superarse
                if ((LoginActivity.user.getScore() + Clicker.oro) <= LoginActivity.user.getCapacity()) {
                    //añade el oro obtenido y lo escribe en el campo correspondiente
                    LoginActivity.user.setScore(LoginActivity.user.getScore() + Clicker.oro);
                    Clicker.txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                } else {
                    //añade el oro máximo obtenible y lo escribe en el campo correspondiente
                    LoginActivity.user.setScore(LoginActivity.user.getCapacity());
                    Clicker.txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                }
                //reinicia la imagen del cofre principal
                Clicker.ivChest.setImageResource(R.drawable.chest);
                //esconde la imagen del cofre
                Clicker.ivChest.setVisibility(View.GONE);
                //anima el mundo para que rote
                Clicker.ivmundo.animate().rotation(Clicker.ivmundo.getRotation()+60).setDuration(200);
            }
        };

        runneableBajaMundo = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //animación del mundo para que baje por la bajada del cofre
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(Clicker.ivmundo, "translationY", 0, 30);
                transAnimatio1.setDuration(50).start();
            }
        };

        runneableSubeMundo = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //animación de el mundo para que suba a su estado natural
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(Clicker.ivmundo, "translationY", 30, 0);
                transAnimatio1.setDuration(50).start();
            }
        };

        runneableAvisoMove = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //animación de el aviso para que sea más visual
                ObjectAnimator transAnimation = ObjectAnimator.ofFloat(Clicker.txtAviso, "translationX", 0, -1000);
                transAnimation.setDuration(500).start();
            }
        };

        runneableReinicioAvisos = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //vacía el campo de avisos
                Clicker.txtAviso.setText("");
            }
        };

        //endregion
    }

    //endregion

    //region MÉTODOS ASYNCTASK

    /** Se ejecuta al iniciar el AsyncTask */
    @Override
    protected Boolean doInBackground(Void... params) {
        //controla que mientras no se interrumpa siga el AsyncTask
        while(seguir){
            //controla que no de un error al ejecutar el siguiente código
            try {
                //para el programa el tiempo que esté establecido en la velocidad del usuario
                Thread.sleep(LoginActivity.user.getSpeed());
            }catch (InterruptedException e) {
                e.printStackTrace();
            }
            //suma el tiempo que ha pasado al tiempo que llevaba
            contGuardado+=LoginActivity.user.getSpeed();
            //ejecuta el método onProgressUpdate()
            publishProgress();
        }
        //ejecuta el método onProgressUpdate() para finalizar el AsyncTask
        publishProgress();
        return true;
    }

    /** Se llama desde doInBackground con la función publishProgress() */
    @SuppressLint("SetTextI18n")
    @Override
    protected void onProgressUpdate(Integer... values) {
        // Controla que si el tiempo transcurrido es mayor o igual a 10 seg. y guardado está activado
        if(contGuardado>=10000 && guardado){
            //reinicia el tiempo de guardado
            contGuardado=0;
            //Inicializa una varible con el tiempo actual
            ParraDate date = new ParraDate();
            //controla si las fechas tienen algún campo diferente
            if(date.getYear()!=LoginActivity.user.getDate().getYear() || date.getDay()!=LoginActivity.user.getDate().getDay() || date.getHour()!=LoginActivity.user.getDate().getHour() || date.getMinute()!=LoginActivity.user.getDate().getMinute()){
                //guarda los datos de la fecha actual en la Base de Datos
                bd.child("date").setValue(date);
                //actualiza la nueva fecha en el usuario
                LoginActivity.user.getDate().setYear(date.getYear());
                LoginActivity.user.getDate().setDay(date.getDay());
                LoginActivity.user.getDate().setHour(date.getHour());
                LoginActivity.user.getDate().setMinute(date.getMinute());
            }
            //guarda los datos actuales del usuario en la Base de Datos
            bd.setValue(LoginActivity.user);
            //Controla que no haya nada escrito en el texto de avisos
            if(Clicker.txtAviso.getText().equals("")) {
                //según el idioma te pone el aviso de guardado en el correspondiente
                if (LoginActivity.Idioma.equals("Español"))
                    Clicker.txtAviso.setText(R.string.SavedSp);
                if (LoginActivity.Idioma.equals("English"))
                    Clicker.txtAviso.setText(R.string.SavedEn);
                //ejecuta los hilos terciarios que se ejecutarán en el tiempo especificado
                hadler.postDelayed(runneableAvisoMove, 1000);
                hadler.postDelayed(runneableReinicioAvisos, 1300);
                //animación para que el aviso destaque más
                ObjectAnimator transAnimation = ObjectAnimator.ofFloat(Clicker.txtAviso, "translationX", -1000, 0);
                transAnimation.setDuration(500).start();
            }
        }
        //controla si el usuario tiene alguna mejora de daño automático
        if(LoginActivity.user.getDamage()>0){
            //Resta vida al cofre según el daño actual del usuario
            Clicker.vidaChest=Clicker.vidaChest-LoginActivity.user.getDamage();
            //controla que la vida del cofre haya llegado a 0 o menos
            if (Clicker.vidaChest <= 0) {
                //inicializa la vida del cofre según la formula establecida
                Clicker.vidaChest = Math.round(LoginActivity.user.getCapacity()/10f);
                //la imagen del cofre secundaria explota con una animación con partículas
                Clicker.explosionField.explode(Clicker.ivChestExplote);
                Clicker.explosionField.expandExplosionBound(200,200);
                //ejecuta los hilos terciarios que se ejecutarán en los tiempos establecidos para hacer las animaciones correspondientes
                hadler.postDelayed(runneableSubeMundo,600);
                hadler.postDelayed(runneableBajaMundo,550);
                hadler.postDelayed(runneableReinicioCofre,500);
                hadler.postDelayed(runneableObtenerOro,300);
                //cambia la imagen del cofre principal a una más deteriorada como reflejo de que se ha abierto
                Clicker.ivChest.setImageResource(R.drawable.chestfinal);
                //la imagen del cofre pasa a estar desactivada para no poder quitarle vida al cofre mientras se ejecutan las animaciones
                Clicker.ivChest.setEnabled(false);
                //se vuelve no visible el compo que refleja la vida del cofre
                Clicker.txtVida.setVisibility(View.GONE);
                //se vuelve visible la moneda que refleja que vas a obtener oro con ese cofre
                Clicker.ivMoneda.setVisibility(View.VISIBLE);
                //animaciones para la moneda en x e y a la vez
                ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(Clicker.ivMoneda, "translationX", Math.round(Clicker.metrics.widthPixels/2f), 0);
                ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(Clicker.ivMoneda, "translationY", Math.round(Clicker.metrics.heightPixels/2f), 0);
                AnimatorSet animSetXY = new AnimatorSet();
                animSetXY.playTogether(transAnimationX, transAnimationY);
                animSetXY.setDuration(300).start();
            } else {
                //crea dos varibles aleatorias entre unos parámetros
                int x = (int) (Math.random() * 41) - 20;
                int y = 20 - Math.abs(x);

                //animación del cofre moviendose en x e y a la vez para reflejar que se le hace daño
                ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(Clicker.ivChest, "translationX", x, 0);
                ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(Clicker.ivChest, "translationY", y, 0);
                AnimatorSet animSetXY = new AnimatorSet();
                animSetXY.playTogether(transAnimationX, transAnimationY);
                animSetXY.setDuration(300).start();
            }
            //escribe la vida actual del cofre en su campo
            Clicker.txtVida.setText(Clicker.vidaChest + "");
        }

    }

    /** Se ejecuta antes de iniciar doInBackground() */
    @Override
    protected void onPreExecute() {

    }

    /** Se ejecuta después de iniciar doInBackground() */
    @Override
    protected void onPostExecute(Boolean result) {
    }

    /** Se ejecuta al cancelar el AsyncTask */
    @Override
    protected void onCancelled() {
    }

    //endregion
}