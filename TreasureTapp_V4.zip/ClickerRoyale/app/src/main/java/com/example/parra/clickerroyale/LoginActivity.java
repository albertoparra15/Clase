package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    //region VARIABLES

    private DisplayMetrics metrics;

    static String Idioma;

    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    static final DatabaseReference dbUsers = database.getReference("users");

    static User user;
    static User[] leaderboard;

    private EditText txtName, txtPassword;

    private TextView txtLogin, txtAviso, txtInfo, txtInfoName, txtInfoPassw;

    private Button btnRegister, btnLogin;

    private ImageView ivIdiomas, ivEspana, ivEngland;

    private RelativeLayout rellay1, rellay2;

    private Handler hadler;

    private Runnable runneable;

    private boolean cargando, idiomasActivo, registerAct;

    //endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        InitComponents();

        //ejecuta el hilo runneable 1 seg despues de crear la activity
        hadler.postDelayed(runneable,1000);

        //obtiene las medidas de la pantalla
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        //on click del boton ok del teclado al estar el TextView de la contraseña focuseado
        txtPassword.setOnKeyListener(new View.OnKeyListener(){
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event){
                if(keyCode == KeyEvent.KEYCODE_ENTER){
                    enter();
                }
                return true;
            }
        });
    }

    //region MÉTODOS

    /** Inicializa los componentes */
    private void InitComponents(){
        //Inicializa los objetos buscando su id en el layout
        rellay1 = findViewById(R.id.rellay1);
        rellay2 = findViewById(R.id.rellay2);
        txtName = findViewById(R.id.etName);
        txtPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnToRegister);
        btnLogin = findViewById(R.id.btnLogin);
        txtLogin = findViewById(R.id.txtLogin);
        txtAviso = findViewById(R.id.txtAvisoLogin);
        ivIdiomas = findViewById(R.id.ivIdiomas);
        ivEngland = findViewById(R.id.ivEngland);
        ivEspana = findViewById(R.id.ivEspana);
        txtInfo = findViewById(R.id.txtInfoIdiomas);
        txtInfoName = findViewById(R.id.txtInfoNameLogin);
        txtInfoPassw = findViewById(R.id.txtInfoPasswLogin);
        //Inicializaciones varias
        metrics = new DisplayMetrics();
        Idioma = getString(R.string.Sp);
        leaderboard=new User[5];
        hadler = new Handler();
        cargando = false;
        idiomasActivo = false;
        registerAct=false;
        runneable = new Runnable() {
            @Override
            public void run() {
                //hace visible los Layout, ya que al principio se encuentran en gone
                rellay1.setVisibility(View.VISIBLE);
                rellay2.setVisibility(View.VISIBLE);
                ivIdiomas.setVisibility(View.VISIBLE);
                //animación que hace más visible el botón de idiomas
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivIdiomas, "translationY", 1000, 0);
                transAnimatio1.setDuration(400).start();
            }
        };
    }

    /** Método que hace el registro y el login */
    private void enter(){
        //controla que no esté cargando la información de registro o logueo para que no se pueda ejecutar seguidamente
        if(!cargando) {
            //cambia el estado a cargando
            cargando = true;
            //controla si estás en la parte de Login o Registro
            if (registerAct)//acción del boton de registrar
                register();
            else//acción del boton Login
                login();
        }
    }

    /** Método que registra al usuario según una serie de condiciones */
    private void register(){
        //cambia el texto de aviso a Rojo
        txtAviso.setTextColor(Color.RED);
        //controla si el nombre no esté vacio o si la longitud es mayor que 20 caracteres del nombre o de la contraseña
        if(txtName.getText().toString().equals("") || txtName.getText().toString().length() > 20 || txtPassword.getText().toString().length() > 20) {
            //según el idioma te pone el aviso de error en el correspondiente
            if(Idioma.equals(getString(R.string.Sp)))
                txtAviso.setText(R.string.Error1Sp);
            if(Idioma.equals(getString(R.string.En)))
                txtAviso.setText(R.string.Error1En);
            //animación para la entrada del texto de aviso
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtAviso, "translationX", -metrics.widthPixels, 0);
            transAnimatio1.setDuration(400).start();
            //cambia el estado de carga a desactivado
            cargando = false;
        }
        else {
            //Búsqueda en la base de datos según el nombre introducido
            Query noRepetido = dbUsers.orderByKey().equalTo(txtName.getText().toString());
            //ejecuta la búsqueda solo una vez
            noRepetido.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    //controla si el valor de la búsqueda no es vacío
                    if((dataSnapshot.getValue())==null){
                        //crea la referencia de la base de datos para el usuario
                        DatabaseReference refName = dbUsers.child(txtName.getText().toString());
                        //crea un objeto usuario con el constructor por parámetros para que inicialice sus componentes a los por defecto
                        user = new User(txtName.getText().toString(),txtPassword.getText().toString());
                        //introduce los datos de el usuario creado en la referencia creada
                        refName.setValue(user);
                        //cambia el color del aviso a Blanco
                        txtAviso.setTextColor(Color.WHITE);
                        //según el idioma te pone el aviso de que ha salido bien en el correspondiente
                        if(Idioma.equals(getString(R.string.Sp)))
                            txtAviso.setText(R.string.RegisteredSp);
                        if(Idioma.equals(getString(R.string.En)))
                            txtAviso.setText(R.string.RegisteredEn);
                    }
                    else{
                        //según el idioma te pone el aviso de error en el correspondiente
                        if(Idioma.equals(getString(R.string.Sp)))
                            txtAviso.setText(R.string.Error2Sp);
                        if(Idioma.equals(getString(R.string.En)))
                            txtAviso.setText(R.string.Error2En);
                    }
                    //animación para la entrada del texto de aviso
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtAviso, "translationX", -metrics.widthPixels, 0);
                    transAnimatio1.setDuration(400).start();
                    //cambia el estado de carga a desactivado
                    cargando = false;
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) { }
            });
        }
    }

    /** Método que logea al usuario según una serie de condiciones */
    private void login(){
        //cambia el texto de aviso a Rojo
        txtAviso.setTextColor(Color.RED);
        //controla si el nombre no esté vacio o si la longitud es mayor que 20 caracteres del nombre o de la contraseña
        if(txtName.getText().toString().equals("") || txtName.getText().toString().length() > 20 || txtPassword.getText().toString().length() > 20){
            //según el idioma te pone el aviso de error en el correspondiente
            if(Idioma.equals(getString(R.string.Sp)))
                txtAviso.setText(R.string.Error3Sp);
            if(Idioma.equals(getString(R.string.En)))
                txtAviso.setText(R.string.Error3En);
            //animación para la entrada del texto de aviso
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtAviso, "translationX", -metrics.widthPixels, 0);
            transAnimatio1.setDuration(400).start();
            //cambia el estado de carga a desactivado
            cargando = false;
        }
        else {
            //Búsqueda en la base de datos según el nombre introducido
            Query existeNombre = database.getReference("users").orderByKey().equalTo(txtName.getText().toString());
            //ejecuta la búsqueda solo una vez
            existeNombre.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    //controla si el valor de la búsqueda no es vacío
                    if ((dataSnapshot.getValue()) != null) {
                        //controla si el texto introducido en el TextView de la contraseña coincide con la contraseñael del usuario, de nombre introducido en el TextView del nombre, en la base de datos
                        if (txtPassword.getText().toString().equals(dataSnapshot.child(txtName.getText().toString()).child("password").getValue())) {
                            //vacía el texto de los avisos
                            txtAviso.setText("");
                            //inicializa el usuario con los datos que hay en la base de datos con el nombre que has introducido en el TextView del nombre
                            user = dataSnapshot.child(txtName.getText().toString()).getValue(User.class);
                            //Cambia de activity a la del Juego y finaliza la del Login
                            Intent i = new Intent(getApplicationContext(), Clicker.class);
                            startActivity(i);
                            finish();
                        } else {
                            //según el idioma te pone el aviso de error en el correspondiente
                            if(Idioma.equals(getString(R.string.Sp)))
                                txtAviso.setText(R.string.Error4Sp);
                            if(Idioma.equals(getString(R.string.En)))
                                txtAviso.setText(R.string.Error4En);
                            //animación para la entrada del texto de aviso
                            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtAviso, "translationX", -metrics.widthPixels, 0);
                            transAnimatio1.setDuration(400).start();
                        }
                    } else {
                        //según el idioma te pone el aviso de error en el correspondiente
                        if(Idioma.equals(getString(R.string.Sp)))
                            txtAviso.setText(R.string.Error5Sp);
                        if(Idioma.equals(getString(R.string.En)))
                            txtAviso.setText(R.string.Error5En);
                        //animación para la entrada del texto de aviso
                        ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtAviso, "translationX", -metrics.widthPixels, 0);
                        transAnimatio1.setDuration(400).start();
                    }
                    //cambia el estado de carga a desactivado
                    cargando = false;
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }
    }

    /** Método utilizado desde Clicker.class para cargar los usuarios con mejor puntuación */
    public static void creacionLeaderboard(){
        //Búsqueda en la base de datos de los 5 usuarios con mejores puntuaciones
        Query lb = database.getReference("users").orderByChild("score").limitToLast(5);
        //ejecuta la búsqueda solo una vez
        lb.addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //inicializa un contador en la cantidad de usuarios menos uno
                int i=4;
                //bucle que recorre todos los usuarios de la búsqueda
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    //introduce el valor de cada usuario en un vector de usuarios
                    leaderboard[i] = ds.getValue(User.class);
                    //hace decrecer en uno el contador
                    i--;
                }
                //si no fueran vacíos rellenan con el nombre y el score en cada texto correspondiente los textos del leaderboard
                if(leaderboard[0]!=null) {
                    Clicker.lbN1.setText(""+leaderboard[0].getName());
                    Clicker.lbS1.setText(""+leaderboard[0].getScore());
                }
                if(leaderboard[1]!=null) {
                    Clicker.lbN2.setText(""+leaderboard[1].getName());
                    Clicker.lbS2.setText(""+leaderboard[1].getScore());
                }
                if(leaderboard[2]!=null) {
                    Clicker.lbN3.setText(""+leaderboard[2].getName());
                    Clicker.lbS3.setText(""+leaderboard[2].getScore());
                }
                if(leaderboard[3]!=null) {
                    Clicker.lbN4.setText(""+leaderboard[3].getName());
                    Clicker.lbS4.setText(""+leaderboard[3].getScore());
                }
                if(leaderboard[4]!=null) {
                    Clicker.lbN5.setText(""+leaderboard[4].getName());
                    Clicker.lbS5.setText(""+leaderboard[4].getScore());
                }
                //hace visible el layout del leaderboard
                Clicker.lyCopaSub.setVisibility(View.VISIBLE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    //endregion

    //region ON CLICKS

    /** Se ejecuta al hacer click en la ImagenView de los idiomas */
    public void IdiomasOnClick(View v){
        //controla si el botón está activado o desactivado
        if(idiomasActivo){
            //cambia el estado del botón a desactivado
            idiomasActivo = false;
            //animación que hace girar -90º el botón respecto a su rotación actual
            ivIdiomas.animate().rotation(ivIdiomas.getRotation() - 90).setDuration(300);
            //animaciones que esconden los botones de los idiomas a seleccionar y el texto de ayuda
            ObjectAnimator transAnimatio3 = ObjectAnimator.ofFloat(txtInfo, "translationX", 0, 1000);
            transAnimatio3.setDuration(400).start();
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivEspana, "translationX", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivEngland, "translationX", 0, 1000);
            transAnimatio2.setDuration(500).start();
        }
        else{
            //cambia el estado del botón a activado
            idiomasActivo = true;
            //hace visible los objetos para que cambien, ya que al principio están en Invisible
            txtInfo.setVisibility(View.VISIBLE);
            ivEspana.setVisibility(View.VISIBLE);
            ivEngland.setVisibility(View.VISIBLE);
            //animación que hace girar 90º el botón respecto a su rotación actual
            ivIdiomas.animate().rotation(ivIdiomas.getRotation() + 90).setDuration(300);
            //animaciones que enseñan los botones de los idiomas a seleccionar y el texto de ayuda
            ObjectAnimator transAnimatio3 = ObjectAnimator.ofFloat(txtInfo, "translationX", 1000, 0);
            transAnimatio3.setDuration(400).start();
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivEspana, "translationX", 1000, 0);
            transAnimatio1.setDuration(400).start();
            ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivEngland, "translationX", 1000, 0);
            transAnimatio2.setDuration(500).start();
        }

    }

    /** Se ejecuta al hacer click en la ImagenView de la bandera de España */
    public void EspanolOnClick(View v){
        //controla si el idioma actual no es Español
        if(!Idioma.equals(getString(R.string.Sp))){
            //cambia el idioma a Español
            Idioma = getString(R.string.Sp);
            //quita avisos por si estaba algo escrito en otro idioma
            txtAviso.setText("");
            //Escribe cualquier texto de la activity en Español
            btnRegister.setText(R.string.RegisterSp);
            btnLogin.setText(R.string.LoginNowSp);
            txtLogin.setText(R.string.LoginSp);
            txtInfo.setText(R.string.LanguagesSp);
            txtInfoName.setText(R.string.NameSp);
            txtInfoPassw.setText(R.string.PasswordSp);
        }
        //desactiva el botón de idiomas
        idiomasActivo = false;
        //animación que hace girar -90º el botón respecto a su rotación actual
        ivIdiomas.animate().rotation(ivIdiomas.getRotation() - 90).setDuration(300);
        //animaciones que esconden los botones de los idiomas a seleccionar y el texto de ayuda
        ObjectAnimator transAnimatio3 = ObjectAnimator.ofFloat(txtInfo, "translationX", 0, 1000);
        transAnimatio3.setDuration(400).start();
        ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivEspana, "translationX", 0, -1000);
        transAnimatio1.setDuration(400).start();
        ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivEngland, "translationX", 0, 1000);
        transAnimatio2.setDuration(500).start();
    }

    /** Se ejecuta al hacer click en la ImagenView de la bandera de Reino Unido */
    public void EnglishOnClick(View v){
        //controla si el idioma actual no es Inglés
        if(!Idioma.equals(getString(R.string.En))){
            //cambia el idioma a Inglés
            Idioma = getString(R.string.En);
            //quita avisos por si estaba algo escrito en otro idioma
            txtAviso.setText("");
            //Escribe cualquier texto de la activity en Inglés
            btnRegister.setText(R.string.RegisterEn);
            btnLogin.setText(R.string.LoginNowEn);
            txtLogin.setText(R.string.LoginEn);
            txtInfo.setText(R.string.LanguagesEn);
            txtInfoName.setText(R.string.NameEn);
            txtInfoPassw.setText(R.string.PasswordEn);
        }
        //desactiva el botón de idiomas
        idiomasActivo = false;
        //animación que hace girar -90º el botón respecto a su rotación actual
        ivIdiomas.animate().rotation(ivIdiomas.getRotation() - 90).setDuration(300);
        //animaciones que esconden los botones de los idiomas a seleccionar y el texto de ayuda
        ObjectAnimator transAnimatio3 = ObjectAnimator.ofFloat(txtInfo, "translationX", 0, 1000);
        transAnimatio3.setDuration(400).start();
        ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivEspana, "translationX", 0, 1000);
        transAnimatio1.setDuration(400).start();
        ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivEngland, "translationX", 0, -1000);
        transAnimatio2.setDuration(500).start();
    }

    /** Se ejecuta al hacer click en el boton de Logeo, que cambia a Registro al darle, y viceversa */
    public void loginAndRegister(View v){
        //ejecuta el método para loguear o registrar
        enter();
    }

    /** Se ejecuta al hacer click al botón para pasar de login a register y viceversa */
    public void toLoginAndToRegister(View v){
        //desactiva el botón para que no puedas darle hasta finalizar la animación
        v.setEnabled(false);
        //vacía el texto de los avisos
        txtAviso.setText("");
        //controla si está activada la parte de registro o login
        if(registerAct){
            //animación del botón
            ObjectAnimator transAnimationZ = ObjectAnimator.ofFloat(v, "translationX", (metrics.widthPixels-350), 0);
            transAnimationZ.setDuration(1000).start();
            //animación secuencial de el layout del login
            ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(rellay1, "translationX", 0, -1000);
            ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(rellay1, "translationX", 1000, 0);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playSequentially(transAnimationX, transAnimationY);
            animSetXY.setDuration(500).start();
            //creación de un runneable para cear un hilo que se ejecute cuando queramos
            Runnable runneable2 = new Runnable() {
                @Override
                public void run() {
                    //según el idioma ponelos textos en el correspondiente
                    if(Idioma.equals(getString(R.string.Sp))) {
                        btnRegister.setText(R.string.RegisterSp);
                        txtLogin.setText(R.string.LoginSp);
                        btnLogin.setText(R.string.LoginNowSp);
                    }
                    if(Idioma.equals(getString(R.string.En))){
                        btnRegister.setText(R.string.RegisterEn);
                        txtLogin.setText(R.string.LoginEn);
                        btnLogin.setText(R.string.LoginNowEn);
                    }
                }
            };
            //ejecuta el hilo del runneable medio segundo después de que pulses el botón
            hadler.postDelayed(runneable2,500);
            //cambia el estado a Login
            registerAct=false;
        }
        else {
            //animación del botón
            ObjectAnimator transAnimationZ = ObjectAnimator.ofFloat(btnRegister, "translationX", 0, (metrics.widthPixels-300));
            transAnimationZ.setDuration(1000).start();
            //animación secuencial de el layout del login
            ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(rellay1, "translationX", 0, 1000);
            ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(rellay1, "translationX", -1000, 0);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playSequentially(transAnimationX, transAnimationY);
            animSetXY.setDuration(500).start();
            //creación de un runneable para cear un hilo que se ejecute cuando queramos
            Runnable runneable2 = new Runnable() {
                @Override
                public void run() {
                    //según el idioma ponelos textos en el correspondiente
                    if(Idioma.equals(getString(R.string.Sp))) {
                        btnRegister.setText(R.string.LoginSp);
                        txtLogin.setText(R.string.RegisterSp);
                        btnLogin.setText(R.string.RegisterNowSp);
                    }
                    if(Idioma.equals(getString(R.string.En))) {
                        btnRegister.setText(R.string.LoginEn);
                        txtLogin.setText(R.string.RegisterEn);
                        btnLogin.setText(R.string.RegisterNowEn);
                    }
                }
            };
            //ejecuta el hilo del runneable medio segundo después de que pulses el botón
            hadler.postDelayed(runneable2,500);
            //cambia el estado a Register
            registerAct=true;
        }
        //espera para darle a el boton el estado activo
        Runnable runneable3 = new Runnable() {
            @Override
            public void run() {
                btnRegister.setEnabled(true);
            }
        };
        hadler.postDelayed(runneable3,1000);
    }

    //endregion
}