package Controlador;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.parra.practicaad2trimestreapc.MainActivity;
import com.example.parra.practicaad2trimestreapc.ModifyActivity;
import com.example.parra.practicaad2trimestreapc.R;

import java.util.ArrayList;

import Modelo.IProductoDao;
import Modelo.ProductoDaoImpl;
import Modelo.Productos;

public class AdapterData extends RecyclerView.Adapter<AdapterData.ViewHolderData> {

    private ArrayList<Productos> productos;

    public AdapterData(ArrayList<Productos> producto) {
        productos = new ArrayList<>();
        productos = producto;
    }

    @NonNull
    @Override
    public ViewHolderData onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_list,viewGroup,false);
        return new ViewHolderData(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderData viewHolderData, int i) {
        viewHolderData.AsignarDatos(productos.get(i));
    }

    @Override
    public int getItemCount() {
        return productos.size();
    }

    //------------------------------------------------------------------------------------
    class ViewHolderData extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final Context context;
        TextView dato, nombre, fecha, url, descripcion;
        ImageView eliminar;
        IProductoDao productoDao;

        ViewHolderData(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();
            itemView.setOnClickListener(this);
            dato=itemView.findViewById(R.id.idData);
            nombre=itemView.findViewById(R.id.name);
            fecha=itemView.findViewById(R.id.storageDate);
            url=itemView.findViewById(R.id.imageURL);
            descripcion=itemView.findViewById(R.id.description);
            eliminar=itemView.findViewById(R.id.eliminar);
            eliminar.setOnClickListener(this);
        }

        void AsignarDatos(Productos producto){
            dato.setText(producto.getCodigo()+"");
            nombre.setText(producto.getNombre());
            fecha.setText(producto.getFecha());
            url.setText(producto.getUrlImagen());
            descripcion.setText(producto.getDescripcion());
        }

        @Override
        public void onClick(View view) {
            productoDao = new ProductoDaoImpl();
            if(view.getId()==R.id.eliminar){
                productoDao.eliminarProducto(dato.getText()+"");
                itemView.setVisibility(View.INVISIBLE);
            }
            else{
                Intent i = new Intent(context.getApplicationContext(),ModifyActivity.class);
                i.putExtra("codigo", dato.getText());
                i.putExtra("nombre", nombre.getText());
                i.putExtra("fecha", fecha.getText());
                i.putExtra("url", url.getText());
                i.putExtra("descripcion", descripcion.getText());
                context.startActivity(i);
            }

        }
    }
}
