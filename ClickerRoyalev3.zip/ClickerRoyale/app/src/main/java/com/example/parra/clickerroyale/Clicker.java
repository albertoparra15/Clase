package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Clicker extends AppCompatActivity {

    //vida cofres
    static int vidaChest=10;

    //botones
    Button btnOpc1;
    Button btnOpc2;

    //layouts
    View lyTime;

    //text
    static TextView txtScore;
    static TextView txtVida;
    TextView txtNombre;

    //imagenes
    ImageView ivOpciones;
    ImageView ivChest;
    ImageView ivCopa;
    ImageView ivFlecha;
    ImageView ivReloj;
    ImageView ivAmigo;


    //booleans controladores
    boolean opcionesAtivo=false;
    boolean timeActivo=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);

        ivOpciones = (ImageView) findViewById(R.id.ivOpciones);
        ivChest = (ImageView) findViewById(R.id.ivChest);
        txtScore = (TextView) findViewById(R.id.txtScore);
        txtVida = (TextView) findViewById(R.id.txtVida);
        txtNombre = (TextView) findViewById(R.id.txtNombre);
        btnOpc1 = (Button) findViewById(R.id.btnOpciones1);
        btnOpc2 = (Button) findViewById(R.id.btnOpciones2);
        lyTime = (View) findViewById(R.id.lyTime);
        ivReloj = (ImageView) findViewById(R.id.ivReloj);
        ivFlecha = (ImageView) findViewById(R.id.ivFlecha);
        ivAmigo = (ImageView) findViewById(R.id.ivAmigo);
        ivCopa = (ImageView) findViewById(R.id.ivCopa);

        txtScore.setText(LoginActivity.user.getScore()+"");
        txtVida.setText(vidaChest+"");
        txtNombre.setText(LoginActivity.user.getName()+"");

        ParraAsyncTask tarea2 = new ParraAsyncTask();
        tarea2.execute();
    }

    public void opcionesOnClick(View v) {
        btnOpc1.setVisibility(View.VISIBLE);
        btnOpc2.setVisibility(View.VISIBLE);


        if(opcionesAtivo){
            ObjectAnimator transAnimation= ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, 1000);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn= ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, 1000);
            transAnimationn.setDuration(500).start();
            opcionesAtivo=false;
            ivOpciones.animate().rotation(ivOpciones.getRotation()-90).setDuration(200);
        }
        else{
            ObjectAnimator transAnimation= ObjectAnimator.ofFloat(btnOpc1, "translationX", 1000, 0);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn= ObjectAnimator.ofFloat(btnOpc2, "translationX", 1000, 0);
            transAnimationn.setDuration(500).start();
            opcionesAtivo=true;
            ivOpciones.animate().rotation(ivOpciones.getRotation()+90).setDuration(200);
        }
    }

    public void chestOnClick(View v){
        vidaChest=vidaChest-LoginActivity.user.getClickDamage();
        if(vidaChest<=0){
            vidaChest=10;
            LoginActivity.user.setScore(LoginActivity.user.getScore()+3);
            txtScore.setText(LoginActivity.user.getScore()+"");
            ObjectAnimator transAnimatio1= ObjectAnimator.ofFloat(txtVida, "translationY", 100, 0);
            transAnimatio1.setDuration(100).start();
            ObjectAnimator transAnimatio2= ObjectAnimator.ofFloat(v, "translationY", -150, 0);
            transAnimatio2.setDuration(100).start();
        }
        else{
            int x = (int) (Math.random()*41)-20;
            int y = 20-Math.abs(x);
            System.out.println(x+" "+y);

            ObjectAnimator transAnimationX= ObjectAnimator.ofFloat(v, "translationX", x, 0);
            ObjectAnimator transAnimationY= ObjectAnimator.ofFloat(v, "translationY", y, 0);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playTogether(transAnimationX, transAnimationY);
            animSetXY.setDuration(300).start();

        }
        txtVida.setText(vidaChest+"");


    }
    public void timeOnClick(View v){
        lyTime.setVisibility(View.VISIBLE);

        if(timeActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivReloj.setImageResource(R.drawable.reloj);
            timeActivo=false;
        }else {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 1000, 0);
            transAnimatio1.setDuration(400).start();
            ivReloj.setImageResource(R.drawable.relojact);
            timeActivo=true;
        }
    }

    public void salirOnClick(View v){
        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        dialogo1.setTitle("Importante");
        dialogo1.setMessage("¿ Desea salir de esta cuenta ?");
        dialogo1.setCancelable(true);
        dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                Intent empezar = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(empezar);

                finish();
            }
        });
        dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                Intent seguir = new Intent(getApplicationContext(), Clicker.class);
                startActivity(seguir);

                finish();
            }
        });
        dialogo1.show();
    }
}
