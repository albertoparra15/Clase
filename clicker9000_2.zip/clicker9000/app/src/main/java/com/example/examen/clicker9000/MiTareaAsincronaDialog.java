package com.example.examen.clicker9000;

import android.os.AsyncTask;

class MiTareaAsincronaDialog extends AsyncTask<Void, Integer, Boolean> {

    public static int contadorGuardar=41;
    boolean guardado=false;
    static boolean activo=true;


    @Override
    protected Boolean doInBackground(Void... params) {


        while (true) {
            if(activo==true) {
                try {
                    Thread.sleep(250);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (contadorGuardar < 40) {
                    contadorGuardar++;
                } else {
                    if (contadorGuardar == 40) {
                        guardado = true;
                        contadorGuardar++;
                    }
                }


                Clicker.score = Clicker.score + Clicker.dps;
                publishProgress(Clicker.score);

                if (isCancelled())
                    break;
            }
        }
        return true;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {

        Clicker.txtScore.setText("Score: "+Clicker.score);
        if(guardado==true){
            Clicker.btnGuardar.setEnabled(true);
            guardado=false;
        }

    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(Boolean result) {
    }

    @Override
    protected void onCancelled() {
    }
}