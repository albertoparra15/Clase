package com.example.examen.clicker9000;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {
    //conexión con la base de datos de Firebase
    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    //referencia a usar de la base de datos Firebase
    DatabaseReference ref = database.getReference("users");

    //datos a guardar para la base de datos
    static String _name;
    static String _password;

    //campos de texto
    EditText txtName;
    EditText txtPassword;

    //botones
    Button registerBtn;
    Button loginBtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //conectamos los elementos con su id en la activity
        txtName = (EditText) findViewById(R.id.txtName);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
        registerBtn = (Button) findViewById(R.id.btnRegister);
        loginBtn = (Button) findViewById(R.id.btnLogin);
    }

    //recoge lo que has puesto en los campos de texto
    public void cogerTxts(){
        _name = txtName.getText().toString();
        _password = txtPassword.getText().toString();
    }

    //función que se ejecuta al pulsar el boton de registrar
    public void registerOnClick(View v){
        cogerTxts();
        register();
    }

    //función que analiza si se puede registrar y lo hace si puede
    public void register(){

        if(_name.equals("")) {

        }
        else {
            registerBtn.setEnabled(false);
            loginBtn.setEnabled(false);

            Query noRepetido = database.getReference("users").orderByKey().equalTo(_name);

            noRepetido.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if((dataSnapshot.getValue())==null){

                        DatabaseReference refName = ref.child(_name);
                        DatabaseReference password = refName.child("password");
                        password.setValue(_password);
                        DatabaseReference dps = refName.child("dps");
                        dps.setValue(0);
                        DatabaseReference dpc = refName.child("dpc");
                        dpc.setValue(1);
                        DatabaseReference score = refName.child("score");
                        score.setValue(0);
                        DatabaseReference amigos = refName.child("amigo");
                        amigos.setValue("");
                        DatabaseReference solicitud = refName.child("solicitud");
                        solicitud.setValue("");

                        Toast registrado= Toast.makeText(getApplicationContext(),"registrado",Toast.LENGTH_SHORT);
                        registrado.setGravity(Gravity.TOP,0,540);
                        registrado.show();
                    }
                    else{
                        Toast noregistrado= Toast.makeText(getApplicationContext(),"ya existe ese usuario",Toast.LENGTH_SHORT);
                        noregistrado.setGravity(Gravity.TOP,0,540);
                        noregistrado.show();
                    }
                    registerBtn.setEnabled(true);
                    loginBtn.setEnabled(true);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    registerBtn.setEnabled(true);
                    loginBtn.setEnabled(true);
                }
            });
        }
    }

    //función que se ejecuta al pulsar el boton de login
    public void loginOnClick(View v) {
        cogerTxts();
        logear();
    }

    //funcion que analiza si existe tu usuario y si coincide la contraseña
    public void logear(){
        if(_name.equals("")) {

        }
        else{
            loginBtn.setEnabled(false);
            registerBtn.setEnabled(false);

            Query existeNombre = database.getReference("users").orderByKey().equalTo(_name);

            existeNombre.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if((dataSnapshot.getValue())==null){
                        Toast nologueado= Toast.makeText(getApplicationContext(),"no está logueado",Toast.LENGTH_SHORT);
                        nologueado.setGravity(Gravity.TOP,0,540);
                        nologueado.show();
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        loginBtn.setEnabled(true);
                        registerBtn.setEnabled(true);
                    }
                    else{
                        Query coincideContras = database.getReference("users").child(_name).child("password");

                        coincideContras.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                                if (dataSnapshot.getValue().equals(_password)) {
                                    Intent clicker = new Intent(getApplicationContext(), Clicker.class);
                                    startActivity(clicker);

                                    finish();

                                } else {
                                    Toast nocoincide = Toast.makeText(getApplicationContext(), "no coincide la contraseña", Toast.LENGTH_SHORT);
                                    nocoincide.setGravity(Gravity.TOP, 0, 540);
                                    nocoincide.show();
                                    try {
                                        Thread.sleep(1000);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }

                                }
                                loginBtn.setEnabled(true);
                                registerBtn.setEnabled(true);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                loginBtn.setEnabled(true);
                                registerBtn.setEnabled(true);
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    loginBtn.setEnabled(true);
                    registerBtn.setEnabled(true);}
            });


        }
    }

    private static final int INTERVALO = 2000; //2 segundos para salir
    private long tiempoPrimerClick;

    @Override
    public void onBackPressed(){
        if (tiempoPrimerClick + INTERVALO > System.currentTimeMillis()){
            super.onBackPressed();
            return;
        }else {
            Toast.makeText(this, "Vuelve a presionar para salir", Toast.LENGTH_SHORT).show();
        }
        tiempoPrimerClick = System.currentTimeMillis();
    }
}
