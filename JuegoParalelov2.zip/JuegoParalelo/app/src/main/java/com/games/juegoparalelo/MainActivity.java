package com.games.juegoparalelo;

import android.annotation.SuppressLint;
import android.graphics.Point;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static int score;
    public static int dps;
    public static int coste;
    public static TextView txtScore;
    public static TextView txtDps;
    public static TextView txtDpc;
    public static Button btnDps;
    public static ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDps= (Button) findViewById(R.id.btnDps);
        imagen= (ImageView) findViewById(R.id.imagen);
        txtScore= (TextView) findViewById(R.id.textoScore);
        txtDps= (TextView) findViewById(R.id.txtDps);
        txtDpc= (TextView) findViewById(R.id.txtDpc);
        score=0;
        dps=0;
        coste=10;


        MiTareaAsincronaDialog tarea2 = new MiTareaAsincronaDialog();
        tarea2.execute();

    }

    public void dpsOnClick(View v){
        if(score>=coste){
            score-=coste;
            coste+=10;
            btnDps.setText("coste: "+coste);
            dps++;
            txtDps.setText("Dps: "+dps);
        }
    }

    public void giraOnClick(View v){
        score++;
        imagen.animate().rotation(imagen.getRotation()-5).setDuration(200);
    }

    @Override
    protected void onStart() {
        super.onStart();
        System.out.println("se llama a onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        System.out.println("Se llama a onResume desde la mainActivity");
    }

    @Override
    protected void onStop(){
        super.onStop();
        System.out.println("Se llama a onStop desde la mainActivity");
    }

}
