package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Objects;

import tyrantgit.explosionfield.ExplosionField;

public class Clicker extends AppCompatActivity implements View.OnClickListener{

    //region VARIABLES

    //statics
    static LinearLayout lyCopaSub;
    static TextView txtAviso, txtScore, txtVida;
    static TextView lbN1, lbN2, lbN3, lbN4, lbN5, lbS1, lbS2, lbS3, lbS4, lbS5;
    static ImageView ivChest, ivmundo, ivMoneda, ivChestExplote;
    static ExplosionField explosionField;
    static DisplayMetrics metrics;
    static int vidaChest, oro;

    private ParraAsyncTask tarea2;
    private DatabaseReference bd = LoginActivity.dbUsers.child(LoginActivity.user.getName());

    private TextView txtMCapacitySuma;

    //handler y runneables
    private Handler hadler = new Handler();
    private Runnable runneableReinicioCofre, runneableObtenerOro, runneableBajaMundo, runneableSubeMundo, runneableEscondeAviso, runneableReinicioAvisos;

    //buttons
    private Button btnOpc1, btnOpc2, btnOpc3, btnOpc4;
    private Button ivCopa, ivFlecha, ivReloj;
    private Button btnMDamage, btnMSpeed, btnMCapacity, btnMClickDamage, btnMGoldInactive;

    //layouts
    private View lyTime, lyFlecha, lyCopa, lycamcon;

    private TextView txtDAct, txtSAct, txtCAct, txtCDAct, txtGIAct;
    private EditText passwordact, passwordnew;

    //images
    private ImageView ivOpciones;
    private ImageView ivCarga;

    //booleans controladores
    private boolean opcionesAtivo, timeActivo, flechaActivo, copaActivo, camconActivo, guardadoManual;

    //precios
    private int precioCapacity, precioDamage, precioSpeed, precioClickDamage, precioGoldInactive;

    //endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);

        //inicializa los componentes
        InitComponents();

        //hace que sea posible hacer click a los campos correspondientes
        ivChest.setOnClickListener(this);
        ivReloj.setOnClickListener(this);
        ivOpciones.setOnClickListener(this);
        ivFlecha.setOnClickListener(this);
        ivCopa.setOnClickListener(this);

        //añade el oro que te corresponda por estar desconectado
        OroExtraInactivo();
    }

    //region MÉTODOS ÚTILES

    /** Método que devuelve el precio de la capcidad según las mejoras obtenidas de ésta */
    private int CalculoPrecioCapacity(){
        return LoginActivity.user.getCapacity() - (LoginActivity.user.getCapacity()/8);
    }

    /** Método que devuelve el precio de la velocidad según las mejoras obtenidas de ésta */
    private int CalculoPrecioSpeed(){
        return (int) (Math.pow(4,(1000 - LoginActivity.user.getSpeed())/10f) + 30);
    }

    /** Método que devuelve el precio del daño automático según las mejoras obtenidas de ésta */
    private int CalculoPrecioDamage(){
        return (int) (Math.pow(3,LoginActivity.user.getDamage()) + 5);
    }

    /** Método que devuelve el precio del daño por click según las mejoras obtenidas de ésta */
    private int CalculoPrecioClickDamage(){
        return (int) (Math.pow(3,LoginActivity.user.getClickDamage()) + 34);
    }

    /** Método que devuelve el precio del oro descactivado según las mejoras obtenidas de ésta */
    private int CalculoPrecioGoldInactive(){
        return (int) (Math.pow(4,LoginActivity.user.getDpsInactive()) + 100);
    }

    /** Método que inicializa los componentes */
    @SuppressLint("SetTextI18n")
    private void InitComponents(){
        //inicializa la vida del cofre, el oro que vas a obener por cada cofre y los precios de las mejoras
        vidaChest = Math.round(LoginActivity.user.getCapacity()/10f);
        oro = (vidaChest / 5) + 1;
        precioCapacity = CalculoPrecioCapacity();
        precioDamage = CalculoPrecioDamage();
        precioSpeed = CalculoPrecioSpeed();
        precioClickDamage = CalculoPrecioClickDamage();
        precioGoldInactive = CalculoPrecioGoldInactive();

        //inicializa los estados de la app
        opcionesAtivo=false;
        timeActivo=false;
        flechaActivo=false;
        copaActivo=false;
        camconActivo=false;
        guardadoManual = true;

        //region RUNNEABLES
        runneableReinicioCofre = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //animaciones del cofre y su vida para que aparezcan otra vez
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtVida, "translationY", metrics.heightPixels, 0);
                transAnimatio1.setDuration(100).start();
                ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivChest, "translationY", -metrics.heightPixels, 0);
                transAnimatio2.setDuration(100).start();
                //vuelve activo el cofre de nuevo para que se pueda activar su onClick
                ivChest.setEnabled(true);
                //vuelve visibles el cofre y su vida
                ivChest.setVisibility(View.VISIBLE);
                txtVida.setVisibility(View.VISIBLE);
                //reinicia la explosión del cofre secundario
                explosionField.clear();
                //escribe la vida del cofre actual
                txtVida.setText(vidaChest + "");
            }
        };

        runneableObtenerOro = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //controla si la capacidad no va a superarse
                if ((LoginActivity.user.getScore() + Clicker.oro) <= LoginActivity.user.getCapacity()) {
                    //añade el oro obtenido y lo escribe en el campo correspondiente
                    LoginActivity.user.setScore(LoginActivity.user.getScore() + Clicker.oro);
                    txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                } else {
                    //añade el oro máximo obtenible y lo escribe en el campo correspondiente
                    LoginActivity.user.setScore(LoginActivity.user.getCapacity());
                    txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                }
                //reinicia la imagen del cofre principal
                ivChest.setImageResource(R.drawable.chest);
                //esconde la imagen del cofre
                ivChest.setVisibility(View.GONE);
                //anima el mundo para que rote
                ivmundo.animate().rotation(Clicker.ivmundo.getRotation()+60).setDuration(200);
            }
        };

        runneableBajaMundo = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //animación del mundo para que baje por la bajada del cofre
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivmundo, "translationY", 0, 30);
                transAnimatio1.setDuration(50).start();
            }
        };

        runneableSubeMundo = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //animación de el mundo para que suba a su estado natural
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivmundo, "translationY", 30, 0);
                transAnimatio1.setDuration(50).start();
            }
        };

        runneableEscondeAviso = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                //vuelve activables los botones de las opciones de guardado si no lo estaban
                if(!btnOpc3.isEnabled())
                    btnOpc3.setEnabled(true);
                if(!btnOpc4.isEnabled())
                    btnOpc4.setEnabled(true);
                //animación de el aviso para que sea más visual
                ObjectAnimator transAnimation = ObjectAnimator.ofFloat(txtAviso, "translationX", 0, -1000);
                transAnimation.setDuration(500).start();
            }
        };

        runneableReinicioAvisos = new Runnable() {
            @Override
            public void run() {
                //vacía el campo de avisos
                txtAviso.setText("");
            }
        };
        //endregion

        //inicializa las imágenes
        ivOpciones = findViewById(R.id.ivOpciones);
        ivChest = findViewById(R.id.ivChest);
        ivChestExplote = findViewById(R.id.ivChestExplote);
        ivMoneda = findViewById(R.id.ivMoneda);
        ivCarga = findViewById(R.id.ivCarga);
        ivmundo = findViewById(R.id.mundo);
        ivReloj = findViewById(R.id.ivReloj);
        ivFlecha = findViewById(R.id.ivFlecha);
        ivCopa = findViewById(R.id.ivCopa);

        //inicializa los textos
        txtScore = findViewById(R.id.txtScore);
        txtVida = findViewById(R.id.txtVida);
        TextView txtNombre = findViewById(R.id.txtNombre);
        txtAviso = findViewById(R.id.txtAvisos);
        txtMCapacitySuma = findViewById(R.id.txtMCapacitySuma);
        TextView txtNewPassw = findViewById(R.id.txtNewPassw);
        TextView txtmilis = findViewById(R.id.txtMSpeedSuma);
        TextView txtporminuto = findViewById(R.id.txtMOInactivoSuma);
        txtDAct = findViewById(R.id.txtMDamageAct);
        txtSAct = findViewById(R.id.txtMSpeedAct);
        txtCAct = findViewById(R.id.txtMCapacitydAct);
        txtCDAct = findViewById(R.id.txtMCDamageAct);
        txtGIAct = findViewById(R.id.txtMOInactivoAct);
        TextView txtDamage = findViewById(R.id.txtMejoraDamage);
        TextView txtClickDamage = findViewById(R.id.txtMejoraDanoClick);
        TextView txtSpeed = findViewById(R.id.txtMejoraSpeed);
        TextView txtCapacity = findViewById(R.id.txtMejoraCapacity);
        TextView txtGoldInactive = findViewById(R.id.txtMejoraOroInactivo);
        TextView txtChangePassword = findViewById(R.id.txtChangePassword);
        TextView txtPasswAct = findViewById(R.id.txtPasswAct);
        lbN1 = findViewById(R.id.lbNombre1);
        lbN2 = findViewById(R.id.lbNombre2);
        lbN3 = findViewById(R.id.lbNombre3);
        lbN4 = findViewById(R.id.lbNombre4);
        lbN5 = findViewById(R.id.lbNombre5);
        lbS1 = findViewById(R.id.lbScore1);
        lbS2 = findViewById(R.id.lbScore2);
        lbS3 = findViewById(R.id.lbScore3);
        lbS4 = findViewById(R.id.lbScore4);
        lbS5 = findViewById(R.id.lbScore5);

        //inicializa los textos editables
        passwordact = findViewById(R.id.etpassact);
        passwordnew = findViewById(R.id.etpassnew);

        //inicializa los botones
        Button btnChangePassw = findViewById(R.id.btnChangePassw);
        btnMDamage = findViewById(R.id.btnMejoraDamage);
        btnMSpeed = findViewById(R.id.btnMejoraSpeed);
        btnMCapacity = findViewById(R.id.btnMejoraCapacity);
        btnMClickDamage = findViewById(R.id.btnMejoraDanoClick);
        btnMGoldInactive = findViewById(R.id.btnMejoraOroInactivo);
        btnOpc1 = findViewById(R.id.btnOpciones1);
        btnOpc2 = findViewById(R.id.btnOpciones2);
        btnOpc3 = findViewById(R.id.btnOpciones3);
        btnOpc4 = findViewById(R.id.btnOpciones4);

        //inicializa los layouts
        lyTime = findViewById(R.id.lyTime);
        lyFlecha = findViewById(R.id.lyFlecha);
        lyCopa = findViewById(R.id.lyCopa);
        lyCopaSub = findViewById(R.id.lyCopaSub);
        lycamcon = findViewById(R.id.lycamcon);

        //inicializa e instancia las medidas del movil en uso
        metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        //escribe en los textos
        txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
        txtVida.setText(vidaChest+"");
        txtNombre.setText(LoginActivity.user.getName()+"");
        txtDAct.setText("Act: "+LoginActivity.user.getDamage());
        txtSAct.setText("Act: "+LoginActivity.user.getSpeed());
        txtCAct.setText("Act: "+LoginActivity.user.getCapacity());
        txtCDAct.setText("Act: "+LoginActivity.user.getClickDamage());
        txtGIAct.setText("Act: "+LoginActivity.user.getDpsInactive());

        //escribe en los textos y botones en Español
        if(LoginActivity.Idioma.equals(getString(R.string.Sp))) {
            btnMClickDamage.setText(getString(R.string.CostSp) + ": " + precioClickDamage);
            btnMDamage.setText(getString(R.string.CostSp) + ": " + precioDamage);
            btnMSpeed.setText(getString(R.string.CostSp) + ": " + precioSpeed);
            btnMCapacity.setText(getString(R.string.CostSp) + ": " + precioCapacity);
            btnMGoldInactive.setText(getString(R.string.CostSp) + ": " + precioGoldInactive);
            txtDamage.setText(getString(R.string.DamageSp));
            txtClickDamage.setText(getString(R.string.DamageClickSp));
            txtSpeed.setText(getString(R.string.SpeedSp));
            txtCapacity.setText(getString(R.string.CapacitySp));
            txtGoldInactive.setText(getString(R.string.GoldInactiveSp));
            btnOpc1.setText(getString(R.string.ChangePasswordSp));
            btnOpc2.setText(getString(R.string.SignOffSp));
            btnOpc3.setText(getString(R.string.ChangeSaveSp));
            btnOpc4.setText(getString(R.string.SaveSp));
            txtChangePassword.setText(getString(R.string.ChangePasswordSp));
            txtPasswAct.setText(getString(R.string.PasswordActSp));
            txtNewPassw.setText(getString(R.string.NewPasswordSp));
            btnChangePassw.setText(getString(R.string.ChangePasswordSp));
            txtmilis.setText(getString(R.string.MillisSp));
            txtporminuto.setText(getString(R.string.PerMinuteSp));
        }
        //escribe en los textos y botones en Inglés
        if(LoginActivity.Idioma.equals(getString(R.string.En))) {
            btnMClickDamage.setText(getString(R.string.CostEn) + ": " + precioClickDamage);
            btnMDamage.setText(getString(R.string.CostEn) + ": " + precioDamage);
            btnMSpeed.setText(getString(R.string.CostEn) + ": " + precioSpeed);
            btnMCapacity.setText(getString(R.string.CostEn) + ": " + precioCapacity);
            btnMGoldInactive.setText(getString(R.string.CostEn) + ": " + precioGoldInactive);
            txtDamage.setText(getString(R.string.DamageEn));
            txtClickDamage.setText(getString(R.string.DamageClickEn));
            txtSpeed.setText(getString(R.string.SpeedEn));
            txtCapacity.setText(getString(R.string.CapacityEn));
            txtGoldInactive.setText(getString(R.string.GoldInactiveEn));
            btnOpc1.setText(getString(R.string.ChangePasswordEn));
            btnOpc2.setText(getString(R.string.SignOffEn));
            btnOpc3.setText(getString(R.string.ChangeSaveEn));
            btnOpc4.setText(getString(R.string.SaveEn));
            txtChangePassword.setText(getString(R.string.ChangePasswordEn));
            txtPasswAct.setText(getString(R.string.PasswordActEn));
            txtNewPassw.setText(getString(R.string.NewPasswordEn));
            btnChangePassw.setText(getString(R.string.ChangePasswordEn));
            txtmilis.setText(getString(R.string.MillisEn));
            txtporminuto.setText(getString(R.string.PerMinuteEn));
        }

        //inicializa la animación de la explosión en esta activity
        explosionField = ExplosionField.attach2Window(this);

        //inicializa el AsyncTask
        tarea2 = new ParraAsyncTask();
    }

    /** Método que actualiza el oro que obtienes por estar desactivado */
    private void OroExtraInactivo(){
        //recoge el dinero que vas a obtener
        int dineroExtra = compararFechas();
        //controla si el dinero no es 0
        if(dineroExtra != 0) {
            //crea un mensaje vacío que se irá rellenando
            String mensaje = "";
            //controla si el dinero obtenido es mayor que lo que puedes almacenar
            if(dineroExtra > (LoginActivity.user.getCapacity() - LoginActivity.user.getScore())){
                //según el idioma rellena el mensaje en el correspondiente
                if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                    mensaje = getString(R.string.DialogGold1Sp) + " " + dineroExtra / LoginActivity.user.getDpsInactive() + " " + getString(R.string.DialogGold2Sp);
                if(LoginActivity.Idioma.equals(getString(R.string.En)))
                    mensaje = getString(R.string.DialogGold1En) + " " + dineroExtra / LoginActivity.user.getDpsInactive() + " " + getString(R.string.DialogGold2En);
                //inicializa el dinero obtenido de nuevo al dinero que le queda por almacenar
                dineroExtra = (LoginActivity.user.getCapacity() - LoginActivity.user.getScore());
            }
            else {
                //según el idioma rellena el mensaje en el correspondiente
                if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                    mensaje = getString(R.string.DialogGold3Sp) + " " + dineroExtra + " " + getString(R.string.DialogGold4Sp) + " " + dineroExtra / LoginActivity.user.getDpsInactive() + " " + getString(R.string.DialogGold2Sp);
                if(LoginActivity.Idioma.equals(getString(R.string.En)))
                    mensaje = getString(R.string.DialogGold3En) + " " + dineroExtra + " " + getString(R.string.DialogGold4En) + " " + dineroExtra / LoginActivity.user.getDpsInactive() + " " + getString(R.string.DialogGold2En);
            }
            //crea un mensaje de diálogo
            AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
            //según el idioma rellena el título en el correspondiente
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                dialogo1.setTitle(getString(R.string.GoldInactiveSp));
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                dialogo1.setTitle(getString(R.string.GoldInactiveEn));
            //añade el mensaje rellenado anteriormente al mensaje de diálogo
            dialogo1.setMessage(mensaje);
            //hace que el diálogo no se pueda cancelar
            dialogo1.setCancelable(false);
            //hace que el dinero sea una variable constante para utilizarla a continuación
            final int finalDineroExtra = dineroExtra;
            //según el idioma rellena el mensaje de recoger en el correspondiente
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                dialogo1.setPositiveButton(getString(R.string.GetSp), new DialogInterface.OnClickListener() {
                    @SuppressLint("SetTextI18n")
                    public void onClick(DialogInterface dialogo1, int id) {
                        //añade el dinero a el usuario y lo escribe en el campo correspondiente
                        LoginActivity.user.setScore(LoginActivity.user.getScore() + finalDineroExtra);
                        txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                        //inicia el AsyncTask
                        tarea2.seguir=true;
                        tarea2.execute();
                    }
                });
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                dialogo1.setPositiveButton(getString(R.string.GetEn), new DialogInterface.OnClickListener() {
                    @SuppressLint("SetTextI18n")
                    public void onClick(DialogInterface dialogo1, int id) {
                        //añade el dinero a el usuario y lo escribe en el campo correspondiente
                        LoginActivity.user.setScore(LoginActivity.user.getScore() + finalDineroExtra);
                        txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                        //inicia el AsyncTask
                        tarea2.seguir=true;
                        tarea2.execute();
                    }
                });
            //muestra el diálogo creado
            dialogo1.show();
        }
        else{
            //inicia el AsyncTask
            tarea2.seguir=true;
            tarea2.execute();
        }
    }

    /** Método que compara las fechas de la última conexión y la actual */
    private int compararFechas(){
        //crea un objeto y lo instancia de tipo fecha
        Calendar calendar;
        calendar = Calendar.getInstance();
        //guarda en varibles los minutos que tiene la fecha actual y la de la última conexión
        int minutosHoy = calendar.get(Calendar.MINUTE) + (calendar.get(Calendar.HOUR_OF_DAY) * 60) + (calendar.get(Calendar.DAY_OF_YEAR) * 1440) + (calendar.get(Calendar.YEAR) * 525600);
        int minutosUltima = LoginActivity.user.getDate().getMinute() + (LoginActivity.user.getDate().getHour()*60) + (LoginActivity.user.getDate().getDay()*1440) + (LoginActivity.user.getDate().getYear()*525600);
        //devuelve la diferencia entre las fechas en minutos multiplicado por el oro que obtienes por minuto
        return ((minutosHoy - minutosUltima) * LoginActivity.user.getDpsInactive());
    }

    //endregion

    //region ON CLICKS MENUS

    /** Se ejecuta al pulsar los botones que acceden a menús de la app y al darle al cofre */
    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {
        //controla que si el botón pulsado no fuera el del cofre cierra los demás menús
        if(v.getId()!=R.id.ivChest){
            cierraMenusNoActivos();
        }

        //selecciona el boton que estas usando
        switch (v.getId()) {

            //accion del boton del leaderboard (Copa)
            case R.id.ivCopa:
                //hace visible el layout del leaderboard
                lyCopa.setVisibility(View.VISIBLE);
                //hace inactivos los demás menús
                opcionesAtivo=false;
                timeActivo=false;
                flechaActivo=false;
                //controla si el menú del leaderboard está activo
                if(copaActivo){
                    //inactiva el menú
                    copaActivo=false;
                }
                else{
                    //activa el menú
                    copaActivo=true;
                    //anima el layout del leaderboard para salir desde abajo hasta su posición inicial
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", metrics.heightPixels, 0);
                    transAnimatio1.setDuration(400).start();
                    //cambia el icino de la copa para que se diferencie de los otros al estar seleccionado
                    ivCopa.setBackgroundResource(R.drawable.copaact);
                    //llama al método que escribe los mejores usuarios y sus puntuaciones
                    LoginActivity.creacionLeaderboard();
                    //anima la imagen de carga mientras se cargan los datos del leaderboard
                    ivCarga.animate().rotation(ivCarga.getRotation()+1800).setDuration(10000);
                    //hace que no sea visible el leaderboard, ya que cuando termina creacionLeaderboard lo hace visible
                    lyCopaSub.setVisibility(View.GONE);
                }
                break;

            //accion del boton de clicks (Flecha)
            case R.id.ivFlecha:
                //hace visible el layout de clicks
                lyFlecha.setVisibility(View.VISIBLE);
                //hace inactivos los demás menús
                opcionesAtivo=false;
                timeActivo=false;
                copaActivo=false;
                //controla si el menú de clicks está activo
                if(flechaActivo){
                    //inactiva el menú
                    flechaActivo=false;
                }else{
                    //activa el menú
                    flechaActivo=true;
                    //anima el layout de clicks para salir desde abajo hasta su posición inicial
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", metrics.heightPixels, 0);
                    transAnimatio1.setDuration(400).start();
                    //cambia el icino de la flecha para que se diferencie de los otros al estar seleccionado
                    ivFlecha.setBackgroundResource(R.drawable.flechaact);
                }
                break;

            //accion del boton de inactividad (Reloj)
            case R.id.ivReloj:
                //hace visible el layout de inactividad
                lyTime.setVisibility(View.VISIBLE);
                //hace inactivos los demás menús
                opcionesAtivo=false;
                flechaActivo=false;
                copaActivo=false;
                //controla si el menú de inactividad está activo
                if(timeActivo){
                    //inactiva el menú
                    timeActivo=false;
                }else {
                    //activa el menú
                    timeActivo=true;
                    //anima el layout de inactividad para salir desde abajo hasta su posición inicial
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", metrics.heightPixels, 0);
                    transAnimatio1.setDuration(400).start();
                    //cambia el icino del reloj para que se diferencie de los otros al estar seleccionado
                    ivReloj.setBackgroundResource(R.drawable.relojact);
                }
                break;

            //accion del boton del cofre
            case R.id.ivChest:
                //controla si el menú del cambio de contraseña no está activo
                if(!camconActivo ) {
                    //cierra los demás menús
                    cierraMenusNoActivos();
                    //hace inactivos los demás menús
                    opcionesAtivo = false;
                    timeActivo = false;
                    flechaActivo = false;
                    copaActivo = false;
                    //resta vida al cofre según el daño del usuario
                    vidaChest = vidaChest - LoginActivity.user.getClickDamage();
                    //controla si la vida del cofre se ha acabado
                    if (vidaChest <= 0) {
                        //reinicia la vida del cofre
                        vidaChest = Math.round(LoginActivity.user.getCapacity()/10f);
                        //la imagen del cofre secundaria explota con una animación con partículas
                        explosionField.explode(ivChestExplote);
                        explosionField.expandExplosionBound(200,200);
                        //ejecuta los hilos terciarios que se ejecutarán en los tiempos establecidos para hacer las animaciones correspondientes
                        hadler.postDelayed(runneableSubeMundo,600);
                        hadler.postDelayed(runneableBajaMundo,550);
                        hadler.postDelayed(runneableReinicioCofre,500);
                        hadler.postDelayed(runneableObtenerOro,300);
                        //cambia la imagen del cofre principal a una más deteriorada como reflejo de que se ha abierto
                        ivChest.setImageResource(R.drawable.chestfinal);
                        //la imagen del cofre pasa a estar desactivada para no poder quitarle vida al cofre mientras se ejecutan las animaciones
                        ivChest.setEnabled(false);
                        //se vuelve no visible el compo que refleja la vida del cofre
                        txtVida.setVisibility(View.GONE);
                        //se vuelve visible la moneda que refleja que vas a obtener oro con ese cofre
                        ivMoneda.setVisibility(View.VISIBLE);
                        //animaciones para la moneda en x e y a la vez
                        ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(ivMoneda, "translationX", Math.round(metrics.widthPixels/2f), 0);
                        ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(ivMoneda, "translationY", Math.round(metrics.heightPixels/2f), 0);
                        AnimatorSet animSetXY = new AnimatorSet();
                        animSetXY.playTogether(transAnimationX, transAnimationY);
                        animSetXY.setDuration(300).start();
                    } else {
                        //crea dos varibles aleatorias entre unos parámetros
                        int x = (int) (Math.random() * 41) - 20;
                        int y = 20 - Math.abs(x);

                        //animación del cofre moviendose en x e y a la vez para reflejar que se le hace daño
                        ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(v, "translationX", x, 0);
                        ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(v, "translationY", y, 0);
                        AnimatorSet animSetXY = new AnimatorSet();
                        animSetXY.playTogether(transAnimationX, transAnimationY);
                        animSetXY.setDuration(300).start();
                    }
                    //escribe la vida actual del cofre en su campo
                    txtVida.setText(vidaChest + "");
                }
                break;

            //accion del boton opciones
            case R.id.ivOpciones:
                //hace visibles los botones de cerrado de sesión, cambio de contraseña, y cambio de tipo de guardado
                btnOpc1.setVisibility(View.VISIBLE);
                btnOpc2.setVisibility(View.VISIBLE);
                btnOpc3.setVisibility(View.VISIBLE);
                //controla si está activado el guardado manual para hacer visible también el botón de guardar
                if(guardadoManual)
                    btnOpc4.setVisibility(View.VISIBLE);
                //hace inactivos los demás menús
                timeActivo=false;
                flechaActivo=false;
                copaActivo=false;
                //controla si el menú de opciones está activo
                if(opcionesAtivo){
                    //inactiva el menú
                    opcionesAtivo=false;
                }
                else{
                    //activa el menú
                    opcionesAtivo=true;
                    //animación de entrada de los botones de cerrado de sesión, cambio de contraseña, y cambio de tipo de guardado
                    ObjectAnimator transAnimation= ObjectAnimator.ofFloat(btnOpc1, "translationX", metrics.widthPixels, 0);
                    transAnimation.setDuration(400).start();
                    ObjectAnimator transAnimationn= ObjectAnimator.ofFloat(btnOpc2, "translationX", metrics.widthPixels, 0);
                    transAnimationn.setDuration(500).start();
                    ObjectAnimator transAnimationnn= ObjectAnimator.ofFloat(btnOpc3, "translationX", metrics.widthPixels, 0);
                    transAnimationnn.setDuration(600).start();
                    //controla si está activado el guardado manual
                    if(guardadoManual) {
                        //animación de entrada del botón de guardar
                        ObjectAnimator transAnimationnnn = ObjectAnimator.ofFloat(btnOpc4, "translationX", metrics.widthPixels, 0);
                        transAnimationnnn.setDuration(700).start();
                    }
                    //animación del botón para que sea más visual
                    ivOpciones.animate().rotation(ivOpciones.getRotation()+90).setDuration(200);
                }
                break;

            default:
                break;
        }
    }

    /** Método que se encarga de cerrar los menús que no están activos */
    public void cierraMenusNoActivos(){
        //cierra todos los botones activos si estan activos con animaciones
        if(opcionesAtivo) {
            ObjectAnimator transAnimation = ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, metrics.widthPixels);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn = ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, metrics.widthPixels);
            transAnimationn.setDuration(500).start();
            ObjectAnimator transAnimationnn= ObjectAnimator.ofFloat(btnOpc3, "translationX", 0, metrics.widthPixels);
            transAnimationnn.setDuration(600).start();
            ObjectAnimator transAnimationnnn = ObjectAnimator.ofFloat(btnOpc4, "translationX", 0, metrics.widthPixels);
            transAnimationnnn.setDuration(700).start();
            ivOpciones.animate().rotation(ivOpciones.getRotation() - 90).setDuration(200);
        }
        if(timeActivo) {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 0, metrics.heightPixels);
            transAnimatio1.setDuration(400).start();
            ivReloj.setBackgroundResource(R.drawable.reloj);
        }
        if(flechaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", 0, metrics.heightPixels);
            transAnimatio1.setDuration(400).start();
            ivFlecha.setBackgroundResource(R.drawable.flecha);
        }
        if(copaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", 0, metrics.heightPixels);
            transAnimatio1.setDuration(400).start();
            ivCopa.setBackgroundResource(R.drawable.copa);
        }
        if(camconActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", 0, -metrics.heightPixels);
            transAnimatio1.setDuration(400).start();
            camconActivo=false;
        }
    }

    //endregion

    //region ON CLICKS OPCIONES

    /** Se ejecuta al pulsar en la opción de cambiar la contraseña */
    public void cambioContrasena(View v){
        //hace visible el layout del cambio de contraseña
        lycamcon.setVisibility(View.VISIBLE);
        //controla si está activo el menú de cambio de contraseña
        if(camconActivo){
            //desactiva el menú
            camconActivo=false;
            //animación para desaparecer el menú
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", 0, -metrics.heightPixels);
            transAnimatio1.setDuration(400).start();
            //si lo escrito en los campos de texto de contraseña actual y nueva es lo mismo
            if(passwordact.getText().toString().equals(passwordnew.getText().toString())){
                //según el idioma escribe el mensaje de aviso en el correspondiente
                if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                    Toast.makeText(this, getString(R.string.BothSamesSp), Toast.LENGTH_SHORT).show();
                if(LoginActivity.Idioma.equals(getString(R.string.En)))
                    Toast.makeText(this, getString(R.string.BothSamesEn), Toast.LENGTH_SHORT).show();
            }
            else{
                //controla si la contraseña actual coincide con la contraseña introducida en el campo contraseña actual
                if(passwordact.getText().toString().equals(LoginActivity.user.getPassword())){
                    //crea una referencia a la base de datos en la parte de la contraseña del usuario
                    DatabaseReference a = LoginActivity.database.getReference("users").child(LoginActivity.user.getName()).child("password");
                    //añade la contraseña añadida en el campo de contraseña actual en la base de datos
                    a.setValue(passwordnew.getText().toString());
                    //añade la contraseña añadida en el campo de contraseña actual en la instancia del usuario
                    LoginActivity.user.setPassword(passwordnew.getText().toString());
                    //según el idioma escribe el mensaje de aviso en el correspondiente
                    if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                        Toast.makeText(getApplicationContext(),getString(R.string.UpdatedPasswordSp),Toast.LENGTH_SHORT).show();
                    if(LoginActivity.Idioma.equals(getString(R.string.En)))
                        Toast.makeText(getApplicationContext(),getString(R.string.UpdatedPasswordEn),Toast.LENGTH_SHORT).show();
                }
                else{
                    //según el idioma escribe el mensaje de aviso en el correspondiente
                    if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                        Toast.makeText(getApplicationContext(),getString(R.string.CPNoMatchSp),Toast.LENGTH_SHORT).show();
                    if(LoginActivity.Idioma.equals(getString(R.string.En)))
                        Toast.makeText(getApplicationContext(),getString(R.string.CPNoMatchEn),Toast.LENGTH_SHORT).show();
                }
            }
        }
        else{
            //activa el estado de cambio de contaseña
            camconActivo=true;
            //desactiva el estado de las opciones
            opcionesAtivo = false;
            //animaciones para desaparecer los botones del menú de opciones
            ObjectAnimator transAnimation = ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, metrics.widthPixels);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn = ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, metrics.widthPixels);
            transAnimationn.setDuration(500).start();
            ObjectAnimator transAnimationnn = ObjectAnimator.ofFloat(btnOpc3, "translationX", 0, metrics.widthPixels);
            transAnimationnn.setDuration(600).start();
            ObjectAnimator transAnimationnnn = ObjectAnimator.ofFloat(btnOpc4, "translationX", 0, metrics.widthPixels);
            transAnimationnnn.setDuration(700).start();
            //animación que hace aparecer el menú de cambio de contraseña
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", -metrics.heightPixels, 0);
            transAnimatio1.setDuration(600).start();
            //anima el botón de opciones para hacerlo más visual
            ivOpciones.animate().rotation(ivOpciones.getRotation() - 90).setDuration(200);
            //vacía los campos de texto de los textos editables del layout del cambio de contraseña
            passwordact.setText("");
            passwordnew.setText("");
        }
    }

    /** Se ejecuta al pulsar en la opción de salir de la cuenta */
    public void salirOnClick(View v){
        //crea un cuadro de diálogo en la pantalla actual
        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        //controla si el idioma es Español
        if(LoginActivity.Idioma.equals(getString(R.string.Sp))) {
            //adecua el mensaje de aviso al idioma especificado
            dialogo1.setTitle(R.string.ImportantSp);
            dialogo1.setMessage(R.string.WantSkipSp);
            //hace que no sea cancelable el mensaje a traves de otra cosa que no sean los botones de ésta
            dialogo1.setCancelable(true);
            //añade un botón que activa positivamente el mensaje anterior
            dialogo1.setPositiveButton(R.string.ConfirmSp, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    //termina el AsyncTask
                    tarea2.seguir = false;
                    //Cambia de pantalla a la de inicio terminando la ejecución de ésta
                    Intent empezar = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(empezar);
                    finish();
                }
            });
            //añade un botón que activa negativamente el mensaje anterior
            dialogo1.setNegativeButton(R.string.CancelSp, new DialogInterface.OnClickListener() {public void onClick(DialogInterface dialogo1, int id) {}});
        }
        //controla si el idioma es Inglés
        if(LoginActivity.Idioma.equals(getString(R.string.En))) {
            //adecua el mensaje de aviso al idioma especificado
            dialogo1.setTitle(R.string.ImportantEn);
            dialogo1.setMessage(R.string.WantSkipEn);
            //hace que no sea cancelable el mensaje a traves de otra cosa que no sean los botones de ésta
            dialogo1.setCancelable(true);
            //añade un botón que activa positivamente el mensaje anterior
            dialogo1.setPositiveButton(R.string.ConfirmEn, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    //termina el AsyncTask
                    tarea2.seguir = false;
                    //Cambia de pantalla a la de inicio terminando la ejecución de ésta
                    Intent empezar = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(empezar);
                    finish();
                }
            });
            //añade un botón que activa negativamente el mensaje anterior
            dialogo1.setNegativeButton(R.string.CancelEn, new DialogInterface.OnClickListener() {public void onClick(DialogInterface dialogo1, int id) {}});
        }
        //muestra el cuadro de diálogo
        dialogo1.show();
    }

    /** Se ejecuta al pulsar en la opción de cambiar tipo de guardado*/
    public void changeSaveOnClick(View v){
        //controla si el guardado manual está activo
        if(guardadoManual){
            //desactiva el guardado manual
            guardadoManual=false;
            //activa el guardado en el asyctask
            tarea2.guardado = true;
            //según el idioma escribe el mensaje de aviso en el correspondiente
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                txtAviso.setText(R.string.AutoSaveSp);
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                txtAviso.setText(R.string.AutoSaveEn);
            //animación para el botón de guardar
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(btnOpc4, "translationY", 0, metrics.heightPixels);
            transAnimatio1.setDuration(400).start();
        }
        else{
            //activa el guardado manual
            guardadoManual=true;
            //desactiva el guardado en el asyctask
            tarea2.guardado = false;
            //según el idioma escribe el mensaje de aviso en el correspondiente
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                txtAviso.setText(R.string.ManualSaveSp);
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                txtAviso.setText(R.string.ManualSaveEn);
            //animación para el botón de guardar
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(btnOpc4, "translationY", metrics.heightPixels, 0);
            transAnimatio1.setDuration(400).start();
        }
        //animación para que el aviso sea más visible
        ObjectAnimator transAnimation = ObjectAnimator.ofFloat(txtAviso, "translationX", -metrics.widthPixels, 0);
        transAnimation.setDuration(500).start();
        //activa hilos secundarios en los tiempos especificados
        hadler.postDelayed(runneableEscondeAviso,1000);
        hadler.postDelayed(runneableReinicioAvisos,1300);
        //desactiva el botón hasta que uno de los hilos secundarios lo active de nuevo
        v.setEnabled(false);
    }

    /** Se ejecuta al pulsar en la opción de guardar */
    public void save(View v){
        //añade en la base de datos el usuario actual
        bd.setValue(LoginActivity.user);
        //Inicializa una varible con el tiempo actual
        ParraDate date = new ParraDate();
        //controla si las fechas tienen algún campo diferente
        if(date.getYear()!=LoginActivity.user.getDate().getYear() || date.getDay()!=LoginActivity.user.getDate().getDay() || date.getHour()!=LoginActivity.user.getDate().getHour() || date.getMinute()!=LoginActivity.user.getDate().getMinute()){
            //guarda los datos de la fecha actual en la Base de Datos
            bd.child("date").setValue(date);
            //actualiza la nueva fecha en el usuario
            LoginActivity.user.getDate().setYear(date.getYear());
            LoginActivity.user.getDate().setDay(date.getDay());
            LoginActivity.user.getDate().setHour(date.getHour());
            LoginActivity.user.getDate().setMinute(date.getMinute());
        }
        //según el idioma escribe el mensaje de aviso en el correspondiente
        if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
            txtAviso.setText(R.string.SavedSp);
        if(LoginActivity.Idioma.equals(getString(R.string.En)))
            txtAviso.setText(R.string.SavedEn);
        //animación para que el aviso destaque más
        ObjectAnimator transAnimation = ObjectAnimator.ofFloat(txtAviso, "translationX", -metrics.widthPixels, 0);
        transAnimation.setDuration(500).start();
        //ejecuta los hilos secuandarios que se ejecutarán en el tiempo especificado
        hadler.postDelayed(runneableEscondeAviso,1000);
        hadler.postDelayed(runneableReinicioAvisos,1300);
        //desactiva el botón hasta que se vuelva a activar en un hilo secuandario
        v.setEnabled(false);
    }

    //endregion

    //region ON CLICKS MEJORAS

    /** Se ejecuta cuando pulsas la mejora de daño inactivo */
    @SuppressLint("SetTextI18n")
    public void damageOnClick(View v){
        //controla si tienes suficiente oro como para comprar la mejora  y que el daño no supere la vida del cofre
        if(LoginActivity.user.getScore()>=precioDamage && LoginActivity.user.getDamage() < vidaChest) {
            //resta lo que cuesta la mejora a tu oro
            LoginActivity.user.setScore(LoginActivity.user.getScore() - precioDamage);
            //muestra tu oro actual
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            //actualiza el daño del usuario
            LoginActivity.user.setDamage(LoginActivity.user.getDamage() + 1);
            //actualiza la cantidad de mejoras que tienes actualmente
            txtDAct.setText("Act: " + LoginActivity.user.getDamage());
            //actualiza el nuevo precio de la mejora
            precioDamage = CalculoPrecioDamage();
            //según el idioma escribe el mensaje del coste en el correspondiente
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                btnMDamage.setText(getString(R.string.CostSp) +": "+precioDamage);
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                btnMDamage.setText(getString(R.string.CostEn) +": "+precioDamage);
        }
    }

    /** Se ejecuta cuando pulsas la mejora de velocidad */
    @SuppressLint("SetTextI18n")
    public void speedOnClick(View v){
        //controla si tienes suficiente oro como para comprar la mejora y  que la velocidad no sobrepase el límite establecido
        if(LoginActivity.user.getScore()>=precioSpeed && LoginActivity.user.getSpeed()>500) {
            //resta lo que cuesta la mejora a tu oro
            LoginActivity.user.setScore(LoginActivity.user.getScore() - precioSpeed);
            //muestra tu oro actual
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            //actualiza la velocidad del usuario
            LoginActivity.user.setSpeed(LoginActivity.user.getSpeed() - 10);
            //actualiza la cantidad de mejoras que tienes actualmente
            txtSAct.setText("Act: " + LoginActivity.user.getSpeed());
            //actualiza el nuevo precio de la mejora
            precioSpeed = CalculoPrecioSpeed();
            //según el idioma escribe el mensaje del coste en el correspondiente
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                btnMSpeed.setText(getString(R.string.CostSp) +": "+precioSpeed);
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                btnMSpeed.setText(getString(R.string.CostEn) +": "+precioSpeed);
        }
    }

    /** Se ejecuta cuando pulsas la mejora de capacidad */
    @SuppressLint("SetTextI18n")
    public void capacityOnClick(View v){
        //controla si tienes suficiente oro como para comprar la mejora
        if(LoginActivity.user.getScore()>=precioCapacity) {
            //controla si el idioma es Español
            if(LoginActivity.Idioma.equals(getString(R.string.Sp))) {
                //creación de un cuadro de diálogo
                AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
                //rellena los textos del cuadro de diálogo con los textos correspondientes
                dialogo1.setTitle(getString(R.string.DialogCapacity1Sp));
                dialogo1.setMessage(getString(R.string.DialogCapacity2Sp) + " " + LoginActivity.user.getCapacity() / 20 + " " + getString(R.string.DialogCapacity3Sp) + " " + LoginActivity.user.getCapacity() / 100 + ".");
                //hace que no se pueda cancelar
                dialogo1.setCancelable(false);
                //crea un botón que ejecuta positivamente el mensaje especificado
                dialogo1.setPositiveButton(getString(R.string.ConfirmSp), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo1, int id) {
                        //actualiza la capacidad del usuario
                        LoginActivity.user.setCapacity(LoginActivity.user.getCapacity() + (LoginActivity.user.getCapacity() / 2));
                        //actualiza la cantidad de mejoras que tienes actualmente
                        txtCAct.setText("Act: " + LoginActivity.user.getCapacity());
                        //resta lo que cuesta la mejora a tu oro
                        LoginActivity.user.setScore(LoginActivity.user.getScore() - precioCapacity);
                        //muestra tu oro actual
                        txtScore.setText(LoginActivity.user.getScore() + " / " + LoginActivity.user.getCapacity());
                        //actualiza el nuevo precio de la mejora
                        precioCapacity = CalculoPrecioCapacity();
                        //escribe el mensaje del coste
                        btnMCapacity.setText(getString(R.string.CostSp) + ": " + precioCapacity);
                        //actualiza la vida del cofre
                        vidaChest = Math.round(LoginActivity.user.getCapacity() / 10f);
                        //actualiza el oro a obtener por cada cofre
                        oro = (vidaChest / 5) + 1;
                        //actualiza la nueva suma de la siguiente mejora
                        txtMCapacitySuma.setText("+ " + LoginActivity.user.getCapacity() / 2);
                    }
                });
                //crea un botón que ejecuta negativamente el mensaje especificado
                dialogo1.setNegativeButton(getString(R.string.CancelSp), new DialogInterface.OnClickListener() {public void onClick(DialogInterface dialogo1, int id) { }});
                //muestra el cuadro de diálogo
                dialogo1.show();
            }
            //controla si el idioma es Inglés
            if(LoginActivity.Idioma.equals(getString(R.string.En))) {
                AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
                dialogo1.setTitle(getString(R.string.DialogCapacity1En));
                dialogo1.setMessage(getString(R.string.DialogCapacity2En) + " " + LoginActivity.user.getCapacity() / 20 + " " + getString(R.string.DialogCapacity3En) + " " + LoginActivity.user.getCapacity() / 100 + ".");
                dialogo1.setCancelable(false);
                dialogo1.setPositiveButton(getString(R.string.ConfirmEn), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo1, int id) {
                        //actualiza la capacidad del usuario
                        LoginActivity.user.setCapacity(LoginActivity.user.getCapacity() + (LoginActivity.user.getCapacity() / 2));
                        //actualiza la cantidad de mejoras que tienes actualmente
                        txtCAct.setText("Act: " + LoginActivity.user.getCapacity());
                        //resta lo que cuesta la mejora a tu oro
                        LoginActivity.user.setScore(LoginActivity.user.getScore() - precioCapacity);
                        //muestra tu oro actual
                        txtScore.setText(LoginActivity.user.getScore() + " / " + LoginActivity.user.getCapacity());
                        precioCapacity = CalculoPrecioCapacity();
                        btnMCapacity.setText(getString(R.string.CostEn) + ": " + precioCapacity);
                        vidaChest = Math.round(LoginActivity.user.getCapacity() / 10f);
                        oro = (vidaChest / 5) + 1;
                        txtMCapacitySuma.setText("+ " + LoginActivity.user.getCapacity() / 2);
                    }
                });
                dialogo1.setNegativeButton(getString(R.string.CancelEn), new DialogInterface.OnClickListener() {public void onClick(DialogInterface dialogo1, int id) { }});
                //muestra el cuadro de diálogo
                dialogo1.show();
            }
        }
    }

    /** Se ejecuta cuando pulsas la mejora de daño de click */
    @SuppressLint("SetTextI18n")
    public void ClickdamageOnClick(View v){
        if(LoginActivity.user.getScore()>=precioClickDamage && LoginActivity.user.getClickDamage()<vidaChest) {
            LoginActivity.user.setClickDamage(LoginActivity.user.getClickDamage() + 1);
            txtCDAct.setText("Act: " + LoginActivity.user.getClickDamage());
            LoginActivity.user.setScore(LoginActivity.user.getScore()-precioClickDamage);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            precioClickDamage = CalculoPrecioClickDamage();
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                btnMClickDamage.setText(getString(R.string.CostSp) +": "+precioClickDamage);
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                btnMClickDamage.setText(getString(R.string.CostEn) +": "+precioClickDamage);
        }
    }

    /** Se ejecuta cuando pulsas la mejora de oro inactivo */
    @SuppressLint("SetTextI18n")
    public void GoldInactiveOnClick(View v){
        if(LoginActivity.user.getScore()>=precioGoldInactive) {
            LoginActivity.user.setDpsInactive(LoginActivity.user.getDpsInactive() + 1);
            txtGIAct.setText("Act: " + LoginActivity.user.getDpsInactive());
            LoginActivity.user.setScore(LoginActivity.user.getScore()-precioGoldInactive);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            precioGoldInactive= CalculoPrecioGoldInactive();
            if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                btnMGoldInactive.setText(getString(R.string.CostSp) +": "+precioGoldInactive);
            if(LoginActivity.Idioma.equals(getString(R.string.En)))
                btnMGoldInactive.setText(getString(R.string.CostEn) +": "+precioGoldInactive);
        }
    }

    //endregion

    //region CONTROL SALIDA DE LA APP
    private static final int INTERVALO = 2000; //2 segundos para salir
    private long tiempoPrimerClick;

    @Override
    public void onBackPressed(){
        if(opcionesAtivo || timeActivo || flechaActivo || copaActivo || camconActivo) {
            cierraMenusNoActivos();
            opcionesAtivo = false;
            timeActivo = false;
            flechaActivo = false;
            copaActivo = false;
        }
        else{
            if (tiempoPrimerClick + INTERVALO > System.currentTimeMillis()) {
                super.onBackPressed();
                finish();
                tarea2.seguir = false;
                return;
            } else {
                if(LoginActivity.Idioma.equals(getString(R.string.Sp)))
                    Toast.makeText(this, getString(R.string.OneMoreSkipSp), Toast.LENGTH_SHORT).show();
                if(LoginActivity.Idioma.equals(getString(R.string.En)))
                    Toast.makeText(this, getString(R.string.OneMoreSkipEn), Toast.LENGTH_SHORT).show();
            }
            tiempoPrimerClick = System.currentTimeMillis();
        }
    }
    //endregion
}
