package com.example.parra.clickerroyale;

import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;

public class LoginActivity extends AppCompatActivity {

    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    final DatabaseReference dbUsers = database.getReference("users");

    static User user;

    //campos de texto
    private static EditText txtName;
    private static EditText txtPassword;
    private EditText txtRPassword;

    //botones
    private Button btnRegister;
    private Button btnLogin;

    //cosas para la animacion
    RelativeLayout rellay1,rellay2;
    Handler hadler = new Handler();
    Runnable runneable = new Runnable() {
        @Override
        public void run() {
            rellay1.setVisibility(View.VISIBLE);
            rellay2.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        rellay1 = (RelativeLayout) findViewById(R.id.rellay1);
        rellay2 = (RelativeLayout) findViewById(R.id.rellay2);

        hadler.postDelayed(runneable,2000);

        //conectamos los elementos con su id en la activity
        txtName = (EditText) findViewById(R.id.etName);
        txtPassword = (EditText) findViewById(R.id.etPassword);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnLogin = (Button) findViewById(R.id.btnLogin);
    }

    public void login(View v){
        if(txtName.getText().toString().equals("") || txtName.getText().toString().length() > 20 || txtPassword.getText().toString().length() > 20){
            Toast mal = Toast.makeText(getApplicationContext(), "error de login", Toast.LENGTH_SHORT);
            mal.setGravity(Gravity.TOP, 0, 0);
            mal.show();
        }
        else{
            Query existeNombre = database.getReference("users").orderByKey().equalTo(txtName.getText().toString());

            existeNombre.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if ((dataSnapshot.getValue()) != null) {
                        user = dataSnapshot.child(LoginActivity.getTxtName().getText().toString()).getValue(User.class);
                        if(LoginActivity.getTxtPassword().getText().toString().equals(user.getPassword())){
                            Intent i = new Intent(getApplicationContext(),Clicker.class);
                            startActivity(i);
                            finish();
                        }
                        else{
                            Toast nocoincide = Toast.makeText(getApplicationContext(), "no coincide la contraseña", Toast.LENGTH_SHORT);
                            nocoincide.setGravity(Gravity.TOP, 0, 0);
                            nocoincide.show();
                        }
                    }
                    else{
                        Toast nologueado= Toast.makeText(getApplicationContext(),"no está logueado",Toast.LENGTH_SHORT);
                        nologueado.setGravity(Gravity.TOP,0,0);
                        nologueado.show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }
    }

    public void register(View v){


    }

    public static EditText getTxtName() {
        return txtName;
    }

    public static EditText getTxtPassword() {
        return txtPassword;
    }
}
