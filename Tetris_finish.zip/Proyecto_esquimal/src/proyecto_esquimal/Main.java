package proyecto_esquimal;

import java.awt.*;
import javax.swing.*;

public class Main {
    static boolean finnal=false;
    static int altof;
    static int anchof;
    public static void main(String[] args) throws InterruptedException {
        boolean salir=false;
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        altof = screenSize.height * 2 / 3;
        anchof = screenSize.width * 2 / 5;
            JFrame frame = new JFrame("Tetris by Parra");
        do{
            Game game = new Game();
            Game.cs = 0;
            Game.volando=false;
            frame.add(game);
            frame.setVisible(true);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(anchof, altof);
            frame.setLocationRelativeTo(null);
            frame.setResizable(false);
            System.out.println(finnal);
            while (finnal==false){
                game.move();
                game.repaint();
                Thread.sleep(10);
                if(Game.cs==0){
                    Thread.sleep(1000);
                }
                Game.cs++;
            }
            int opcion = JOptionPane.showConfirmDialog(null, "tu puntuación es de: "+game.puntaje+"\n¿Desea continuar?","Game Over", JOptionPane.YES_NO_OPTION);
            if(opcion==JOptionPane.NO_OPTION){
                salir=true;
            }
            if(opcion==JOptionPane.YES_OPTION){
                salir=false;
            }
            frame.setVisible(false);
            frame.remove(game);
            frame.dispose();
            finnal=false;
        }while(salir==false);
    }
}