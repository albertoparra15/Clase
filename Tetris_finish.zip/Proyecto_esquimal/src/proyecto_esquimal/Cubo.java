package proyecto_esquimal;

public class Cubo {
    int x=4;
    int y=0;
    public Cubo() {
        if(Game.mapa[x][y]!=' ' || Game.mapa[x+1][y]!=' ' || Game.mapa[x+1][y+1]!=' ' || Game.mapa[x][y+1]!=' ')
            Main.finnal=true;
        Game.mapa[x][y]='x';
        Game.mapa[x+1][y]='x';
        Game.mapa[x+1][y+1]='x';
        Game.mapa[x][y+1]='x';
    }
    void move(){
        if(y<18){
            Game.mapa[x][y]=' ';
            Game.mapa[x+1][y]=' ';
            Game.mapa[x+1][y+1]=' ';
            Game.mapa[x][y+1]=' ';
            y+=1;
            Game.mapa[x][y]='x';
            Game.mapa[x+1][y]='x';
            Game.mapa[x+1][y+1]='x';
            Game.mapa[x][y+1]='x';
        }
    }
    
    void moverX(int numero){
        Game.mapa[x][y]=' ';
        Game.mapa[x+1][y]=' ';
        Game.mapa[x+1][y+1]=' ';
        Game.mapa[x][y+1]=' ';
        x=x+numero;
        Game.mapa[x][y]='x';
        Game.mapa[x+1][y]='x';
        Game.mapa[x+1][y+1]='x';
        Game.mapa[x][y+1]='x';
    }
    
    boolean comprobarRight(){
        if(x<8){
            if(Game.mapa[x+2][y]==' ' && Game.mapa[x+2][y+1]==' '){
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }
    
    boolean comprobarLeft(){
        if(x>0){
            if(Game.mapa[x-1][y]==' ' && Game.mapa[x-1][y+1]==' '){
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }
    
    boolean comprobarDown(){
        if(y<18){
            if(Game.mapa[x][y+2]==' ' && Game.mapa[x+1][y+2]==' '){
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }
    
    void finiquitao(){
        Game.mapa[x][y]='o';
        Game.mapa[x+1][y]='o';
        Game.mapa[x+1][y+1]='o';
        Game.mapa[x][y+1]='o';
        Game.volando=false;
    }
}
