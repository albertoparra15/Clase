package com.example.examen.clicker9000;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Clicker extends AppCompatActivity {

    public static int score;
    public static int dps;
    public static int dpc;
    public static int costeDps;
    public static int costeDpc;
    public static TextView txtScore;
    public static TextView txtDps;
    public static TextView txtDpc;
    public static Button btnDps;
    public static Button btnDpc;
    public static ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);
        imagen= (ImageView) findViewById(R.id.imagen);
        txtScore= (TextView) findViewById(R.id.textoScore);
        txtDps= (TextView) findViewById(R.id.txtDps);
        txtDpc= (TextView) findViewById(R.id.txtDpc);
        btnDps= (Button) findViewById(R.id.dpsBtn);
        btnDpc= (Button) findViewById(R.id.dpcBtn);

        Query score = Login.database.getReference("users").child(Login._name).child("score");
        score.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Clicker.score= (int) (long) dataSnapshot.getValue();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.score=0;
            }
        });
        Query dps = Login.database.getReference("users").child(Login._name).child("dps");
        dps.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Clicker.dps= (int) (long) dataSnapshot.getValue();
                costeDps=(Clicker.dps+1)*10;
                txtDps.setText("Dps: "+Clicker.dps);
                btnDps.setText("coste: "+costeDps);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.dps=0;
            }
        });
        Query dpc = Login.database.getReference("users").child(Login._name).child("dpc");
        dpc.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Clicker.dpc= (int) (long) dataSnapshot.getValue();
                costeDpc=(Clicker.dpc)*10;
                txtDpc.setText("Dpc: "+Clicker.dpc);
                btnDpc.setText("coste: "+costeDpc);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.dpc=1;
            }
        });


        MiTareaAsincronaDialog tarea2 = new MiTareaAsincronaDialog();
        tarea2.execute();

    }

    public void guardarOnClick(View v){

        DatabaseReference refName = Login.database.getReference("users").child(Login._name);

        DatabaseReference password = refName.child("password");
        password.setValue(Login._password);

        DatabaseReference dpsdb = refName.child("dps");
        dpsdb.setValue(dps);

        DatabaseReference dpcdb = refName.child("dpc");
        dpcdb.setValue(dpc);

        DatabaseReference scoredb = refName.child("score");
        scoredb.setValue(score);
    }

    public void dpsOnClick(View v){
        if(score>=costeDps){
            score-=costeDps;
            costeDps+=10;
            btnDps.setText("coste: "+costeDps);
            dps++;
            txtDps.setText("Dps: "+dps);
        }
    }

    public void dpcOnClick(View v){
        if(score>=costeDpc){
            score-=costeDpc;
            costeDpc+=10;
            btnDpc.setText("coste: "+costeDpc);
            dpc++;
            txtDpc.setText("Dpc: "+dpc);
        }
    }

    public void giraOnClick(View v){
        score+=dpc;
        imagen.animate().rotation(imagen.getRotation()-5).setDuration(200);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop(){
        super.onStop();
    }

}
