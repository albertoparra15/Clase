package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    static final DatabaseReference dbUsers = database.getReference("users");

    static User user;
    static User[] leaderboard=new User[5];

    //campos de texto
    private static EditText txtName;
    private static EditText txtPassword;
    private TextView txtLogin;

    //botones
    private Button btnRegister;
    private Button btnLogin;

    //cosas para la animacion
    RelativeLayout rellay1,rellay2;
    Handler hadler = new Handler();
    Runnable runneable = new Runnable() {
        @Override
        public void run() {
            rellay1.setVisibility(View.VISIBLE);
            rellay2.setVisibility(View.VISIBLE);
        }
    };

    //controladores
    boolean registerAct=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        rellay1 = (RelativeLayout) findViewById(R.id.rellay1);
        rellay2 = (RelativeLayout) findViewById(R.id.rellay2);

        hadler.postDelayed(runneable,2000);

        //conectamos los elementos con su id en la activity
        txtName = (EditText) findViewById(R.id.etName);
        txtPassword = (EditText) findViewById(R.id.etPassword);
        btnRegister = (Button) findViewById(R.id.btnToRegister);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        txtLogin = (TextView) findViewById(R.id.txtLogin);
    }

    public void loginAndRegister(View v){
        //acción del boton de registrar
        if(registerAct){
            if(txtName.getText().toString().equals("") || txtName.getText().toString().length() > 20 || txtPassword.getText().toString().length() > 20) {
                Toast mal = Toast.makeText(getApplicationContext(), "error de registro", Toast.LENGTH_SHORT);
                mal.setGravity(Gravity.TOP, 0, 0);
                mal.show();
            }
            else {

                Query noRepetido = dbUsers.orderByKey().equalTo(txtName.getText().toString());

                noRepetido.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                        if((dataSnapshot.getValue())==null){

                            DatabaseReference refName = dbUsers.child(txtName.getText().toString());
                            user = new User(txtName.getText().toString(),txtPassword.getText().toString());
                            refName.setValue(user);

                            Toast registrado= Toast.makeText(getApplicationContext(),"registrado",Toast.LENGTH_SHORT);
                            registrado.setGravity(Gravity.TOP,0,540);
                            registrado.show();
                        }
                        else{
                            Toast noregistrado= Toast.makeText(getApplicationContext(),"ya existe ese usuario",Toast.LENGTH_SHORT);
                            noregistrado.setGravity(Gravity.TOP,0,540);
                            noregistrado.show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }
        }
        //acción del boton Login
        else{
            if(txtName.getText().toString().equals("") || txtName.getText().toString().length() > 20 || txtPassword.getText().toString().length() > 20){
                Toast mal = Toast.makeText(getApplicationContext(), "error de login", Toast.LENGTH_SHORT);
                mal.setGravity(Gravity.TOP, 0, 0);
                mal.show();
            }
            else {
                Query existeNombre = database.getReference("users").orderByKey().equalTo(txtName.getText().toString());

                existeNombre.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if ((dataSnapshot.getValue()) != null) {

                            if (LoginActivity.getTxtPassword().getText().toString().equals(txtPassword.getText().toString())) {
                                user = dataSnapshot.child(LoginActivity.getTxtName().getText().toString()).getValue(User.class);
                                creacionLeaderboard();
                                Intent i = new Intent(getApplicationContext(), Clicker.class);
                                startActivity(i);
                                finish();
                            } else {
                                Toast nocoincide = Toast.makeText(getApplicationContext(), "no coincide la contraseña", Toast.LENGTH_SHORT);
                                nocoincide.setGravity(Gravity.TOP, 0, 0);
                                nocoincide.show();
                            }
                        } else {
                            Toast nologueado = Toast.makeText(getApplicationContext(), "no está logueado", Toast.LENGTH_SHORT);
                            nologueado.setGravity(Gravity.TOP, 0, 0);
                            nologueado.show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }
        }
    }

    public void toLoginAndToRegister(View v){
        btnRegister.setEnabled(false);
        //Para pasar a pantalla de Login con una animación
        if(registerAct){
            ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(rellay1, "translationX", 0, -1000);
            ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(rellay1, "translationX", 1000, 0);
            ObjectAnimator transAnimationZ = ObjectAnimator.ofFloat(btnRegister, "translationX", 470, 0);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playSequentially(transAnimationX, transAnimationY);
            animSetXY.setDuration(500).start();
            transAnimationZ.setDuration(1000).start();
            Runnable runneable2 = new Runnable() {
                @Override
                public void run() {
                    btnRegister.setText(R.string.RegisterSp);
                    txtLogin.setText(R.string.LoginSp);
                    btnLogin.setText(R.string.LoginNowSp);
                }
            };
            hadler.postDelayed(runneable2,500);
            registerAct=false;
        }
        //Para pasar a pantalla de Register con una animación
        else {
            ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(rellay1, "translationX", 0, 1000);
            ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(rellay1, "translationX", -1000, 0);
            ObjectAnimator transAnimationZ = ObjectAnimator.ofFloat(btnRegister, "translationX", 0, 470);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playSequentially(transAnimationX, transAnimationY);
            animSetXY.setDuration(500).start();
            transAnimationZ.setDuration(1000).start();
            Runnable runneable2 = new Runnable() {
                @Override
                public void run() {
                    btnRegister.setText(R.string.LoginSp);
                    txtLogin.setText(R.string.RegisterSp);
                    btnLogin.setText(R.string.RegisterNowSp);
                }
            };
            hadler.postDelayed(runneable2,500);
            registerAct=true;
        }
        //espera para darle a el boton el estado activo
        Runnable runneable3 = new Runnable() {
            @Override
            public void run() {
                btnRegister.setEnabled(true);
            }
        };
        hadler.postDelayed(runneable3,1000);
    }

    public static void creacionLeaderboard(){
        //recoge los 5 mejores
        Query lb = database.getReference("users").orderByChild("score").limitToLast(5);
        lb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i=4;
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    leaderboard[i]=ds.getValue(User.class);
                    System.out.println(leaderboard[i].getName());
                    i--;
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    public static EditText getTxtName() {
        return txtName;
    }

    public static EditText getTxtPassword() {
        return txtPassword;
    }
}
