package com.example.parra.clickerroyale;

import com.google.firebase.database.*;

import java.util.ArrayList;

/**
 * The type User.
 */
@IgnoreExtraProperties
@SuppressWarnings("serial")
public class User {

    //region VARIABLES

    private String name;
    private String password;
    private int level;
    private int score;
    private int damage;
    private int speed;
    private int capacity;
    private int clickDamage;
    private int dpsInactive;
    private ParraDate date;

    //endregion

    //region CONSTRUCTORES

    /**
     * Constructor por defecto
     */
    public User() {

    }

    /**
     * Constructor usado para pasarle un usuario y su contraseña y rellenar con valores predeterminados sus demas atributos
     * @param name the name
     *
     * @param password the password
     */
    //Constructor de registro
    public User(String name, String password) {
        this.name = name;
        this.password = password;
        this.level = 1;
        this.score = 0;
        this.damage = 0;
        this.speed = 1000;
        this.capacity = 100;
        this.clickDamage = 1;
        this.dpsInactive = 0;
        this.date = new ParraDate();
    }

    //endregion

    //region GETTERS Y SETTERS

    /**
     * Gets date.
     *
     * @return the date
     */
    public ParraDate getDate() {
        return date;
    }

    /**
     * Sets date.
     *
     * @param date the date
     */
    public void setDate(ParraDate date) {
        this.date = date;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets name.
     *
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets password.
     *
     * @param password the password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets level.
     *
     * @return the level
     */
    public int getLevel() {
        return level;
    }

    /**
     * Sets level.
     *
     * @param level the level
     */
    public void setLevel(int level) {
        this.level = level;
    }

    /**
     * Gets score.
     *
     * @return the score
     */
    public int getScore() {
        return score;
    }

    /**
     * Sets score.
     *
     * @param score the score
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Gets damage.
     *
     * @return the damage
     */
    public int getDamage() {
        return damage;
    }

    /**
     * Sets damage.
     *
     * @param damage the damage
     */
    public void setDamage(int damage) {
        this.damage = damage;
    }

    /**
     * Gets speed.
     *
     * @return the speed
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * Sets speed.
     *
     * @param speed the speed
     */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    /**
     * Gets capacity.
     *
     * @return the capacity
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * Sets capacity.
     *
     * @param capacity the capacity
     */
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    /**
     * Gets click damage.
     *
     * @return the click damage
     */
    public int getClickDamage() {
        return clickDamage;
    }

    /**
     * Sets click damage.
     *
     * @param clickDamage the click damage
     */
    public void setClickDamage(int clickDamage) {
        this.clickDamage = clickDamage;
    }

    /**
     * Gets dps inactive.
     *
     * @return the dps inactive
     */
    public int getDpsInactive() {
        return dpsInactive;
    }

    /**
     * Sets dps inactive.
     *
     * @param dpsInactive the dps inactive
     */
    public void setDpsInactive(int dpsInactive) {
        this.dpsInactive = dpsInactive;
    }

    //endregion
}
