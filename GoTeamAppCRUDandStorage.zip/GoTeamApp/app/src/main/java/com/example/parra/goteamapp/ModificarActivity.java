package com.example.parra.goteamapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.util.Dictionary;

public class ModificarActivity extends AppCompatActivity {
    EditText mnombreET;
    RatingBar mnivelRB;
    Button modify, mexit;
    Bundle extras;
    Users user;
    ImageView image;
    Uri imageUri;
    private static final int PICK_IMAGE = 100;
    byte[] imageArray;
    boolean cambiaImagen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(ModificarActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
        }

        extras=getIntent().getExtras();
        user = new Users(extras.getString("nombre"), Integer.parseInt(extras.getString("nivel")));

        mnivelRB = (RatingBar) findViewById(R.id.mnivelrb);
        mnivelRB.setRating(user.getNivel());
        mnombreET = (EditText) findViewById(R.id.mnombreet);
        mnombreET.setText(user.getNombre());
        image= (ImageView) findViewById(R.id.mimage);
        image.setImageBitmap(UsersCRUD.avatar);
        CargaActivity.crud.obtenerImagen(user.getNombre(), image);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        modify = (Button) findViewById(R.id.modifybtn);
        mexit = (Button) findViewById(R.id.exitmbtn);
    }

    private void openGallery(){
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == RESULT_OK && requestCode == PICK_IMAGE){
            cambiaImagen = true;
            imageUri = data.getData();
            image.setImageURI(imageUri);
            Bitmap bitmap = ((BitmapDrawable) image.getDrawable()).getBitmap();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            imageArray = baos.toByteArray();
        }
    }

    public void modifyOnClick(View v){
        boolean bien = true;
        for (Users us : UsersCRUD.users) {
            if (us.getNombre().equals(mnombreET.getText() + "") && !us.getNombre().equals(user.getNombre())) {
                bien = false;
                break;
            }
        }
        if (bien) {
            Users u = new Users(mnombreET.getText() + "", (int) mnivelRB.getRating());
            CargaActivity.crud.actualizarUsuario(user, u);
            if(cambiaImagen)
                CargaActivity.crud.subirImagen(imageArray, mnombreET.getText() + "");

            Toast t = Toast.makeText(v.getContext(),mnombreET.getText()+ " ha sido modificado con éxito", Toast.LENGTH_SHORT);
            t.show();

            Intent i = new Intent(v.getContext(), UsersActivity.class);
            UsersActivity.recycler.swapAdapter(UsersActivity.adapter,true);
            finish();
        }
        else{
            Toast t = Toast.makeText(v.getContext(),mnombreET.getText()+ " ya existe", Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void mexit(View v){
        Intent i = new Intent(v.getContext(), UsersActivity.class);
        UsersActivity.recycler.swapAdapter(UsersActivity.adapter,true);
        finish();
    }
}
