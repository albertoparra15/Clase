package com.games.juegoparalelo;

import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static int score;
    public static int dps;

    MotorJuego motor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        score=0;
        dps=0;


        //Obtenemos la pantalla del dispositivo
        Display pantalla = getWindowManager().getDefaultDisplay();

        //Cargar la resolución a un objeto Point.
        Point resolucion = new Point();
        pantalla.getSize(resolucion);

        //Se crea una instancia del motor de Juego pasándole el tamaño de la pantalla.
        //Se inicia el juego y se establece como el ContentView de la actividad. Esto sustituye al MainLayout típico. Podemos hacerlo porque la clase MotorJuego hereda de SurfaceView.
        motor = new MotorJuego(this, resolucion.x, resolucion.y);

    }

    public void dpsOnClick(View v){
        dps++;
    }

    @Override
    protected void onStart() {
        super.onStart();
        System.out.println("se llama a onStart()");
    }

    //Se sobreescribe el método onResume de esta activity para controlar lo que sucede con el cambio del ciclo de la actividad
    @Override
    protected void onResume() {
        //Se llama al método onResume de la clase parent de esta clase (CompatActivity)
        super.onResume();
        System.out.println("Se llama a onResume desde la mainActivity");
    }

    //Se sobreescribe el método onStop de esta activity para controlar lo que sucede con el cambio del ciclo de la actividad
    @Override
    protected void onStop(){
        //Se llama al método onStop de la clase parent de esta clase (CompatActivity)
        super.onStop();
        System.out.println("Se llama a onStop desde la mainActivity");
    }

}
