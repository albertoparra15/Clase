package com.example.parra.goteamapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.Dictionary;

public class UsersCRUD{
    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    static final DatabaseReference dbUsers = database.getReference("users");
    static ArrayList<Users> users;

    static final FirebaseStorage storage = FirebaseStorage.getInstance();
    static final StorageReference storageRef = storage.getReference();
    static Bitmap avatar;


    public UsersCRUD() {
        users = new ArrayList<>();
    }

    public void obtenerUsersAndImages() {
        //obtener avatar
        StorageReference avatarRef = storageRef.child("avatar.png");

        final long ONE_MEGABYTE = 1024 * 1024;
        avatarRef.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                avatar = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                System.out.println("se ha descargado correctamente el avatar");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                System.out.println("no se ha descargado el avatar");
            }
        });

        //obtener usuarios
        Query lb = dbUsers.orderByKey();
        lb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i=0;
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    users.add(ds.getValue(Users.class));
                    System.out.println(ds.getValue());
                    i++;
                }
                CargaActivity.t.setText("Cargado");
                CargaActivity.b.setEnabled(true);
                System.out.println("añade los usuarios");
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
        System.out.println("empieza");
    }

    public void crearUser(Users user) {
        //Base de datos
        DatabaseReference refName = dbUsers.child(user.getNombre()+"");
        refName.setValue(user);
        //Array de usuarios
        users.add(user);
    }

    public void subirImagen(byte[] data, String nombre){
        UploadTask uploadTask = storageRef.child(nombre).child("image.png").putBytes(data);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle unsuccessful uploads
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                // ...
            }
        });
    }

    public void obtenerImagen(String nombre, final ImageView image){
        boolean a=true;
        try {
            StorageReference islandRef = storageRef.child(nombre + "/image.png");

            final long ONE_MEGABYTE = 1024 * 1024;
            islandRef.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    image.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length));
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    // Handle any errors
                }
            });
            a=false;
        }
        finally {
        }
    }

    public void actualizarUsuario(Users user, Users modificated) {
        //Base de datos
        if(!user.getNombre().equals(modificated.getNombre())){
            DatabaseReference ref = dbUsers.child(user.getNombre()+"");
            ref.removeValue();
        }
        DatabaseReference refName = dbUsers.child(modificated.getNombre()+"");
        refName.setValue(modificated);
        //Array de usuarios
        for(int i=0; i < users.size(); i++){
            if(users.get(i).getNombre().equals(user.getNombre())){
                users.remove(i);
            }
        }
        users.add(modificated);
    }

    public void eliminarUsuario(int num, String nombre) {
        //Base de datos
        dbUsers.child(nombre).removeValue();
        System.out.println("eliminado");
        //Array de usuarios
        users.remove(num);
    }
}
