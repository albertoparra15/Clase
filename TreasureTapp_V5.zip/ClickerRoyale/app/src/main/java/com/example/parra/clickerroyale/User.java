package com.example.parra.clickerroyale;

public class User {

    //region VARIABLES

    private String name;
    private String password;
    private int score;
    private int damage;
    private int speed;
    private int capacity;
    private int clickDamage;
    private int dpsInactive;
    private ParraDate date;

    //endregion

    //region CONSTRUCTORES

    public User() {

    }

    //Constructor de registro
    User(String name, String password) {
        this.name = name;
        this.password = password;
        this.score = 0;
        this.damage = 0;
        this.speed = 1000;
        this.capacity = 100;
        this.clickDamage = 1;
        this.dpsInactive = 0;
        this.date = new ParraDate();
    }

    //endregion

    //region GETTERS Y SETTERS

    public ParraDate getDate() {
        return date;
    }

    public void setDate(ParraDate date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getClickDamage() {
        return clickDamage;
    }

    public void setClickDamage(int clickDamage) {
        this.clickDamage = clickDamage;
    }

    public int getDpsInactive() {
        return dpsInactive;
    }

    public void setDpsInactive(int dpsInactive) {
        this.dpsInactive = dpsInactive;
    }

    //endregion
}