package com.example.parra.practicaad2trimestreapc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import Modelo.IProductoDao;
import Modelo.ProductoDaoImpl;
import Modelo.Productos;

public class ModifyActivity extends AppCompatActivity {

    IProductoDao productoDao;
    TextView codigo, nombre, fecha, url, descripcion;
    Productos p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        Bundle extras=getIntent().getExtras();
        p = new Productos(Integer.parseInt(extras.getString("codigo")), extras.getString("nombre"), extras.getString("fecha"), extras.getString("url"), extras.getString("descripcion"));

        //objeto para manipular el dao
        productoDao = new ProductoDaoImpl();
        codigo = (TextView) findViewById(R.id.codigo);
        codigo.setText(p.getCodigo()+"");
        nombre = (TextView) findViewById(R.id.nombre);
        nombre.setText(p.getNombre());
        fecha = (TextView) findViewById(R.id.fecha);
        fecha.setText(p.getFecha());
        url = (TextView) findViewById(R.id.url);
        url.setText(p.getUrlImagen());
        descripcion = (TextView) findViewById(R.id.descriptionM);
        descripcion.setText(p.getDescripcion());
    }


    public void BackOnClick(View v){
        volver(v);
    }

    public void OkayOnClick(View v){
        System.out.println("preparando modificado");
        productoDao.actualizarProducto(p,new Productos(Integer.parseInt(codigo.getText().toString()), nombre.getText()+"", fecha.getText()+"", url.getText()+"", descripcion.getText()+""));
        volver(v);
    }

    private void volver(View v){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}
