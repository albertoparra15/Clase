package proyecto_esquimal;

public class Pato {
    int x=5;
    int y=0;
    int posicion=1;
    public Pato() {
        if(Game.mapa[x-1][y+1]!=' ' || Game.mapa[x][y]!=' ' || Game.mapa[x][y+1]!=' ' || Game.mapa[x+1][y]!=' ')
            Main.finnal=true;
        Game.mapa[x-1][y+1]='x';
        Game.mapa[x][y]='x';
        Game.mapa[x][y+1]='x';
        Game.mapa[x+1][y]='x';
    }
    
    void move(){
        switch(posicion){
            case 1:
                if(y<18){
                    Game.mapa[x-1][y+1]=' ';
                    Game.mapa[x][y]=' ';
                    Game.mapa[x][y+1]=' ';
                    Game.mapa[x+1][y]=' ';
                    y+=1;
                    Game.mapa[x-1][y+1]='x';
                    Game.mapa[x][y]='x';
                    Game.mapa[x][y+1]='x';
                    Game.mapa[x+1][y]='x';
                    }
                break;
            case 2:
                if(y<17){
                    Game.mapa[x+1][y+2]=' ';
                    Game.mapa[x][y]=' ';
                    Game.mapa[x][y+1]=' ';
                    Game.mapa[x+1][y+1]=' ';
                    y+=1;
                    Game.mapa[x+1][y+2]='x';
                    Game.mapa[x][y]='x';
                    Game.mapa[x][y+1]='x';
                    Game.mapa[x+1][y+1]='x';
                    }
                break;
                
        }
    }
     void cambioPosicion(){
        switch(posicion){
            case 1:
                Game.mapa[x-1][y+1]=' ';
                Game.mapa[x][y]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x+1][y]=' ';
                Game.mapa[x+1][y+2]='x';
                Game.mapa[x][y]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x+1][y+1]='x';
                posicion=2;
                break;
            case 2:
                Game.mapa[x+1][y+2]=' ';
                Game.mapa[x][y]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x+1][y+1]=' '; 
                Game.mapa[x-1][y+1]='x';
                Game.mapa[x][y]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x+1][y]='x';
                posicion=1;
                break;
        }
    }
    void moverX(int numero){
        switch(posicion){
            case 1:
                Game.mapa[x-1][y+1]=' ';
                Game.mapa[x][y]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x+1][y]=' ';
                x=x+numero;
                Game.mapa[x-1][y+1]='x';
                Game.mapa[x][y]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x+1][y]='x';
                break;
            case 2:
                Game.mapa[x+1][y+2]=' ';
                Game.mapa[x][y]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x+1][y+1]=' ';
                x=x+numero;
                Game.mapa[x+1][y+2]='x';
                Game.mapa[x][y]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x+1][y+1]='x';
                break;
        }
    }
    
    boolean comprobarRight(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(x<8){
                    if(Game.mapa[x+2][y]==' ' && Game.mapa[x+1][y+1]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(x<8){
                    if(Game.mapa[x+1][y]==' ' && Game.mapa[x+2][y+1]==' ' && Game.mapa[x+2][y+2]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    boolean comprobarLeft(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(x>1){
                    if(Game.mapa[x-1][y]==' ' && Game.mapa[x-2][y+1]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(x>0){
                    if(Game.mapa[x-1][y]==' ' && Game.mapa[x-1][y+1]==' ' && Game.mapa[x][y+2]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    boolean comprobarDown(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(y<18){
                    if(Game.mapa[x+1][y+1]==' ' && Game.mapa[x][y+2]==' ' && Game.mapa[x-1][y+2]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(y<17){
                    if(Game.mapa[x][y+2]==' ' && Game.mapa[x+1][y+3]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    boolean comprobarCambio(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(y<18){
                    if(Game.mapa[x+1][y+1]==' ' && Game.mapa[x+1][y+2]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(x<9){
                    if(Game.mapa[x+1][y]==' ' && Game.mapa[x-1][y+1]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    void finiquitao(){
        switch(posicion){
            case 1:
                Game.mapa[x-1][y+1]='o';
                Game.mapa[x][y]='o';
                Game.mapa[x][y+1]='o';
                Game.mapa[x+1][y]='o';
                break;
            case 2:
                Game.mapa[x+1][y+2]='o';
                Game.mapa[x][y]='o';
                Game.mapa[x][y+1]='o';
                Game.mapa[x+1][y+1]='o';
                break;
        }
        Game.volando=false;
    }
}
