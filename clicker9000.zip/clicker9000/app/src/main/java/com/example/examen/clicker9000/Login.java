package com.example.examen.clicker9000;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.lang.ref.Reference;

public class Login extends AppCompatActivity {
    //conexión con la base de datos de Firebase
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    //referencia a usar de la base de datos Firebase
    DatabaseReference ref = database.getReference("users");

    //datos a guardar para la base de datos
    String _name;
    String _password;

    //contenedores del xml
    EditText txtName;
    EditText txtPassword;


    boolean nombrereg=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        txtName = (EditText) findViewById(R.id.txtName);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
    }

    //función que se ejecuta al pulsar el boton de registrar
    public void registerOnClick(View v){
        _name = txtName.getText().toString();
        _password = txtPassword.getText().toString();

        if(_name.equals("")) {}
        else{
            Query q = database.getReference("users").orderByKey().equalTo(_name);
            q.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if((dataSnapshot.getValue())==null){
                        DatabaseReference refName = ref.child(_name).child("password");
                        refName.setValue(_password);
                    }
                    else{
                        System.out.println("ya está creado");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    System.out.println("etohqueeh");
                }
            });
            /*

            */
        }
    }
    //función que se ejecuta al pulsar el boton de login
    public void loginOnClick(View v) throws InterruptedException {
        _name = txtName.getText().toString();
        _password = txtPassword.getText().toString();

        if(_name.equals("")) {}
        else{
            Query q = database.getReference("users").orderByKey().equalTo(_name);


            q.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    System.out.println("1- "+dataSnapshot.getValue());

                    if((dataSnapshot.getValue())==null){
                        Toast nologueado= Toast.makeText(getApplicationContext(),"no está logueado",Toast.LENGTH_SHORT);
                        nologueado.setGravity(Gravity.TOP,0,540);
                        nologueado.show();
                    }
                    else{
                        System.out.println("1.1");
                        nombrereg=true;

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    System.out.println("olqa");
                }
            });
            Thread.sleep(1000);
            System.out.println("2- "+nombrereg+" "+_name);

            if(nombrereg==true) {

                Query p = database.getReference("users").child(_name).child("password");


                p.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        System.out.println("3-");
                        if (dataSnapshot.getValue().equals(_password)) {
                            Toast logueado = Toast.makeText(getApplicationContext(), "logueado", Toast.LENGTH_SHORT);

                            logueado.setGravity(Gravity.TOP, 0, 540);
                            logueado.show();
                            nombrereg=false;
                        } else {
                            Toast nocoincide = Toast.makeText(getApplicationContext(), "no coincide la contraseña", Toast.LENGTH_SHORT);
                            nocoincide.setGravity(Gravity.TOP, 0, 540);
                            nocoincide.show();
                            nombrereg=false;

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            System.out.println("4- "+nombrereg);

        }
    }
}
