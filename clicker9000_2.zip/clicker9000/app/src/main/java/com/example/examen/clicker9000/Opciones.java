package com.example.examen.clicker9000;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Opciones extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opciones);

    }


    public void contrasenaOnClick(View v){
        Intent contrasena = new Intent(getApplicationContext(), CambiarContrasena.class);
        startActivity(contrasena);
    }

    public void salirOnClick(View v){
        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        dialogo1.setTitle("Importante");
        dialogo1.setMessage("¿ Desea salir de esta cuenta ?");
        dialogo1.setCancelable(true);
        dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                Intent empezar = new Intent(getApplicationContext(), Login.class);
                startActivity(empezar);

                finish();
            }
        });
        dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                Intent seguir = new Intent(getApplicationContext(), Clicker.class);
                startActivity(seguir);

                finish();
            }
        });
        dialogo1.show();
    }

    public void volverOnClick(View v){
        Intent volver = new Intent(getApplicationContext(), Clicker.class);
        startActivity(volver);

        finish();
    }


    @Override
    public void onBackPressed(){
        Intent volver = new Intent(getApplicationContext(), Clicker.class);
        startActivity(volver);

        finish();
    }
}
