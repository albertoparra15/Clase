package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Clicker extends AppCompatActivity {

    //vida cofres
    static int vidaChest=10;

    //layout

    //text
    static TextView txtScore;
    static TextView txtVida;

    //imagenes
    ImageView ivOpciones;
    static ImageView ivChest;

    //booleans controladores
    boolean opcionesAtivo=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);

        ivOpciones = (ImageView) findViewById(R.id.ivOpciones);
        ivChest = (ImageView) findViewById(R.id.ivChest);
        txtScore = (TextView) findViewById(R.id.txtScore);
        txtVida = (TextView) findViewById(R.id.txtVida);

        txtScore.setText(LoginActivity.user.getScore()+"");
        txtVida.setText(vidaChest+"");

        ParraAsyncTask tarea2 = new ParraAsyncTask();
        tarea2.execute();
    }

    public void opcionesOnClick(View v) {

/*

        if(opcionesAtivo){
            ObjectAnimator transAnimation= ObjectAnimator.ofFloat(lyOpciones, "translationX", 0, 1000);
            transAnimation.setDuration(500).start();
            opcionesAtivo=false;
            ivOpciones.animate().rotation(ivOpciones.getRotation()-90).setDuration(200);
        }
        else{
            lyOpciones.setVisibility(View.VISIBLE);
            ObjectAnimator transAnimation= ObjectAnimator.ofFloat(lyOpciones, "translationX", 1000, 0);
            transAnimation.setDuration(500).start();
            opcionesAtivo=true;
            ivOpciones.animate().rotation(ivOpciones.getRotation()+90).setDuration(200);
        }*/
    }

    public void chestOnClick(View v){
        vidaChest=vidaChest-LoginActivity.user.getClickDamage();
        if(vidaChest<=0){
            vidaChest=10;
            LoginActivity.user.setScore(LoginActivity.user.getScore()+3);
            txtScore.setText(LoginActivity.user.getScore()+"");
            ObjectAnimator transAnimatio1= ObjectAnimator.ofFloat(txtVida, "translationY", 100, 0);
            transAnimatio1.setDuration(100).start();
            ObjectAnimator transAnimatio2= ObjectAnimator.ofFloat(v, "translationY", -150, 0);
            transAnimatio2.setDuration(100).start();
        }
        else{
            int x = (int) (Math.random()*41)-20;
            int y = 20-Math.abs(x);
            System.out.println(x+" "+y);

            ObjectAnimator transAnimationX= ObjectAnimator.ofFloat(v, "translationX", x, 0);
            ObjectAnimator transAnimationY= ObjectAnimator.ofFloat(v, "translationY", y, 0);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playTogether(transAnimationX, transAnimationY);
            animSetXY.setDuration(300).start();

        }
        txtVida.setText(vidaChest+"");


    }
}
