package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Clicker extends AppCompatActivity implements View.OnClickListener{

    //vida cofres
    static int vidaChest=10;

    //botones
    Button btnOpc1;
    Button btnOpc2;
    Button ivCopa;
    Button ivFlecha;
    Button ivReloj;
    Button ivAmigo;

    //layouts
    View lyTime;
    View lyFlecha;
    View lyAmigos;
    View lyCopa;

    //text
    static TextView txtScore;
    static TextView txtVida;
    TextView txtNombre;

    //imagenes
    ImageView ivOpciones;
    ImageView ivChest;


    //booleans controladores
    boolean opcionesAtivo=false;
    boolean timeActivo=false;
    boolean flechaActivo=false;
    boolean friendsActivo=false;
    boolean copaActivo=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);

        ivOpciones = (ImageView) findViewById(R.id.ivOpciones);
        ivChest = (ImageView) findViewById(R.id.ivChest);
        txtScore = (TextView) findViewById(R.id.txtScore);
        txtVida = (TextView) findViewById(R.id.txtVida);
        txtNombre = (TextView) findViewById(R.id.txtNombre);
        btnOpc1 = (Button) findViewById(R.id.btnOpciones1);
        btnOpc2 = (Button) findViewById(R.id.btnOpciones2);
        lyTime = (View) findViewById(R.id.lyTime);
        lyFlecha = (View) findViewById(R.id.lyFlecha);
        lyAmigos = (View) findViewById(R.id.lyAmigos);
        lyCopa = (View) findViewById(R.id.lyCopa);
        ivReloj = (Button) findViewById(R.id.ivReloj);
        ivFlecha = (Button) findViewById(R.id.ivFlecha);
        ivAmigo = (Button) findViewById(R.id.ivAmigo);
        ivCopa = (Button) findViewById(R.id.ivCopa);

        txtScore.setText(LoginActivity.user.getScore()+"");
        txtVida.setText(vidaChest+"");
        txtNombre.setText(LoginActivity.user.getName()+"");

        ivChest.setOnClickListener(this);
        ivReloj.setOnClickListener(this);
        ivOpciones.setOnClickListener(this);
        ivFlecha.setOnClickListener(this);
        ivAmigo.setOnClickListener(this);
        ivCopa.setOnClickListener(this);

        ParraAsyncTask tarea2 = new ParraAsyncTask();
        tarea2.execute();
    }
    //cierra todos si estan activos
    @Override
    public void onClick(View v) {
        if(opcionesAtivo) {
            ObjectAnimator transAnimation = ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, 1000);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn = ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, 1000);
            transAnimationn.setDuration(500).start();
            ivOpciones.animate().rotation(ivOpciones.getRotation() - 90).setDuration(200);
        }
        if(timeActivo) {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivReloj.setBackgroundResource(R.drawable.reloj);
        }
        if(flechaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivFlecha.setBackgroundResource(R.drawable.flecha);
        }
        if(friendsActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyAmigos, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivAmigo.setBackgroundResource(R.drawable.amigo);
        }
        if(copaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivCopa.setBackgroundResource(R.drawable.copa);
        }

        switch (v.getId()) {

            //accion del boton copa
            case R.id.ivCopa:
                lyCopa.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                flechaActivo=false;
                friendsActivo=false;

                if(copaActivo){
                    copaActivo=false;
                }
                else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivCopa.setBackgroundResource(R.drawable.copaact);
                    copaActivo=true;
                }
                break;

            //accion del boton amigos
            case R.id.ivAmigo:
                lyAmigos.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                flechaActivo=false;
                copaActivo=false;

                if(friendsActivo){
                    friendsActivo=false;
                }
                else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyAmigos, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivAmigo.setBackgroundResource(R.drawable.amigoact);
                    friendsActivo=true;
                }
                break;

            //accion del boton Flecha
            case R.id.ivFlecha:
                lyFlecha.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                friendsActivo=false;
                copaActivo=false;

                if(flechaActivo){
                    flechaActivo=false;
                }else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivFlecha.setBackgroundResource(R.drawable.flechaact);
                    flechaActivo=true;
                }
                break;

            //accion del boton del cofre
            case R.id.ivChest:
                opcionesAtivo=false;
                timeActivo=false;
                flechaActivo=false;
                friendsActivo=false;
                copaActivo=false;

                vidaChest=vidaChest-LoginActivity.user.getClickDamage();
                if(vidaChest<=0){
                    vidaChest=10;
                    LoginActivity.user.setScore(LoginActivity.user.getScore()+3);
                    txtScore.setText(LoginActivity.user.getScore()+"");
                    ObjectAnimator transAnimatio1= ObjectAnimator.ofFloat(txtVida, "translationY", 100, 0);
                    transAnimatio1.setDuration(100).start();
                    ObjectAnimator transAnimatio2= ObjectAnimator.ofFloat(v, "translationY", -150, 0);
                    transAnimatio2.setDuration(100).start();
                }
                else{
                    int x = (int) (Math.random()*41)-20;
                    int y = 20-Math.abs(x);
                    System.out.println(x+" "+y);

                    ObjectAnimator transAnimationX= ObjectAnimator.ofFloat(v, "translationX", x, 0);
                    ObjectAnimator transAnimationY= ObjectAnimator.ofFloat(v, "translationY", y, 0);
                    AnimatorSet animSetXY = new AnimatorSet();
                    animSetXY.playTogether(transAnimationX, transAnimationY);
                    animSetXY.setDuration(300).start();

                }
                txtVida.setText(vidaChest+"");
                break;
            //accion del boton reloj
            case R.id.ivReloj:

                lyTime.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                flechaActivo=false;
                friendsActivo=false;
                copaActivo=false;

                if(timeActivo){
                    timeActivo=false;
                }else {
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivReloj.setBackgroundResource(R.drawable.relojact);
                    timeActivo=true;
                }
                break;

            //accion del boton opciones
            case R.id.ivOpciones:

                btnOpc1.setVisibility(View.VISIBLE);
                btnOpc2.setVisibility(View.VISIBLE);
                timeActivo=false;
                flechaActivo=false;
                friendsActivo=false;
                copaActivo=false;

                if(opcionesAtivo){
                    opcionesAtivo=false;
                }
                else{
                    ObjectAnimator transAnimation= ObjectAnimator.ofFloat(btnOpc1, "translationX", 1000, 0);
                    transAnimation.setDuration(400).start();
                    ObjectAnimator transAnimationn= ObjectAnimator.ofFloat(btnOpc2, "translationX", 1000, 0);
                    transAnimationn.setDuration(500).start();
                    ivOpciones.animate().rotation(ivOpciones.getRotation()+90).setDuration(200);
                    opcionesAtivo=true;
                }
                break;
            default:
                break;
        }
    }


    public void salirOnClick(View v){
        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        dialogo1.setTitle("Importante");
        dialogo1.setMessage("¿ Desea salir de esta cuenta ?");
        dialogo1.setCancelable(true);
        dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                Intent empezar = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(empezar);

                finish();
            }
        });
        dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {}
        });
        dialogo1.show();
    }
}
