package com.example.parra.clickerroyale;

import android.os.AsyncTask;

public class ParraAsyncTask extends AsyncTask<Void, Integer, Boolean> {

    //activadores
    static boolean chestActivo=false;
    boolean speedActivo=false;

    //contadores
    static int contGuardar=-1;
    static int contSpeed=-1;


    @Override
    protected Boolean doInBackground(Void... params) {

        while(true){
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            //controla la velocidad del daño
            if(contSpeed<LoginActivity.user.getSpeed()){
                contSpeed++;
            }
            else{
                speedActivo=true;
                contSpeed=0;
            }


            publishProgress();

            if (isCancelled())
                break;
        }

        return true;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {

        if(speedActivo){

            Clicker.vidaChest=Clicker.vidaChest-LoginActivity.user.getDamage();
            if(Clicker.vidaChest<=0){
                Clicker.vidaChest=10;
                Clicker.txtVida.setText(Clicker.vidaChest+"");
                LoginActivity.user.setScore(LoginActivity.user.getScore()+3);
                Clicker.txtScore.setText(LoginActivity.user.getScore()+"");
            }
            Clicker.txtVida.setText(Clicker.vidaChest+"");
            speedActivo=false;
        }

    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(Boolean result) {
    }

    @Override
    protected void onCancelled() {
    }
}

