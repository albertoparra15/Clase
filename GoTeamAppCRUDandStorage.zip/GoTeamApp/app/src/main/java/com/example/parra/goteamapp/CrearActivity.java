package com.example.parra.goteamapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class CrearActivity extends AppCompatActivity {
    EditText nombreET;
    RatingBar nivelRB;
    Button addContinue, addExit, exit;
    ImageView image;
    Uri imageUri;
    private static final int PICK_IMAGE = 100;
    byte[] imageArray;
    boolean cambiaImagen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear);

        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(CrearActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
        }

        image = (ImageView) findViewById(R.id.image);
        nivelRB = (RatingBar) findViewById(R.id.nivelrb);
        nombreET = (EditText) findViewById(R.id.nombreet);
        addContinue = (Button) findViewById(R.id.addContinuebtn);
        addExit = (Button) findViewById(R.id.addbtn);
        exit = (Button) findViewById(R.id.exitbtn);

        image.setImageBitmap(UsersCRUD.avatar);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });
    }

    private void openGallery(){
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == RESULT_OK && requestCode == PICK_IMAGE){
            cambiaImagen = true;
            imageUri = data.getData();
            image.setImageURI(imageUri);
            Bitmap bitmap = ((BitmapDrawable) image.getDrawable()).getBitmap();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            imageArray = baos.toByteArray();
        }
    }

    public void addAndContinue(View v){
        boolean bien = true;
        if(!(nombreET.getText() + "").equals("")) {
            for (Users user:UsersCRUD.users) {
                if(user.getNombre().equals(nombreET.getText() + "")){
                    bien = false;
                    break;
                }
            }
            if(bien) {

                System.out.println("" + nivelRB.getRating());
                Users u = new Users(nombreET.getText() + "", (int) nivelRB.getRating());
                CargaActivity.crud.crearUser(u);
                if(cambiaImagen)
                    CargaActivity.crud.subirImagen(imageArray, nombreET.getText() + "");

                nombreET.setText("");
                nivelRB.setRating(0);

                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ha sido creado con éxito", Toast.LENGTH_SHORT);
                t.show();
            }
            else{
                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ya existe", Toast.LENGTH_SHORT);
                t.show();
            }
        }
        else{
            Toast t = Toast.makeText(v.getContext()," no has introducido el nombre", Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void addAndExit(View v){
        boolean bien = true;
        if(!(nombreET.getText() + "").equals("")) {
            for (Users user:UsersCRUD.users) {
                if(user.getNombre().equals(nombreET.getText() + "")){
                    bien = false;
                    break;
                }
            }
            if(bien) {

                System.out.println("" + nivelRB.getRating());
                Users u = new Users(nombreET.getText() + "", (int) nivelRB.getRating());
                CargaActivity.crud.crearUser(u);
                if(cambiaImagen)
                    CargaActivity.crud.subirImagen(imageArray, nombreET.getText() + "");

                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ha sido creado con éxito", Toast.LENGTH_SHORT);
                t.show();

                Intent i = new Intent(v.getContext(), UsersActivity.class);
                UsersActivity.recycler.swapAdapter(UsersActivity.adapter,true);
                finish();
            }
            else{
                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ya existe", Toast.LENGTH_SHORT);
                t.show();
            }
        }
        else{
            Toast t = Toast.makeText(v.getContext()," no has introducido el nombre", Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void exit(View v){
        Intent i = new Intent(v.getContext(), UsersActivity.class);
        UsersActivity.recycler.swapAdapter(UsersActivity.adapter,true);
        finish();
    }
}
