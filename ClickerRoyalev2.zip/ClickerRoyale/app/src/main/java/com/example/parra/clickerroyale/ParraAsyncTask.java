package com.example.parra.clickerroyale;

import android.os.AsyncTask;

public class ParraAsyncTask extends AsyncTask<Void, Integer, Boolean> {

    //activadores
    boolean speedActivo=false;

    //contadores
    static int contGuardar=10;
    int i=0;


    @Override
    protected Boolean doInBackground(Void... params) {

        while(true){
            try {
                Thread.sleep(LoginActivity.user.getSpeed());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


            publishProgress();

            if (isCancelled())
                break;
        }

        return true;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {

        Clicker.vidaChest=Clicker.vidaChest-LoginActivity.user.getDamage();
        if(Clicker.vidaChest<=0){
            Clicker.vidaChest=10;
            Clicker.txtVida.setText(Clicker.vidaChest+"");
            LoginActivity.user.setScore(LoginActivity.user.getScore()+3);
            Clicker.txtScore.setText(LoginActivity.user.getScore()+"");
        }
        Clicker.txtVida.setText(Clicker.vidaChest+"");
        speedActivo=false;

    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(Boolean result) {
    }

    @Override
    protected void onCancelled() {
    }
}

