package com.example.parra.chatglobal;

import android.support.annotation.NonNull;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ChatCR {
    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    static final DatabaseReference dbChat = database.getReference("chat");
    static ArrayList<Chat> chats;

    public ChatCR() {
        chats = new ArrayList<>();
    }

    public void obtenerMensajes(){
        Query lb = dbChat.orderByKey();
        lb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    chats.add(ds.getValue(Chat.class));
                }
                if(!LoginActivity.termina) {
                    LoginActivity.entrar.setText("Entrar");
                    LoginActivity.entrar.setEnabled(true);
                }
                else {
                    ChatActivity.mensajetxt.setEnabled(true);
                    ChatActivity.enviar.setEnabled(true);
                    ChatActivity.actualizar.setEnabled(true);
                    ChatActivity.recycler.setAdapter(ChatActivity.adapter);
                }
                System.out.println("añade los chats");
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
        System.out.println("Termina++++++++++++++++++++++");
    }

    public void crearMensaje(Chat chat) {
        //Base de datos
        DatabaseReference refName = dbChat.push();
        refName.setValue(chat);
        //Array de usuarios
        chats.add(chat);
        ChatActivity.recycler.swapAdapter(ChatActivity.adapter, true);
    }
}
