package com.example.parra.goteamapp;

import android.support.annotation.NonNull;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UsersCRUD{
    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    static final DatabaseReference dbUsers = database.getReference("users");
    static ArrayList<Users> users;


    public UsersCRUD() {
        users = new ArrayList<>();
    }

    public void obtenerUsers() {
        Query lb = dbUsers.orderByKey();
        lb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i=0;
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    users.add(ds.getValue(Users.class));
                    System.out.println(ds.getValue());
                    i++;
                }
                CargaActivity.t.setText("Cargado");
                CargaActivity.b.setEnabled(true);
                System.out.println("añade los usuarios");
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
        System.out.println("empieza");
    }

    public void crearProducto(Users user) {
        //Base de datos
        DatabaseReference refName = dbUsers.child(user.getNombre()+"");
        refName.setValue(user);
        //Array de usuarios
        users.add(user);
    }

    public void actualizarUsuario(Users user, Users modificated) {
        //Base de datos
        if(!user.getNombre().equals(modificated.getNombre())){
            DatabaseReference ref = dbUsers.child(user.getNombre()+"");
            ref.removeValue();
        }
        DatabaseReference refName = dbUsers.child(modificated.getNombre()+"");
        refName.setValue(modificated);
        //Array de usuarios
        for(int i=0; i < users.size(); i++){
            if(users.get(i).getNombre().equals(user.getNombre())){
                users.remove(i);
            }
        }
        users.add(modificated);
    }

    public void eliminarUsuario(int num, String nombre) {
        //Base de datos
        dbUsers.child(nombre).removeValue();
        System.out.println("eliminado");
        //Array de usuarios
        users.remove(num);
    }
}
