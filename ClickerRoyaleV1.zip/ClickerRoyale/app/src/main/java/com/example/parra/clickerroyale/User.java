package com.example.parra.clickerroyale;

import com.google.firebase.database.*;

import java.util.ArrayList;

@IgnoreExtraProperties
@SuppressWarnings("serial")
public class User {


    private String name;
    private String password;
    private int level;
    private int score;
    private int damage;
    private int speed;
    private int capacity;
    private int clickDamage;
    private int numFriends;
    private ArrayList<String> friends;
    private ArrayList<String> request;
    private boolean hidden;
    private int dpsInactive;
    private ParraDate date;

    /** Constructor por defecto */
    public User() {

    }

    /** Constructor usado para pasarle un usuario y su contraseña y rellenar con valores predeterminados sus demas atributos */
    //Constructor de registro
    public User(String name, String password) {
        this.name = name;
        this.password = password;
        this.level = 1;
        this.score = 0;
        this.damage = 0;
        this.speed = 100;
        this.capacity = 100;
        this.clickDamage = 1;
        this.numFriends = 0;
        this.friends = new ArrayList<>();
        this.request = new ArrayList<>();
        this.hidden = false;
        this.dpsInactive = 0;
        this.date = new ParraDate();
    }

    public ParraDate getDate() {
        return date;
    }

    public void setDate(ParraDate date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getClickDamage() {
        return clickDamage;
    }

    public void setClickDamage(int clickDamage) {
        this.clickDamage = clickDamage;
    }

    public int getNumFriends() {
        return numFriends;
    }

    public void setNumFriends(int numFriends) {
        this.numFriends = numFriends;
    }

    public ArrayList<String> getFriends() {
        return friends;
    }

    public void setFriends(ArrayList<String> friends) {
        this.friends = friends;
    }

    public ArrayList<String> getRequest() {
        return request;
    }

    public void setRequest(ArrayList<String> request) {
        this.request = request;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public int getDpsInactive() {
        return dpsInactive;
    }

    public void setDpsInactive(int dpsInactive) {
        this.dpsInactive = dpsInactive;
    }
}
