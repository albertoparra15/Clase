package com.example.parra.chatglobal;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText emailtxt;
    static  Button entrar;
    static String nombre = "Anonymous";
    static boolean termina = false;


    static ChatCR crud;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailtxt = (EditText) findViewById(R.id.emailtxt);
        entrar = (Button) findViewById(R.id.entrar);

        crud = new ChatCR();
        crud.obtenerMensajes();
    }

    public void entrarOnClick(View v){
        if("Cargando...".equals(entrar.getText()+"")){
            Toast.makeText(LoginActivity.this, "Espera a que termine de cargar", Toast.LENGTH_SHORT).show();
            entrar.setEnabled(false);
        }
        else {
            if (!"".equals(emailtxt.getText() + "")) {
                nombre = emailtxt.getText() + "";
            }
            Intent i = new Intent(LoginActivity.this, ChatActivity.class);
            startActivity(i);
            finish();
        }
    }
}
