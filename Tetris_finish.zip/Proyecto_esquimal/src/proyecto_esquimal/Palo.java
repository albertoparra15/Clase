package proyecto_esquimal;

public class Palo {
    int x=4;
    int y=0;
    int posicion=1;
    
    public Palo() {
        if(Game.mapa[x][y]!=' ' || Game.mapa[x][y+1]!=' ' || Game.mapa[x][y+2]!=' ' || Game.mapa[x][y+3]!=' '){
            Main.finnal=true;
        }
        Game.mapa[x][y]='x';
        Game.mapa[x][y+1]='x';
        Game.mapa[x][y+2]='x';
        Game.mapa[x][y+3]='x';
    }
    
    void move(){
        switch(posicion){
            case 1:
                if(y<16){
                    Game.mapa[x][y]=' ';
                    Game.mapa[x][y+1]=' ';
                    Game.mapa[x][y+2]=' ';
                    Game.mapa[x][y+3]=' ';
                    y+=1;
                    Game.mapa[x][y]='x';
                    Game.mapa[x][y+1]='x';
                    Game.mapa[x][y+2]='x';
                    Game.mapa[x][y+3]='x';
                }
                break;
            case 2:
                if(y<18){
                    Game.mapa[x-1][y+1]=' ';
                    Game.mapa[x][y+1]=' ';
                    Game.mapa[x+1][y+1]=' ';
                    Game.mapa[x+2][y+1]=' ';
                    y+=1;
                    Game.mapa[x-1][y+1]='x';
                    Game.mapa[x][y+1]='x';
                    Game.mapa[x+1][y+1]='x';
                    Game.mapa[x+2][y+1]='x';
                }
                break;
        }
        
    }
    
    void cambioPosicion(){
        switch(posicion){
            case 1:
                Game.mapa[x][y]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x][y+2]=' ';
                Game.mapa[x][y+3]=' ';
                Game.mapa[x-1][y+1]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x+1][y+1]='x';
                Game.mapa[x+2][y+1]='x';
                posicion=2;
                break;
            case 2:
                Game.mapa[x-1][y+1]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x+1][y+1]=' ';
                Game.mapa[x+2][y+1]=' ';
                Game.mapa[x][y]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x][y+2]='x';
                Game.mapa[x][y+3]='x';
                posicion=1;
                break;
        }
    }
    
    void moverX(int numero){
        switch(posicion){
            case 1:
                Game.mapa[x][y]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x][y+2]=' ';
                Game.mapa[x][y+3]=' ';
                x=x+numero;
                Game.mapa[x][y]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x][y+2]='x';
                Game.mapa[x][y+3]='x';
                break;
            case 2:
                Game.mapa[x-1][y+1]=' ';
                Game.mapa[x][y+1]=' ';
                Game.mapa[x+1][y+1]=' ';
                Game.mapa[x+2][y+1]=' ';
                x=x+numero;
                Game.mapa[x-1][y+1]='x';
                Game.mapa[x][y+1]='x';
                Game.mapa[x+1][y+1]='x';
                Game.mapa[x+2][y+1]='x';
                break;
        }
    }
    
    boolean comprobarRight(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(x<9){
                    if(Game.mapa[x+1][y]==' ' && Game.mapa[x+1][y+1]==' ' && Game.mapa[x+1][y+2]==' ' && Game.mapa[x+1][y+3]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(x<7){
                    if(Game.mapa[x+3][y+1]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    boolean comprobarLeft(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(x>0){
                    if(Game.mapa[x-1][y]==' ' && Game.mapa[x-1][y+1]==' ' && Game.mapa[x-1][y+2]==' ' && Game.mapa[x-1][y+3]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(x>1){
                    if(Game.mapa[x-2][y+1]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    boolean comprobarDown(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(y<16){
                    if(Game.mapa[x][y+4]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(y<18){
                    if(Game.mapa[x+1][y+2]==' ' && Game.mapa[x][y+2]==' ' && Game.mapa[x-1][y+2]==' ' && Game.mapa[x+2][y+2]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    boolean comprobarCambio(){
        boolean bool=false;
        switch(posicion){
            case 1:
                if(x>0 && x<8){
                    if(Game.mapa[x-1][y+1]==' ' && Game.mapa[x+1][y+1]==' ' && Game.mapa[x+2][y+1]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
            case 2:
                if(y<17){
                    if(Game.mapa[x][y]==' ' && Game.mapa[x][y+2]==' ' && Game.mapa[x][y+3]==' '){
                        bool= true;
                    }
                    else
                        bool= false;
                }
                else
                    bool= false;
                break;
        }
        return bool;
    }
    
    void finiquitao(){
        switch(posicion){
            case 1:
                Game.mapa[x][y]='o';
                Game.mapa[x][y+1]='o';
                Game.mapa[x][y+2]='o';
                Game.mapa[x][y+3]='o';
                break;
            case 2:
                Game.mapa[x-1][y+1]='o';
                Game.mapa[x][y+1]='o';
                Game.mapa[x+1][y+1]='o';
                Game.mapa[x+2][y+1]='o';
                break;
        }
        Game.volando=false;
    }
}
