package com.example.examen.clicker9000;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Clicker extends AppCompatActivity {

    public static int score;
    public static int dps;
    public static int dpc;
    public static int costeDps;
    public static int costeDpc;
    public static TextView txtNombre;
    public static TextView txtScore;
    public static TextView txtDps;
    public static TextView txtDpc;
    public static Button btnDps;
    public static Button btnDpc;
    public static Button btnGuardar;
    public static ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);

        imagen= (ImageView) findViewById(R.id.imagen);
        txtNombre= (TextView) findViewById(R.id.txtNombre);
        txtScore= (TextView) findViewById(R.id.textoScore);
        txtDps= (TextView) findViewById(R.id.txtDps);
        txtDpc= (TextView) findViewById(R.id.txtDpc);
        btnDps= (Button) findViewById(R.id.dpsBtn);
        btnDpc= (Button) findViewById(R.id.dpcBtn);
        btnGuardar= (Button) findViewById(R.id.btnGuardar);

        Query score = Login.database.getReference("users").child(Login._name).child("score");
        score.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Clicker.score= (int) (long) dataSnapshot.getValue();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.score=0;
            }
        });
        Query dps = Login.database.getReference("users").child(Login._name).child("dps");
        dps.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Clicker.dps= (int) (long) dataSnapshot.getValue();
                costeDps=(Clicker.dps+1)*10;
                txtDps.setText("Dps: "+Clicker.dps);
                btnDps.setText("coste: "+costeDps);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.dps=0;
            }
        });
        Query dpc = Login.database.getReference("users").child(Login._name).child("dpc");
        dpc.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Clicker.dpc= (int) (long) dataSnapshot.getValue();
                costeDpc=(Clicker.dpc)*10;
                txtDpc.setText("Dpc: "+Clicker.dpc);
                btnDpc.setText("coste: "+costeDpc);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.dpc=1;
            }
        });

        txtNombre.setText(Login._name);
        MiTareaAsincronaDialog tarea2 = new MiTareaAsincronaDialog();
        tarea2.execute();

    }

    public void opcionesOnClick(View v){
        guardar();
        Intent opciones = new Intent(getApplicationContext(), Opciones.class);
        startActivity(opciones);

        finish();
    }
    public void amigosOnClick(View v){
        guardar();
        Intent amigos = new Intent(getApplicationContext(), Amigos.class);
        startActivity(amigos);

        finish();
    }

    public void guardarOnClick(View v) {
        btnGuardar.setEnabled(false);
        MiTareaAsincronaDialog.contadorGuardar=0;
        guardar();

        Toast nocoincide = Toast.makeText(getApplicationContext(), "guardado", Toast.LENGTH_SHORT);
        nocoincide.setGravity(Gravity.TOP, 0, 8);
        nocoincide.show();
    }

    public void guardar(){

        DatabaseReference refName = Login.database.getReference("users").child(Login._name);

        DatabaseReference dpsdb = refName.child("dps");
        dpsdb.setValue(dps);

        DatabaseReference dpcdb = refName.child("dpc");
        dpcdb.setValue(dpc);

        DatabaseReference scoredb = refName.child("score");
        scoredb.setValue(score);
    }

    public void dpsOnClick(View v){
        if(score>=costeDps){
            score-=costeDps;
            costeDps+=10;
            btnDps.setText("coste: "+costeDps);
            dps++;
            txtDps.setText("Dps: "+dps);
        }
    }

    public void dpcOnClick(View v){
        if(score>=costeDpc){
            score-=costeDpc;
            costeDpc+=10;
            btnDpc.setText("coste: "+costeDpc);
            dpc++;
            txtDpc.setText("Dpc: "+dpc);
        }
    }

    public void giraOnClick(View v){
        score+=dpc;
        imagen.animate().rotation(imagen.getRotation()-5).setDuration(200);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MiTareaAsincronaDialog.activo=true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        MiTareaAsincronaDialog.activo=false;
    }

    @Override
    protected void onStop() {
        super.onStop();
        MiTareaAsincronaDialog.activo=false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MiTareaAsincronaDialog.activo=false;
    }

    //para tener que pulsar 2 veces atras para salir
    private static final int INTERVALO = 2000; //2 segundos para salir
    private long tiempoPrimerClick;

    @Override
    public void onBackPressed(){
        if (tiempoPrimerClick + INTERVALO > System.currentTimeMillis()){
            super.onBackPressed();
            return;
        }else {
            Toast.makeText(this, "Vuelve a presionar para salir", Toast.LENGTH_SHORT).show();
        }
        tiempoPrimerClick = System.currentTimeMillis();
    }
}
