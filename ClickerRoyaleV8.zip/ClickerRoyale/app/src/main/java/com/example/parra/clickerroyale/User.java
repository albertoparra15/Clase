package com.example.parra.clickerroyale;

import com.google.firebase.database.*;

import java.util.ArrayList;

/**
 * The type User.
 */
@IgnoreExtraProperties
@SuppressWarnings("serial")
public class User {


    private String name;
    private String password;
    private int level;
    private int score;
    private int damage;
    private int speed;
    private int capacity;
    private int clickDamage;
    private int numFriends;
    private ArrayList<String> friends;
    private ArrayList<String> request;
    private boolean hidden;
    private int dpsInactive;
    private ParraDate date;

    /**
     * Constructor por defecto
     */
    public User() {

    }

    /**
     * Constructor usado para pasarle un usuario y su contraseña y rellenar con valores predeterminados sus demas atributos
     * @param name the name
     *
     * @param password the password
     */
//Constructor de registro
    public User(String name, String password) {
        this.name = name;
        this.password = password;
        this.level = 1;
        this.score = 0;
        this.damage = 0;
        this.speed = 1000;
        this.capacity = 100;
        this.clickDamage = 1;
        this.numFriends = 0;
        this.friends = new ArrayList<>();
        this.request = new ArrayList<>();
        this.hidden = false;
        this.dpsInactive = 0;
        this.date = new ParraDate();
    }

    /**
     * Gets date.
     *
     * @return the date
     */
    public ParraDate getDate() {
        return date;
    }

    /**
     * Sets date.
     *
     * @param date the date
     */
    public void setDate(ParraDate date) {
        this.date = date;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets name.
     *
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets password.
     *
     * @param password the password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets level.
     *
     * @return the level
     */
    public int getLevel() {
        return level;
    }

    /**
     * Sets level.
     *
     * @param level the level
     */
    public void setLevel(int level) {
        this.level = level;
    }

    /**
     * Gets score.
     *
     * @return the score
     */
    public int getScore() {
        return score;
    }

    /**
     * Sets score.
     *
     * @param score the score
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Gets damage.
     *
     * @return the damage
     */
    public int getDamage() {
        return damage;
    }

    /**
     * Sets damage.
     *
     * @param damage the damage
     */
    public void setDamage(int damage) {
        this.damage = damage;
    }

    /**
     * Gets speed.
     *
     * @return the speed
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * Sets speed.
     *
     * @param speed the speed
     */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    /**
     * Gets capacity.
     *
     * @return the capacity
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * Sets capacity.
     *
     * @param capacity the capacity
     */
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    /**
     * Gets click damage.
     *
     * @return the click damage
     */
    public int getClickDamage() {
        return clickDamage;
    }

    /**
     * Sets click damage.
     *
     * @param clickDamage the click damage
     */
    public void setClickDamage(int clickDamage) {
        this.clickDamage = clickDamage;
    }

    /**
     * Gets num friends.
     *
     * @return the num friends
     */
    public int getNumFriends() {
        return numFriends;
    }

    /**
     * Sets num friends.
     *
     * @param numFriends the num friends
     */
    public void setNumFriends(int numFriends) {
        this.numFriends = numFriends;
    }

    /**
     * Gets friends.
     *
     * @return the friends
     */
    public ArrayList<String> getFriends() {
        return friends;
    }

    /**
     * Sets friends.
     *
     * @param friends the friends
     */
    public void setFriends(ArrayList<String> friends) {
        this.friends = friends;
    }

    /**
     * Gets request.
     *
     * @return the request
     */
    public ArrayList<String> getRequest() {
        return request;
    }

    /**
     * Sets request.
     *
     * @param request the request
     */
    public void setRequest(ArrayList<String> request) {
        this.request = request;
    }

    /**
     * Is hidden boolean.
     *
     * @return the boolean
     */
    public boolean isHidden() {
        return hidden;
    }

    /**
     * Sets hidden.
     *
     * @param hidden the hidden
     */
    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    /**
     * Gets dps inactive.
     *
     * @return the dps inactive
     */
    public int getDpsInactive() {
        return dpsInactive;
    }

    /**
     * Sets dps inactive.
     *
     * @param dpsInactive the dps inactive
     */
    public void setDpsInactive(int dpsInactive) {
        this.dpsInactive = dpsInactive;
    }
}
