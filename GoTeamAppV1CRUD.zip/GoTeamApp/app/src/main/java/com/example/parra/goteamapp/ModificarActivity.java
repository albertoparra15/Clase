package com.example.parra.goteamapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class ModificarActivity extends AppCompatActivity {
    EditText mnombreET;
    RatingBar mnivelRB;
    Button modify, mexit;
    Bundle extras;
    Users user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);

        extras=getIntent().getExtras();
        user = new Users(extras.getString("nombre"), Integer.parseInt(extras.getString("nivel")));

        mnivelRB = (RatingBar) findViewById(R.id.mnivelrb);
        mnivelRB.setRating(user.getNivel());
        mnombreET = (EditText) findViewById(R.id.mnombreet);
        mnombreET.setText(user.getNombre());
        modify = (Button) findViewById(R.id.modifybtn);
        mexit = (Button) findViewById(R.id.exitmbtn);
    }

    public void modifyOnClick(View v){
        boolean bien = true;
        for (Users us : UsersCRUD.users) {
            if (us.getNombre().equals(mnombreET.getText() + "") && !us.getNombre().equals(user.getNombre())) {
                bien = false;
                break;
            }
        }
        if (bien) {
            Users u = new Users(mnombreET.getText() + "", (int) mnivelRB.getRating());
            CargaActivity.crud.actualizarUsuario(user, u);

            Toast t = Toast.makeText(v.getContext(),mnombreET.getText()+ " ha sido modificado con éxito", Toast.LENGTH_SHORT);
            t.show();

            Intent i = new Intent(v.getContext(), UsersActivity.class);
            startActivity(i);
            finish();
        }
        else{
            Toast t = Toast.makeText(v.getContext(),mnombreET.getText()+ " ya existe", Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void mexit(View v){
        Intent i = new Intent(v.getContext(), UsersActivity.class);
        startActivity(i);
        finish();
    }
}
