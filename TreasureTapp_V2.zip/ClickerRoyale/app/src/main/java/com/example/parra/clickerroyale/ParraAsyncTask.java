package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;

import com.google.firebase.database.DatabaseReference;

/**
 * The type Parra async task.
 */
public class ParraAsyncTask extends AsyncTask<Void, Integer, Boolean> {

    boolean guardado = false;
    /**
     * The Bd.
     */
//base de datos
    private DatabaseReference bd = LoginActivity.dbUsers.child(LoginActivity.user.getName());

    /**
     * The Seguir.
     */
    boolean seguir=true;

    /**
     * The Cont guardado.
     */
    //contadores
    private int contGuardado=0;

    /**
     * The Context.
     */
    @SuppressLint("StaticFieldLeak")
    private Context context;

    /**
     * The Hadler.
     */
    private Handler hadler = new Handler();
    /**
     * The Runneable.
     */
    private Runnable runneable = new Runnable() {
        @SuppressLint("SetTextI18n")
        @Override
        public void run() {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(Clicker.txtVida, "translationY", 500, 0);
            transAnimatio1.setDuration(100).start();
            ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(Clicker.ivChest, "translationY", -500, 0);
            transAnimatio2.setDuration(100).start();
            Clicker.ivChest.setEnabled(true);
            Clicker.ivChest.setVisibility(View.VISIBLE);
            Clicker.txtVida.setVisibility(View.VISIBLE);
            Clicker.explosionField.clear();
            Clicker.txtVida.setText(Clicker.vidaChest + "");
        }
    };

    private Runnable runneable2 = new Runnable() {
        @SuppressLint("SetTextI18n")
        @Override
        public void run() {
            if ((LoginActivity.user.getScore() + Clicker.oro) <= LoginActivity.user.getCapacity()) {
                LoginActivity.user.setScore(LoginActivity.user.getScore() + Clicker.oro);
                Clicker.txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            } else {
                LoginActivity.user.setScore(LoginActivity.user.getCapacity());
                Clicker.txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            }
            Clicker.ivChest.setImageResource(R.drawable.chest);
            Clicker.ivChest.setVisibility(View.GONE);
            Clicker.ivmundo.animate().rotation(Clicker.ivmundo.getRotation()+60).setDuration(200);
        }
    };

    private Runnable runneable3 = new Runnable() {
        @SuppressLint("SetTextI18n")
        @Override
        public void run() {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(Clicker.ivmundo, "translationY", 0, 30);
            transAnimatio1.setDuration(50).start();
        }
    };

    private Runnable runneable4 = new Runnable() {
        @SuppressLint("SetTextI18n")
        @Override
        public void run() {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(Clicker.ivmundo, "translationY", 30, 0);
            transAnimatio1.setDuration(50).start();
        }
    };

    /**
     * Instantiates a new Parra async task.
     *
     * @param context the context
     */
    ParraAsyncTask(Context context) {
        this.context = context;
    }

    @Override
    protected Boolean doInBackground(Void... params) {

        while(seguir){
            try {
                Thread.sleep(LoginActivity.user.getSpeed());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            contGuardado+=LoginActivity.user.getSpeed();
            publishProgress();
        }
        publishProgress();
        return true;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onProgressUpdate(Integer... values) {
        // Guardado automático cada 10 seg
        if(contGuardado>=10000 && guardado){
            contGuardado=0;
            bd.setValue(LoginActivity.user);
            ParraDate date = new ParraDate();
            if(date.getYear()!=LoginActivity.user.getDate().getYear() || date.getDay()!=LoginActivity.user.getDate().getDay() || date.getHour()!=LoginActivity.user.getDate().getHour() || date.getMinute()!=LoginActivity.user.getDate().getMinute()){
                bd.child("date").setValue(date);
                LoginActivity.user.getDate().setYear(date.getYear());
                LoginActivity.user.getDate().setDay(date.getDay());
                LoginActivity.user.getDate().setHour(date.getHour());
                LoginActivity.user.getDate().setMinute(date.getMinute());
            }
            Clicker.txtAviso.setText(R.string.SavedSp);
        }
        if(LoginActivity.user.getDamage()>0){
            // daño automático realizado
            Clicker.vidaChest=Clicker.vidaChest-LoginActivity.user.getDamage();
            if (Clicker.vidaChest <= 0) {
                Clicker.vidaChest = Math.round(LoginActivity.user.getCapacity()/10);
                Clicker.explosionField.explode(Clicker.ivChestExplote);
                Clicker.explosionField.expandExplosionBound(200,200);
                hadler.postDelayed(runneable4,600);
                hadler.postDelayed(runneable3,550);
                hadler.postDelayed(runneable,500);
                hadler.postDelayed(runneable2,300);
                Clicker.ivChest.setImageResource(R.drawable.chestfinal);
                Clicker.ivChest.setEnabled(false);
                Clicker.txtVida.setVisibility(View.GONE);
                Clicker.ivMoneda.setVisibility(View.VISIBLE);
                ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(Clicker.ivMoneda, "translationX", Math.round(Clicker.metrics.widthPixels/2), 0);
                ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(Clicker.ivMoneda, "translationY", Math.round(Clicker.metrics.heightPixels/2), 0);
                AnimatorSet animSetXY = new AnimatorSet();
                animSetXY.playTogether(transAnimationX, transAnimationY);
                animSetXY.setDuration(300).start();
            } else {
                int x = (int) (Math.random() * 41) - 20;
                int y = 20 - Math.abs(x);

                ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(Clicker.ivChest, "translationX", x, 0);
                ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(Clicker.ivChest, "translationY", y, 0);
                AnimatorSet animSetXY = new AnimatorSet();
                animSetXY.playTogether(transAnimationX, transAnimationY);
                animSetXY.setDuration(300).start();
            }
            Clicker.txtVida.setText(Clicker.vidaChest + "");
        }

    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(Boolean result) {
    }

    @Override
    protected void onCancelled() {
    }
}

