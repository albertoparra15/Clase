package com.games.juegoparalelo;

import android.os.AsyncTask;

class MiTareaAsincronaDialog extends AsyncTask<Void, Integer, Boolean> {

    @Override
    protected Boolean doInBackground(Void... params) {

        while(true) {

            try {
                Thread.sleep(250);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            MainActivity.score=MainActivity.score+MainActivity.dps;
            publishProgress(MainActivity.score);

            if(isCancelled())
                break;
        }

        return true;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        int progreso = values[0].intValue();

        MainActivity.txtScore.setText("Score: "+MainActivity.score);
    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(Boolean result) {
    }

    @Override
    protected void onCancelled() {
    }
}