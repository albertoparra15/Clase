package com.example.examen.clicker9000;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;

public class CambiarContrasena extends AppCompatActivity {

    EditText txtPassAct;
    EditText txtPass;
    EditText txtPassR;
    Button btnGuardarOpciones;
    TextView txtNombreOpciones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambiar_contrasena);

        txtNombreOpciones = (TextView) findViewById(R.id.txtNombre);
        txtPassAct = (EditText) findViewById(R.id.txtpassact);
        txtPass = (EditText) findViewById(R.id.txtpass);
        txtPassR = (EditText) findViewById(R.id.txtpassr);
        btnGuardarOpciones = (Button) findViewById(R.id.btnGuardarCambios);

        txtNombreOpciones.setText(Login._name);
    }

    public void guardarCambiosOnClick(View v){

        if(Login._password.equals(txtPassAct.getText().toString())){
            if(txtPass.getText().toString().equals(txtPassR.getText().toString())){
                DatabaseReference refName = Login.database.getReference("users").child(Login._name);

                DatabaseReference password = refName.child("password");
                password.setValue(txtPass.getText().toString());
                Login._password=txtPass.getText().toString();
            }
        }

    }
}
