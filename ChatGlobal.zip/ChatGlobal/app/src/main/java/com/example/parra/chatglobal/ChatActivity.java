package com.example.parra.chatglobal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {
    static EditText mensajetxt;
    static Button enviar, actualizar;
    static RecyclerView recycler;
    static AdapterData adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        mensajetxt = (EditText) findViewById(R.id.mensajetxt);
        recycler = (RecyclerView) findViewById(R.id.recyclerId);
        enviar = (Button) findViewById(R.id.enviar);
        actualizar = (Button) findViewById(R.id.refresh);

        recycler.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        adapter = new AdapterData();
        recycler.setAdapter(adapter);

        LoginActivity.termina = true;
    }

    public void enviar(View v){
        if(!"".equals(mensajetxt.getText()+"")){
            LoginActivity.crud.crearMensaje(new Chat(LoginActivity.nombre, mensajetxt.getText()+""));
            mensajetxt.setText("");
        }
    }

    public void actualizar(View v){
        mensajetxt.setEnabled(false);
        enviar.setEnabled(false);
        actualizar.setEnabled(false);
        ChatCR.chats = new ArrayList<>();
        LoginActivity.crud.obtenerMensajes();
    }
}
