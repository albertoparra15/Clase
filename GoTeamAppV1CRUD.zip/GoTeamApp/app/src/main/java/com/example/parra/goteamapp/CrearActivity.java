package com.example.parra.goteamapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class CrearActivity extends AppCompatActivity {
    EditText nombreET;
    RatingBar nivelRB;
    Button addContinue, addExit, exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear);

        nivelRB = (RatingBar) findViewById(R.id.nivelrb);
        nombreET = (EditText) findViewById(R.id.nombreet);
        addContinue = (Button) findViewById(R.id.addContinuebtn);
        addExit = (Button) findViewById(R.id.addbtn);
        exit = (Button) findViewById(R.id.exitbtn);
    }

    public void addAndContinue(View v){
        boolean bien = true;
        if(!(nombreET.getText() + "").equals("")) {
            for (Users user:UsersCRUD.users) {
                if(user.getNombre().equals(nombreET.getText() + "")){
                    bien = false;
                    break;
                }
            }
            if(bien) {

                System.out.println("" + nivelRB.getRating());
                Users u = new Users(nombreET.getText() + "", (int) nivelRB.getRating());
                CargaActivity.crud.crearProducto(u);

                nombreET.setText("");
                nivelRB.setRating(0);

                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ha sido creado con éxito", Toast.LENGTH_SHORT);
                t.show();
            }
            else{
                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ya existe", Toast.LENGTH_SHORT);
                t.show();
            }
        }
        else{
            Toast t = Toast.makeText(v.getContext()," no has introducido el nombre", Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void addAndExit(View v){
        boolean bien = true;
        if(!(nombreET.getText() + "").equals("")) {
            for (Users user:UsersCRUD.users) {
                if(user.getNombre().equals(nombreET.getText() + "")){
                    bien = false;
                    break;
                }
            }
            if(bien) {

                System.out.println("" + nivelRB.getRating());
                Users u = new Users(nombreET.getText() + "", (int) nivelRB.getRating());
                CargaActivity.crud.crearProducto(u);

                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ha sido creado con éxito", Toast.LENGTH_SHORT);
                t.show();

                Intent i = new Intent(v.getContext(), UsersActivity.class);
                startActivity(i);
                finish();
            }
            else{
                Toast t = Toast.makeText(v.getContext(),nombreET.getText()+ " ya existe", Toast.LENGTH_SHORT);
                t.show();
            }
        }
        else{
            Toast t = Toast.makeText(v.getContext()," no has introducido el nombre", Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void exit(View v){
        Intent i = new Intent(v.getContext(), UsersActivity.class);
        startActivity(i);
        finish();
    }
}
