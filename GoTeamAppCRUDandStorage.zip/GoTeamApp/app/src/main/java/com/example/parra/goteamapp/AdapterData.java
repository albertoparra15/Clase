package com.example.parra.goteamapp;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class AdapterData extends RecyclerView.Adapter<AdapterData.ViewHolderData> {

    public AdapterData() {
    }

    @NonNull
    @Override
    public ViewHolderData onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_list,viewGroup,false);
        return new ViewHolderData(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderData viewHolderData, int i) {
        viewHolderData.AsignarDatos(UsersCRUD.users.get(i));
    }

    @Override
    public int getItemCount() {
        return UsersCRUD.users.size();
    }

    //------------------------------------------------------------------------------------
    class ViewHolderData extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final Context context;
        TextView nombre, nivel;
        ImageView eliminar;

        ViewHolderData(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();

            nivel=itemView.findViewById(R.id.nivel);
            nombre=itemView.findViewById(R.id.nombre);
            eliminar=itemView.findViewById(R.id.eliminar);

            eliminar.setOnClickListener(this);
            itemView.setOnClickListener(this);
        }

        void AsignarDatos(Users user){
            nivel.setText("Nivel:  " + user.getNivel());
            nombre.setText(user.getNombre());
        }

        @Override
        public void onClick(View view) {
            if(view.getId()==R.id.eliminar){
                CargaActivity.crud.eliminarUsuario(this.getAdapterPosition(),this.nombre.getText()+"");
                UsersActivity.recycler.swapAdapter(UsersActivity.adapter,true);
            }
            else{
                Intent i = new Intent(context.getApplicationContext(),ModificarActivity.class);
                i.putExtra("nivel", nivel.getText().charAt(8)+"");
                i.putExtra("nombre", nombre.getText()+"");
                context.startActivity(i);
            }

        }
    }
}
