package com.example.parra.practicaad2trimestreapc;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import Controlador.AdapterData;
import Modelo.ProductoDaoImpl;
import Modelo.IProductoDao;

public class MainActivity extends AppCompatActivity {

    RecyclerView recycler;
    AdapterData adapter;
    boolean actualizar=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //objeto para manipular el dao
        IProductoDao productoDao = new ProductoDaoImpl();

        recycler = (RecyclerView) findViewById(R.id.recyclerId);
        recycler.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        //imprimir productos
        adapter = new AdapterData(((ProductoDaoImpl) productoDao).obtenerProductos());
        recycler.setAdapter(adapter);
        System.out.println("muestra los productos");
    }

    public void CreateOnClick(View v){
        Intent i = new Intent(this,CreateActivity.class);
        startActivity(i);
        finish();
    }

    public void ReadOnClick(View v){
        if(actualizar) {
            recycler.setAdapter(adapter);
            actualizar=false;
            v.setVisibility(View.INVISIBLE);
        }
    }

    public void RerollOnClick(View v){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}
