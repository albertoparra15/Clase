package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * The type Login activity.
 */
public class LoginActivity extends AppCompatActivity {

    //region VARIABLES

    static String Idioma = "Español";

    /**
     * The Database.
     */
    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    /**
     * The Db users.
     */
    static final DatabaseReference dbUsers = database.getReference("users");

    /**
     * The User.
     */
    static User user;
    /**
     * The Leaderboard.
     */
    static User[] leaderboard=new User[5];

    //campos de texto
    private static EditText txtName;
    private static EditText txtPassword;
    private TextView txtLogin;
    private TextView txtAviso;
    private TextView txtInfo;

    //botones
    private Button btnRegister;
    private Button btnLogin;

    ImageView ivIdiomas;
    ImageView ivEspana;
    ImageView ivEngland;

    /**
     * The Rellay 1.
     */
//cosas para la animacion
    RelativeLayout rellay1, /**
     * The Rellay 2.
     */
    rellay2;
    /**
     * The Hadler.
     */
    Handler hadler = new Handler();
    /**
     * The Runneable.
     */
    Runnable runneable = new Runnable() {
        @Override
        public void run() {
            rellay1.setVisibility(View.VISIBLE);
            rellay2.setVisibility(View.VISIBLE);
            ivIdiomas.setVisibility(View.VISIBLE);
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivIdiomas, "translationY", 1000, 0);
            transAnimatio1.setDuration(400).start();
        }
    };

    boolean cargando = false;

    boolean idiomasActivo = false;

    /**
     * The Register act.
     */
//controladores
    boolean registerAct=false;

    //endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        rellay1 = findViewById(R.id.rellay1);
        rellay2 = findViewById(R.id.rellay2);

        hadler.postDelayed(runneable,1000);

        //conectamos los elementos con su id en la activity
        txtName = findViewById(R.id.etName);
        txtPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnToRegister);
        btnLogin = findViewById(R.id.btnLogin);
        txtLogin = findViewById(R.id.txtLogin);
        txtAviso = findViewById(R.id.txtAvisoLogin);
        ivIdiomas = findViewById(R.id.ivIdiomas);
        ivEngland = findViewById(R.id.ivEngland);
        ivEspana = findViewById(R.id.ivEspana);
        txtInfo = findViewById(R.id.txtInfo);

        txtPassword.setOnKeyListener(new View.OnKeyListener(){
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event){
                if(keyCode == KeyEvent.KEYCODE_ENTER){
                    enter();
                }
                return true;
            }
        });
    }

    public void IdiomasOnClick(View v){

        if(idiomasActivo){
            idiomasActivo = false;
            ObjectAnimator transAnimatio3 = ObjectAnimator.ofFloat(txtInfo, "translationX", 0, 1000);
            transAnimatio3.setDuration(400).start();
            ivIdiomas.animate().rotation(ivIdiomas.getRotation() - 90).setDuration(300);
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivEspana, "translationX", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivEspana.setVisibility(View.VISIBLE);
            ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivEngland, "translationX", 0, 1000);
            transAnimatio2.setDuration(500).start();
        }
        else{
            idiomasActivo = true;
            txtInfo.setVisibility(View.VISIBLE);
            ObjectAnimator transAnimatio3 = ObjectAnimator.ofFloat(txtInfo, "translationX", 1000, 0);
            transAnimatio3.setDuration(400).start();
            ivIdiomas.animate().rotation(ivIdiomas.getRotation() + 90).setDuration(300);
            ivEspana.setVisibility(View.VISIBLE);
            ivEngland.setVisibility(View.VISIBLE);
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivEspana, "translationX", 1000, 0);
            transAnimatio1.setDuration(400).start();
            ivEspana.setVisibility(View.VISIBLE);
            ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivEngland, "translationX", 1000, 0);
            transAnimatio2.setDuration(500).start();
        }

    }

    /**
     * Login and register.
     *
     * @param v the v
     */
    public void loginAndRegister(View v){
        enter();
    }

    private void enter(){
        if(!cargando) {
            cargando = true;
            //acción del boton de registrar
            if (registerAct) {
                register();
            }
            //acción del boton Login
            else {
                login();
            }
        }
    }

    private void register(){
        txtAviso.setTextColor(Color.RED);
        if(txtName.getText().toString().equals("") || txtName.getText().toString().length() > 20 || txtPassword.getText().toString().length() > 20) {
            if(Idioma.equals("Español"))
                txtAviso.setText(R.string.Error1Sp);
            if(Idioma.equals("England"))
                txtAviso.setText(R.string.Error1En);
        }
        else {

            Query noRepetido = dbUsers.orderByKey().equalTo(txtName.getText().toString());

            noRepetido.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if((dataSnapshot.getValue())==null){

                        DatabaseReference refName = dbUsers.child(txtName.getText().toString());
                        user = new User(txtName.getText().toString(),txtPassword.getText().toString());
                        refName.setValue(user);
                        txtAviso.setTextColor(Color.WHITE);
                        if(Idioma.equals("Español"))
                            txtAviso.setText(R.string.RegisteredSp);
                        if(Idioma.equals("England"))
                            txtAviso.setText(R.string.RegisteredEn);
                    }
                    else{
                        if(Idioma.equals("Español"))
                            txtAviso.setText(R.string.Error2Sp);
                        if(Idioma.equals("England"))
                            txtAviso.setText(R.string.Error2En);
                    }
                    cargando = false;
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    cargando = false;
                }
            });
        }
    }

    private void login(){
        txtAviso.setTextColor(Color.RED);
        if(txtName.getText().toString().equals("") || txtName.getText().toString().length() > 20 || txtPassword.getText().toString().length() > 20){
            if(Idioma.equals("Español"))
                txtAviso.setText(R.string.Error3Sp);
            if(Idioma.equals("England"))
                txtAviso.setText(R.string.Error3En);
            cargando = false;
        }
        else {
            Query existeNombre = database.getReference("users").orderByKey().equalTo(txtName.getText().toString());

            existeNombre.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if ((dataSnapshot.getValue()) != null) {

                        if (LoginActivity.getTxtPassword().getText().toString().equals(txtPassword.getText().toString())) {
                            txtAviso.setText("");
                            user = dataSnapshot.child(LoginActivity.getTxtName().getText().toString()).getValue(User.class);
                            Intent i = new Intent(getApplicationContext(), Clicker.class);
                            startActivity(i);
                            finish();
                        } else {
                            if(Idioma.equals("Español"))
                                txtAviso.setText(R.string.Error4Sp);
                            if(Idioma.equals("England"))
                                txtAviso.setText(R.string.Error4En);
                        }
                    } else {
                        if(Idioma.equals("Español"))
                            txtAviso.setText(R.string.Error5Sp);
                        if(Idioma.equals("England"))
                            txtAviso.setText(R.string.Error5En);
                    }
                    cargando = false;
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    cargando = false;
                }
            });
        }
    }

    /**
     * To login and to register.
     *
     * @param v the v
     */
    public void toLoginAndToRegister(View v){
        btnRegister.setEnabled(false);
        txtAviso.setText("");
        //Para pasar a pantalla de Login con una animación
        if(registerAct){
            ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(rellay1, "translationX", 0, -1000);
            ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(rellay1, "translationX", 1000, 0);
            ObjectAnimator transAnimationZ = ObjectAnimator.ofFloat(btnRegister, "translationX", 470, 0);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playSequentially(transAnimationX, transAnimationY);
            animSetXY.setDuration(500).start();
            transAnimationZ.setDuration(1000).start();
            Runnable runneable2 = new Runnable() {
                @Override
                public void run() {
                    if(Idioma.equals("Español")) {
                        btnRegister.setText(R.string.RegisterSp);
                        txtLogin.setText(R.string.LoginSp);
                        btnLogin.setText(R.string.LoginNowSp);
                    }
                    if(Idioma.equals("England")){
                        btnRegister.setText(R.string.RegisterEn);
                        txtLogin.setText(R.string.LoginEn);
                        btnLogin.setText(R.string.LoginNowEn);
                    }
                }
            };
            hadler.postDelayed(runneable2,500);
            registerAct=false;
        }
        //Para pasar a pantalla de Register con una animación
        else {
            ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(rellay1, "translationX", 0, 1000);
            ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(rellay1, "translationX", -1000, 0);
            ObjectAnimator transAnimationZ = ObjectAnimator.ofFloat(btnRegister, "translationX", 0, 470);
            AnimatorSet animSetXY = new AnimatorSet();
            animSetXY.playSequentially(transAnimationX, transAnimationY);
            animSetXY.setDuration(500).start();
            transAnimationZ.setDuration(1000).start();
            Runnable runneable2 = new Runnable() {
                @Override
                public void run() {
                    if(Idioma.equals("Español")) {
                        btnRegister.setText(R.string.LoginSp);
                        txtLogin.setText(R.string.RegisterSp);
                        btnLogin.setText(R.string.RegisterNowSp);
                    }
                    if(Idioma.equals("England")) {
                        btnRegister.setText(R.string.LoginEn);
                        txtLogin.setText(R.string.RegisterEn);
                        btnLogin.setText(R.string.RegisterNowEn);
                    }
                }
            };
            hadler.postDelayed(runneable2,500);
            registerAct=true;
        }
        //espera para darle a el boton el estado activo
        Runnable runneable3 = new Runnable() {
            @Override
            public void run() {
                btnRegister.setEnabled(true);
            }
        };
        hadler.postDelayed(runneable3,1000);
    }

    /**
     * Creacion leaderboard.
     */
    public static void creacionLeaderboard(){
        //recoge los 5 mejores
        Query lb = database.getReference("users").orderByChild("score").limitToLast(5);
        lb.addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i=4;
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    leaderboard[i] = ds.getValue(User.class);
                    i--;
                }
                if(leaderboard[0]!=null) {
                    Clicker.lbN1.setText(""+leaderboard[0].getName());
                    Clicker.lbS1.setText(""+leaderboard[0].getScore());
                }
                if(LoginActivity.leaderboard[1]!=null) {
                    Clicker.lbN2.setText(""+LoginActivity.leaderboard[1].getName());
                    Clicker.lbS2.setText(""+LoginActivity.leaderboard[1].getScore());
                }
                if(LoginActivity.leaderboard[2]!=null) {
                    Clicker.lbN3.setText(""+LoginActivity.leaderboard[2].getName());
                    Clicker.lbS3.setText(""+LoginActivity.leaderboard[2].getScore());
                }
                if(LoginActivity.leaderboard[3]!=null) {
                    Clicker.lbN4.setText(""+LoginActivity.leaderboard[3].getName());
                    Clicker.lbS4.setText(""+LoginActivity.leaderboard[3].getScore());
                }
                if(LoginActivity.leaderboard[4]!=null) {
                    Clicker.lbN5.setText(""+LoginActivity.leaderboard[4].getName());
                    Clicker.lbS5.setText(""+LoginActivity.leaderboard[4].getScore());
                }
                Clicker.lyCopaSub.setVisibility(View.VISIBLE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    /**
     * Gets txt name.
     *
     * @return the txt name
     */
    public static EditText getTxtName() {
        return txtName;
    }

    /**
     * Gets txt password.
     *
     * @return the txt password
     */
    public static EditText getTxtPassword() {
        return txtPassword;
    }
}
