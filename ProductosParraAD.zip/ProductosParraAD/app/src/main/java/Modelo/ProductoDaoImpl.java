package Modelo;

import android.support.annotation.NonNull;
import android.view.Gravity;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ProductoDaoImpl implements IProductoDao {
    static final FirebaseDatabase database = FirebaseDatabase.getInstance();
    static final DatabaseReference dbProducts = database.getReference("products");
    ArrayList<Productos> productos;


    public ProductoDaoImpl() {
        productos = new ArrayList<>();
        //productos.add(new Productos(1,"Cromo","1-1-1990","qwertyuyu"));
    }

    @Override
    public ArrayList<Productos> obtenerProductos() {
        Query lb = dbProducts.orderByKey();
        lb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i=0;
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    productos.add(ds.getValue(Productos.class));
                    System.out.println(ds.getValue());
                    i++;
                }
                System.out.println("añade los productos");
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
        System.out.println("empieza");
        return productos;
    }

    @Override
    public void crearProducto(Productos producto) {
        DatabaseReference refName = dbProducts.child(producto.getCodigo()+"");
        Productos p = new Productos(producto.getCodigo(), producto.getNombre(), producto.getFecha(), producto.getUrlImagen(), producto.getDescripcion());
        refName.setValue(p);
    }

    @Override
    public void actualizarProducto(Productos producto, Productos modificated) {
        if(producto.getCodigo()!=modificated.getCodigo()){
            DatabaseReference ref = dbProducts.child(producto.getCodigo()+"");
            ref.removeValue();
        }
        DatabaseReference refName = dbProducts.child(modificated.getCodigo()+"");
        Productos m = new Productos(modificated.getCodigo(), modificated.getNombre(), modificated.getFecha(), modificated.getUrlImagen(), modificated.getDescripcion());
        refName.setValue(m);
    }

    @Override
    public void eliminarProducto(String codigo) {
        dbProducts.child(codigo).removeValue();
        System.out.println("eliminado");
    }
}
