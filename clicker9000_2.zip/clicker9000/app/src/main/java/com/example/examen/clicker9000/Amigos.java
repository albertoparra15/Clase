package com.example.examen.clicker9000;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Amigos extends AppCompatActivity {

    TextView score;
    TextView scoreAmigo;
    TextView nombreAmigo;
    EditText etNombre;
    Button solicitud;

    static String samigo;
    static String amigo;

    boolean añadiractivo=false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amigos);

        score = (TextView) findViewById(R.id.txtScore);
        scoreAmigo = (TextView) findViewById(R.id.txtScoreAmigo);
        nombreAmigo = (TextView) findViewById(R.id.txtAmigo);
        etNombre = (EditText) findViewById(R.id.etName);
        solicitud = (Button) findViewById(R.id.btnSolicitud);

        refresh();

    }

    public void refreshOnClick(View v){
        refresh();
    }

    public void refresh(){
        Query solicitudes = Login.database.getReference("users").child(Login._name).child("solicitud");
        solicitudes.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.getValue().toString().equals("")){

                }
                else{
                    solicitud.setVisibility(View.VISIBLE);
                    samigo=dataSnapshot.getValue().toString();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.score=0;
            }
        });




        score.setText(Clicker.score+"");
        Query amigo1 = Login.database.getReference("users").child(Login._name).child("amigo");
        amigo1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.getValue().toString().equals("")){

                }
                else{
                    nombreAmigo.setText(dataSnapshot.getValue().toString()+":  ");
                    amigo=dataSnapshot.getValue().toString();

                    Query amigo2 = Login.database.getReference("users").child(dataSnapshot.getValue().toString()).child("score");
                    amigo2.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            scoreAmigo.setText(dataSnapshot.getValue().toString());
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Clicker.score=0;
            }
        });
    }

    public void solicitudAmigoOnClick(View v){
        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        dialogo1.setTitle("Solicitud");
        dialogo1.setMessage("¿ Desea añadir como amigo a: "+samigo+" ?");
        dialogo1.setCancelable(true);
        dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                DatabaseReference refName = Login.database.getReference("users").child(Login._name);

                DatabaseReference solicitud = refName.child("solicitud");
                solicitud.setValue("");
            }
        });

        dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                DatabaseReference refName = Login.database.getReference("users").child(Login._name);

                DatabaseReference amigo = refName.child("amigo");
                amigo.setValue(Amigos.samigo);
                DatabaseReference solicitud = refName.child("solicitud");
                solicitud.setValue("");

                DatabaseReference refName2 = Login.database.getReference("users").child(Amigos.samigo);

                DatabaseReference amigo2 = refName2.child("amigo");
                amigo2.setValue(Login._name);
            }
        });

        dialogo1.show();
        solicitud.setVisibility(View.INVISIBLE);
    }

    public void añadirAmigoOnClick(View v){
        if(añadiractivo==false){
            etNombre.setVisibility(View.VISIBLE);
            añadiractivo=true;
        }
        else{
            if(etNombre.getText().toString().equals("") || etNombre.getText().toString().equals(Login._name) || etNombre.getText().toString().equals(amigo)){ }
            else{
                Query existeUser = Login.database.getReference("users").child(etNombre.getText().toString());
                existeUser.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if((dataSnapshot.getValue())==null){}
                        else{
                            DatabaseReference refName = Login.database.getReference("users").child(dataSnapshot.getKey());

                            DatabaseReference solicitud = refName.child("solicitud");
                            solicitud.setValue(Login._name);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }

            añadiractivo=false;
            etNombre.setVisibility(View.INVISIBLE);
        }
    }

    public void volverOnClick(View v){
        Intent volver = new Intent(getApplicationContext(), Clicker.class);
        startActivity(volver);

        finish();
    }


    @Override
    public void onBackPressed(){
        Intent volver = new Intent(getApplicationContext(), Clicker.class);
        startActivity(volver);

        finish();
    }
}
