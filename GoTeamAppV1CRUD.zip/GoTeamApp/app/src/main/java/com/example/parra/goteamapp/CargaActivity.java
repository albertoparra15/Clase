package com.example.parra.goteamapp;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CargaActivity extends AppCompatActivity implements View.OnClickListener {
    static Context context;
    static Button b;
    static TextView t;
    static UsersCRUD crud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carga);
        context = getApplicationContext();

        b = (Button) findViewById(R.id.iniciarbtn);
        t = (TextView) findViewById(R.id.cargatxt);

        b.setEnabled(false);
        b.setOnClickListener(this);

        crud = new UsersCRUD();
        crud.obtenerUsers();
    }

    @Override
    public void onClick(View view) {
        Intent i = new Intent(this.getApplicationContext(), MainActivity.class);
        startActivity(i);
        finish();
    }
}