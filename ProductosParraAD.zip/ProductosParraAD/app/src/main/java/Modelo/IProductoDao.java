package Modelo;

import java.util.List;

import Modelo.Productos;

public interface IProductoDao {

    //declaración de métodos para acceder a la base de datos
    public List<Productos> obtenerProductos();
    public void crearProducto(Productos producto);
    public void actualizarProducto(Productos producto, Productos modificated);
    public void eliminarProducto(String codigo);
}
