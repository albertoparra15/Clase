package com.example.parra.clickerroyale;

import android.content.Context;
import android.os.AsyncTask;
import android.view.Gravity;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;

public class ParraAsyncTask extends AsyncTask<Void, Integer, Boolean> {
    //base de datos
    DatabaseReference bd = LoginActivity.dbUsers.child(LoginActivity.user.getName());

    //activadores
    boolean speedActivo=false;
    boolean seguir=true;

    //contadores
    int contGuardado=0;

    Context context;

    public ParraAsyncTask(Context context) {
        this.context = context;
    }

    @Override
    protected Boolean doInBackground(Void... params) {

        while(seguir){
            try {
                Thread.sleep(LoginActivity.user.getSpeed());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            contGuardado+=LoginActivity.user.getSpeed();
            publishProgress();
        }

        return true;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        // Guardado automático cada 10 seg
        if(contGuardado>=10000){
            contGuardado=0;
            bd.setValue(LoginActivity.user);
            ParraDate date = new ParraDate();
            System.out.println(date.getMinute()+" "+LoginActivity.user.getDate().getMinute());
            if(date.getYear()!=LoginActivity.user.getDate().getYear() || date.getDay()!=LoginActivity.user.getDate().getDay() || date.getHour()!=LoginActivity.user.getDate().getHour() || date.getMinute()!=LoginActivity.user.getDate().getMinute()){
                bd.child("date").setValue(date);
                LoginActivity.user.getDate().setYear(date.getYear());
                LoginActivity.user.getDate().setDay(date.getDay());
                LoginActivity.user.getDate().setHour(date.getHour());
                LoginActivity.user.getDate().setMinute(date.getMinute());
            }
            Toast t = Toast.makeText(context, "Actualizado", Toast.LENGTH_SHORT);
            t.setGravity(Gravity.BOTTOM,0,50);
            t.show();
        }
        // daño automático realizado
        Clicker.vidaChest=Clicker.vidaChest-LoginActivity.user.getDamage();
        if(Clicker.vidaChest<=0){
            Clicker.vidaChest=10;
            Clicker.txtVida.setText(Clicker.vidaChest+"");
            LoginActivity.user.setScore(LoginActivity.user.getScore()+3);
            Clicker.txtScore.setText(LoginActivity.user.getScore()+"");
        }
        Clicker.txtVida.setText(Clicker.vidaChest+"");
        speedActivo=false;

    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(Boolean result) {
    }

    @Override
    protected void onCancelled() {
    }
}

