package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.DownloadManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

/**
 * The type Clicker.
 */
public class Clicker extends AppCompatActivity implements View.OnClickListener{

    /**
     * The constant vidaChest.
     */
//vida cofres
    static int vidaChest=10;

    /**
     * The Btn opc 1.
     */
//botones
    Button btnOpc1;
    /**
     * The Btn opc 2.
     */
    Button btnOpc2;
    /**
     * The Iv copa.
     */
    Button ivCopa;
    /**
     * The Iv flecha.
     */
    Button ivFlecha;
    /**
     * The Iv reloj.
     */
    Button ivReloj;
    /**
     * The Btn m damage.
     */
//Button ivAmigo;
    Button btnMDamage, /**
     * The Btn m speed.
     */
    btnMSpeed, /**
     * The Btn m capacity.
     */
    btnMCapacity, /**
     * The Btn m click damage.
     */
    btnMClickDamage;

    /**
     * The Ly time.
     */
//layouts
    View lyTime;
    /**
     * The Ly flecha.
     */
    View lyFlecha;
    /**
     * The Ly copa.
     */
//View lyAmigos;
    View lyCopa;
    /**
     * The Lycamcon.
     */
    View lycamcon;

    /**
     * The constant txtScore.
     */
//text
    static TextView txtScore;
    /**
     * The Txt vida.
     */
    static TextView txtVida;
    /**
     * The Txt nombre.
     */
    TextView txtNombre;
    /**
     * The Lb n 1.
     */
    TextView lbN1, /**
     * The Lb n 2.
     */
    lbN2, /**
     * The Lb n 3.
     */
    lbN3, /**
     * The Lb n 4.
     */
    lbN4, /**
     * The Lb n 5.
     */
    lbN5, /**
     * The Lb s 1.
     */
    lbS1, /**
     * The Lb s 2.
     */
    lbS2, /**
     * The Lb s 3.
     */
    lbS3, /**
     * The Lb s 4.
     */
    lbS4, /**
     * The Lb s 5.
     */
    lbS5;
    /**
     * The Txt d act.
     */
    TextView txtDAct, /**
     * The Txt s act.
     */
    txtSAct, /**
     * The Txt c act.
     */
    txtCAct, /**
     * The Txt cd act.
     */
    txtCDAct, /**
     * The Txt nf act.
     */
    txtNFAct;
    /**
     * The Passwordact.
     */
    EditText passwordact, /**
     * The Passwordnew.
     */
    passwordnew;


    /**
     * The Iv opciones.
     */
//imagenes
    ImageView ivOpciones;
    /**
     * The Iv chest.
     */
    static ImageView ivChest;


    /**
     * The Opciones ativo.
     */
//booleans controladores
    boolean opcionesAtivo=false;
    /**
     * The Time activo.
     */
    boolean timeActivo=false;
    /**
     * The Flecha activo.
     */
    boolean flechaActivo=false;
    /**
     * The Friends activo.
     */
    boolean friendsActivo=false;
    /**
     * The Copa activo.
     */
    boolean copaActivo=false;
    /**
     * The Camcon activo.
     */
    boolean camconActivo=false;

    /**
     * The Precio capacity.
     */
//precios
    int precioCapacity=LoginActivity.user.getCapacity();
    /**
     * The Precio damage.
     */
    int precioDamage=(LoginActivity.user.getDamage()*100)+5;
    /**
     * The Precio speed.
     */
    int precioSpeed=(1000-LoginActivity.user.getSpeed())*10+20;
    /**
     * The Precio click damage.
     */
    int precioClickDamage=LoginActivity.user.getClickDamage()*120;

    /**
     * The Tarea 2.
     */
    static ParraAsyncTask tarea2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);

        ivOpciones = (ImageView) findViewById(R.id.ivOpciones);
        ivChest = (ImageView) findViewById(R.id.ivChest);
        txtScore = (TextView) findViewById(R.id.txtScore);
        txtVida = (TextView) findViewById(R.id.txtVida);
        txtNombre = (TextView) findViewById(R.id.txtNombre);
        lbN1 = (TextView) findViewById(R.id.lbNombre1);
        lbN2 = (TextView) findViewById(R.id.lbNombre2);
        lbN3 = (TextView) findViewById(R.id.lbNombre3);
        lbN4 = (TextView) findViewById(R.id.lbNombre4);
        lbN5 = (TextView) findViewById(R.id.lbNombre5);
        lbS1 = (TextView) findViewById(R.id.lbScore1);
        lbS2 = (TextView) findViewById(R.id.lbScore2);
        lbS3 = (TextView) findViewById(R.id.lbScore3);
        lbS4 = (TextView) findViewById(R.id.lbScore4);
        lbS5 = (TextView) findViewById(R.id.lbScore5);
        txtDAct = (TextView) findViewById(R.id.txtMDamageAct);
        txtSAct = (TextView) findViewById(R.id.txtMSpeedAct);
        txtCAct = (TextView) findViewById(R.id.txtMCapacitydAct);
        txtCDAct = (TextView) findViewById(R.id.txtMCDamageAct);
        txtNFAct = (TextView) findViewById(R.id.txtMNumFAct);
        btnOpc1 = (Button) findViewById(R.id.btnOpciones1);
        btnOpc2 = (Button) findViewById(R.id.btnOpciones2);
        lyTime = (View) findViewById(R.id.lyTime);
        lyFlecha = (View) findViewById(R.id.lyFlecha);
        //lyAmigos = (View) findViewById(R.id.lyAmigos);
        lyCopa = (View) findViewById(R.id.lyCopa);
        lycamcon = (View) findViewById(R.id.lycamcon);
        ivReloj = (Button) findViewById(R.id.ivReloj);
        ivFlecha = (Button) findViewById(R.id.ivFlecha);
        //ivAmigo = (Button) findViewById(R.id.ivAmigo);
        ivCopa = (Button) findViewById(R.id.ivCopa);
        btnMDamage = (Button) findViewById(R.id.btnMejoraDamage);
        btnMSpeed = (Button) findViewById(R.id.btnMejoraSpeed);
        btnMCapacity = (Button) findViewById(R.id.btnMejoraCapacity);
        btnMClickDamage = (Button) findViewById(R.id.btnMejoraDanoClick);
        passwordact = (EditText) findViewById(R.id.etpassact);
        passwordnew = (EditText) findViewById(R.id.etpassnew);

        txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
        txtVida.setText(vidaChest+"");
        txtNombre.setText(LoginActivity.user.getName()+"");
        txtDAct.setText("Act: "+LoginActivity.user.getDamage());
        txtSAct.setText("Act: "+LoginActivity.user.getSpeed());
        txtCAct.setText("Act: "+LoginActivity.user.getCapacity());
        txtCDAct.setText("Act: "+LoginActivity.user.getClickDamage());
        txtNFAct.setText("Act: "+LoginActivity.user.getNumFriends());
        btnMClickDamage.setText("COSTE: "+precioClickDamage);
        btnMDamage.setText("COSTE: "+precioDamage);
        btnMSpeed.setText("COSTE: "+precioSpeed);
        btnMCapacity.setText("COSTE: "+precioCapacity);

        ivChest.setOnClickListener(this);
        ivReloj.setOnClickListener(this);
        ivOpciones.setOnClickListener(this);
        ivFlecha.setOnClickListener(this);
        //ivAmigo.setOnClickListener(this);
        ivCopa.setOnClickListener(this);

        tarea2 = new ParraAsyncTask(this);
        tarea2.seguir=true;
        tarea2.execute();

    }

    @Override
    public void onClick(View v) {
        if(v.getId()!=R.id.ivChest){
            onClicks();
        }


        //selecciona el boton que estas usando
        switch (v.getId()) {

            //accion del boton copa
            case R.id.ivCopa:
                lyCopa.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                flechaActivo=false;
                friendsActivo=false;

                if(copaActivo){
                    copaActivo=false;

                }
                else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivCopa.setBackgroundResource(R.drawable.copaact);
                    copaActivo=true;
                    LoginActivity.creacionLeaderboard();
                    lbN1.setText(""+LoginActivity.leaderboard[0].getName());
                    lbN2.setText(""+LoginActivity.leaderboard[1].getName());
                    lbN3.setText(""+LoginActivity.leaderboard[2].getName());
                    lbN4.setText(""+LoginActivity.leaderboard[3].getName());
                    lbN5.setText(""+LoginActivity.leaderboard[4].getName());
                    lbS1.setText(""+LoginActivity.leaderboard[0].getScore());
                    lbS2.setText(""+LoginActivity.leaderboard[1].getScore());
                    lbS3.setText(""+LoginActivity.leaderboard[2].getScore());
                    lbS4.setText(""+LoginActivity.leaderboard[3].getScore());
                    lbS5.setText(""+LoginActivity.leaderboard[4].getScore());
                }
                break;
/*
            //accion del boton amigos
            case R.id.ivAmigo:
                lyAmigos.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                flechaActivo=false;
                copaActivo=false;

                if(friendsActivo){
                    friendsActivo=false;
                }
                else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyAmigos, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivAmigo.setBackgroundResource(R.drawable.amigoact);
                    friendsActivo=true;
                }
                break;*/

            //accion del boton Flecha
            case R.id.ivFlecha:
                lyFlecha.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                friendsActivo=false;
                copaActivo=false;

                if(flechaActivo){
                    flechaActivo=false;
                }else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivFlecha.setBackgroundResource(R.drawable.flechaact);
                    flechaActivo=true;
                }
                break;

            //accion del boton del cofre
            case R.id.ivChest:
                if(!camconActivo ) {
                    onClicks();
                    opcionesAtivo = false;
                    timeActivo = false;
                    flechaActivo = false;
                    friendsActivo = false;
                    copaActivo = false;

                    vidaChest = vidaChest - LoginActivity.user.getClickDamage();
                    if (vidaChest <= 0) {
                        vidaChest = 10;
                        if ((LoginActivity.user.getScore() + 3) <= LoginActivity.user.getCapacity()) {
                            LoginActivity.user.setScore(LoginActivity.user.getScore() + 3);
                            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                        } else {
                            LoginActivity.user.setScore(LoginActivity.user.getCapacity());
                            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                        }
                        ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtVida, "translationY", 100, 0);
                        transAnimatio1.setDuration(100).start();
                        ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(v, "translationY", -150, 0);
                        transAnimatio2.setDuration(100).start();
                    } else {
                        int x = (int) (Math.random() * 41) - 20;
                        int y = 20 - Math.abs(x);

                        ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(v, "translationX", x, 0);
                        ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(v, "translationY", y, 0);
                        AnimatorSet animSetXY = new AnimatorSet();
                        animSetXY.playTogether(transAnimationX, transAnimationY);
                        animSetXY.setDuration(300).start();

                    }
                    txtVida.setText(vidaChest + "");
                }
                break;
            //accion del boton reloj
            case R.id.ivReloj:

                lyTime.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                flechaActivo=false;
                friendsActivo=false;
                copaActivo=false;

                if(timeActivo){
                    timeActivo=false;
                }else {
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivReloj.setBackgroundResource(R.drawable.relojact);
                    timeActivo=true;
                }
                break;

            //accion del boton opciones
            case R.id.ivOpciones:

                btnOpc1.setVisibility(View.VISIBLE);
                btnOpc2.setVisibility(View.VISIBLE);
                timeActivo=false;
                flechaActivo=false;
                friendsActivo=false;
                copaActivo=false;

                if(opcionesAtivo){
                    opcionesAtivo=false;
                }
                else{
                    ObjectAnimator transAnimation= ObjectAnimator.ofFloat(btnOpc1, "translationX", 1000, 0);
                    transAnimation.setDuration(400).start();
                    ObjectAnimator transAnimationn= ObjectAnimator.ofFloat(btnOpc2, "translationX", 1000, 0);
                    transAnimationn.setDuration(500).start();
                    ivOpciones.animate().rotation(ivOpciones.getRotation()+90).setDuration(200);
                    opcionesAtivo=true;
                }
                break;
            default:
                break;
        }
    }

    /**
     * On clicks.
     */
    public void onClicks(){
        //cierra todos los botones activos si estan activos
        if(opcionesAtivo) {
            ObjectAnimator transAnimation = ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, 1000);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn = ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, 1000);
            transAnimationn.setDuration(500).start();
            ivOpciones.animate().rotation(ivOpciones.getRotation() - 90).setDuration(200);
        }
        if(timeActivo) {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivReloj.setBackgroundResource(R.drawable.reloj);
        }
        if(flechaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivFlecha.setBackgroundResource(R.drawable.flecha);
        }
        /*
        if(friendsActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyAmigos, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivAmigo.setBackgroundResource(R.drawable.amigo);
        }*/
        if(copaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivCopa.setBackgroundResource(R.drawable.copa);
        }
        if(camconActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", 0, -1000);
            transAnimatio1.setDuration(400).start();
            camconActivo=false;
        }
    }

    /**
     * Cambio contrasena.
     *
     * @param v the v
     */
    public void cambioContrasena(View v){
        lycamcon.setVisibility(View.VISIBLE);
        if(camconActivo){
            camconActivo=false;
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", 0, -1000);
            transAnimatio1.setDuration(400).start();
            if(passwordact.getText().toString().equals(passwordnew.getText().toString())){
                Toast.makeText(this, "son iguales", Toast.LENGTH_SHORT).show();
            }
            else{
                Query contra =LoginActivity.database.getReference("users").child(LoginActivity.user.getName().toString()).child("password");
                contra.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.getValue().equals(passwordact.getText().toString())){
                            DatabaseReference a =LoginActivity.database.getReference("users").child(LoginActivity.user.getName().toString()).child("password");
                            a.setValue(passwordnew.getText().toString());
                            LoginActivity.user.setPassword(passwordnew.getText().toString());
                            Toast.makeText(getApplicationContext(),"contraseña actualizada",Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"contraseña actual no coincide",Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {}
                });
            }
        }
        else{
            camconActivo=true;
            opcionesAtivo = false;
            ObjectAnimator transAnimation = ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, 1000);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn = ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, 1000);
            transAnimationn.setDuration(500).start();
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", -1000, 0);
            transAnimatio1.setDuration(600).start();
            ivOpciones.animate().rotation(ivOpciones.getRotation() - 90).setDuration(200);
            passwordact.setText("");
            passwordnew.setText("");

        }

    }

    /**
     * Salir on click.
     *
     * @param v the v
     */
    public void salirOnClick(View v){

        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        dialogo1.setTitle("Importante");
        dialogo1.setMessage("¿ Desea salir de esta cuenta ?");
        dialogo1.setCancelable(true);
        dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                Intent empezar = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(empezar);
                Clicker.tarea2.seguir=false;
                finish();
            }
        });
        dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {}
        });
        dialogo1.show();
    }

    /**
     * Damage on click.
     *
     * @param v the v
     */
    public void damageOnClick(View v){
        if(LoginActivity.user.getScore()>=precioDamage && LoginActivity.user.getDamage() < 10) {
            LoginActivity.user.setScore(LoginActivity.user.getScore() - precioDamage);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            LoginActivity.user.setDamage(LoginActivity.user.getDamage() + 1);
            txtDAct.setText("Act: " + LoginActivity.user.getDamage());
            precioDamage=(LoginActivity.user.getDamage()*100)+5;
            btnMDamage.setText("COSTE: "+precioDamage);

        }
    }

    /**
     * Speed on click.
     *
     * @param v the v
     */
    public void speedOnClick(View v){
        if(LoginActivity.user.getScore()>=precioSpeed && LoginActivity.user.getSpeed()>400) {
            LoginActivity.user.setScore(LoginActivity.user.getScore() - precioSpeed);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            LoginActivity.user.setSpeed(LoginActivity.user.getSpeed() - 10);
            txtSAct.setText("Act: " + LoginActivity.user.getSpeed());
            precioSpeed=(1000-LoginActivity.user.getSpeed())*10+20;
            btnMSpeed.setText("COSTE: "+precioSpeed);
        }
    }

    /**
     * Capacity on click.
     *
     * @param v the v
     */
    public void capacityOnClick(View v){
        if(LoginActivity.user.getScore()>=precioCapacity) {
            LoginActivity.user.setCapacity(LoginActivity.user.getCapacity() + 10);
            txtCAct.setText("Act: " + LoginActivity.user.getCapacity());
            LoginActivity.user.setScore(LoginActivity.user.getScore()-precioCapacity);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            precioCapacity=LoginActivity.user.getCapacity();
            btnMCapacity.setText("COSTE: "+precioCapacity);
        }
    }

    /**
     * Clickdamage on click.
     *
     * @param v the v
     */
    public void ClickdamageOnClick(View v){
        if(LoginActivity.user.getScore()>=precioClickDamage && LoginActivity.user.getClickDamage()<10) {
            LoginActivity.user.setClickDamage(LoginActivity.user.getClickDamage() + 1);
            txtCDAct.setText("Act: " + LoginActivity.user.getClickDamage());
            LoginActivity.user.setScore(LoginActivity.user.getScore()-precioClickDamage);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            precioClickDamage=LoginActivity.user.getClickDamage()*120;
            btnMClickDamage.setText("COSTE: "+precioClickDamage);
        }
    }
/*
    public void numFriendsOnClick(View v){
        if(LoginActivity.user.getNumFriends()<5) {
            LoginActivity.user.setNumFriends(LoginActivity.user.getNumFriends() + 1);
            txtNFAct.setText("Act: " + LoginActivity.user.getNumFriends());
        }
    }*/

    //******************************CONTROL SALIDA DE LA APP*****************************************
    private static final int INTERVALO = 2000; //2 segundos para salir
    private long tiempoPrimerClick;

    @Override
    public void onBackPressed(){
        if(opcionesAtivo || timeActivo || flechaActivo || friendsActivo || copaActivo || camconActivo) {
            onClicks();
            opcionesAtivo = false;
            timeActivo = false;
            flechaActivo = false;
            friendsActivo = false;
            copaActivo = false;
        }
        else{
            if (tiempoPrimerClick + INTERVALO > System.currentTimeMillis()) {
                super.onBackPressed();
                finish();
                tarea2.seguir = false;
                return;
            } else {
                Toast.makeText(this, "Vuelve a presionar para salir", Toast.LENGTH_SHORT).show();

            }
            tiempoPrimerClick = System.currentTimeMillis();
        }
    }
}
