package proyecto_esquimal;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class Game extends JPanel {
    final int record = 30000;
    boolean pausa=false;
    int imagenCele = 0;
    int alto;
    int ancho;
    int anchosp;
    static char[][] mapa;
    int puntaje=0;
    int pieza;
    int siguiente;
    static boolean volando=false;
    boolean rapido=true;
    static int cs=0;
    int rs=0;
    Palo palo;
    Cubo cubo;
    Zeta zeta;
    Pato pato;
    Ele ele;
    Jota jota;
    Micro micro;
    
    public Game() {
        
        mapa = new char[10][20];
        alto=(Main.altof)/24;
        ancho=((Main.anchof)/2)-(alto*mapa.length/2);
        anchosp=((Main.anchof)/2)+(alto*mapa.length/2)+alto;
        siguiente=(int) (Math.random() * 7) + 1;
        for (int j = 0; j < mapa.length*2; j++) {
            for (int i = 0; i < mapa.length; i++) {
                mapa[i][j]=' ';
            }
        }
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                rapido=true;
            }

            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_P){
                    if(pausa==false){
                        pausa=true;
                    }else{
                        pausa=false;
                    }
                    System.out.println(pausa);
                }
                if(e.getKeyCode() == KeyEvent.VK_RIGHT){
                    if(pausa==false)
                        switch(pieza){
                            case 1:
                                if(palo.comprobarRight()==true){
                                    palo.moverX(1);
                                }
                                break;
                            case 2:
                                if(cubo.comprobarRight()==true){
                                    cubo.moverX(1);
                                }
                                break;
                            case 3:
                                if(zeta.comprobarRight()==true){
                                    zeta.moverX(1);
                                }
                                break;
                            case 4:
                                if(pato.comprobarRight()==true){
                                    pato.moverX(1);
                                }
                                break;
                            case 5:
                                if(ele.comprobarRight()==true){
                                    ele.moverX(1);
                                }
                                break;
                            case 6:
                                if(jota.comprobarRight()==true){
                                    jota.moverX(1);
                                }
                                break;
                            case 7:
                                if(micro.comprobarRight()==true){
                                    micro.moverX(1);
                                }
                                break;
                    }
                }
                if(e.getKeyCode() == KeyEvent.VK_LEFT){
                    if(pausa==false)
                        switch(pieza){
                            case 1:
                                if(palo.comprobarLeft()==true){
                                    palo.moverX(-1);
                                }
                                break;
                            case 2:
                                if(cubo.comprobarLeft()==true){
                                    cubo.moverX(-1);
                                }
                                break;
                            case 3:
                                if(zeta.comprobarLeft()==true){
                                    zeta.moverX(-1);
                                }
                                break;
                            case 4:
                                if(pato.comprobarLeft()==true){
                                    pato.moverX(-1);
                                }
                                break;
                            case 5:
                                if(ele.comprobarLeft()==true){
                                    ele.moverX(-1);
                                }
                                break;
                            case 6:
                                if(jota.comprobarLeft()==true){
                                    jota.moverX(-1);
                                }
                                break;
                            case 7:
                                if(micro.comprobarLeft()==true){
                                    micro.moverX(-1);
                                }
                                break;
                    }
                }
                if(e.getKeyCode() == KeyEvent.VK_UP){
                    if(pausa==false)
                        switch(pieza){
                            case 1:
                                if(palo.comprobarCambio()==true){
                                    palo.cambioPosicion();
                                }
                                break;
                            case 3:
                                if(zeta.comprobarCambio()==true){
                                    zeta.cambioPosicion();
                                }
                                break;
                            case 4:
                                if(pato.comprobarCambio()==true){
                                    pato.cambioPosicion();
                                }
                                break;
                            case 5:
                                if(ele.comprobarCambio()==true){
                                    ele.cambioPosicion();
                                }
                                break;
                            case 6:
                                if(jota.comprobarCambio()==true){
                                    jota.cambioPosicion();
                                }
                                break;
                            case 7:
                                if(micro.comprobarCambio()==true){
                                    micro.cambioPosicion();
                                }
                                break;
                    }
                }
                if(e.getKeyCode() == KeyEvent.VK_DOWN){
                    if(pausa==false)
                        switch(pieza){
                            case 1:
                                if(palo.comprobarDown()==true){
                                    if(rapido==true){
                                        palo.move();
                                    }
                                }
                                else{
                                    palo.finiquitao();
                                    rapido=false;
                                }
                                break;
                            case 2:
                                if(cubo.comprobarDown()==true){
                                    if(rapido==true){
                                        cubo.move();
                                    }
                                }
                                else{
                                    cubo.finiquitao();
                                    rapido=false;
                                }
                                break;
                            case 3:
                                if(zeta.comprobarDown()==true){
                                    if(rapido==true){
                                        zeta.move();
                                    }
                                }
                                else{
                                    zeta.finiquitao();
                                    rapido=false;
                                }
                                break;
                            case 4:
                                if(pato.comprobarDown()==true){
                                    if(rapido==true){
                                        pato.move();
                                    }
                                }
                                else{
                                    pato.finiquitao();
                                    rapido=false;
                                }
                                break;
                            case 5:
                                if(ele.comprobarDown()==true){
                                   if(rapido==true){
                                        ele.move();
                                    } 
                                }
                                else{
                                    ele.finiquitao();
                                    rapido=false;
                                }
                                break;
                            case 6:
                                if(jota.comprobarDown()==true){
                                   if(rapido==true){
                                        jota.move();
                                    } 
                                }
                                else{
                                    jota.finiquitao();
                                    rapido=false;
                                }
                                break;
                            case 7:
                                if(micro.comprobarDown()==true){
                                   if(rapido==true){
                                        micro.move();
                                    }
                                }
                                else{
                                    micro.finiquitao();
                                    rapido=false;
                                }
                                break;
                    }
                }
            }
        });
        setFocusable(true);
    }
    
    public void move() {
        if(pausa==false){
            if(volando==false){
                puntaje+=100;
                if(rs<=45){
                    rs++;
                }
                volando=true;
                comprobarFilas();
                elegirPieza();

            }
            if(cs%(50)==0){
                switch(pieza){
                    case 1:
                        if(palo.comprobarDown()==true){
                            palo.move();
                        }
                        else{
                            palo.finiquitao();
                        }
                        break;
                    case 2:
                        if(cubo.comprobarDown()==true){
                            cubo.move();
                        }
                        else{
                            cubo.finiquitao();
                        }
                        break;
                    case 3:
                        if(zeta.comprobarDown()==true){
                            zeta.move();
                        }
                        else{
                            zeta.finiquitao();
                        }
                        break;
                    case 4:
                        if(pato.comprobarDown()==true){
                            pato.move();
                        }
                        else{
                            pato.finiquitao();
                        }
                        break;
                    case 5:
                        if(ele.comprobarDown()==true){
                            ele.move();
                        }
                        else{
                            ele.finiquitao();
                        }
                        break;
                    case 6:
                        if(jota.comprobarDown()==true){
                            jota.move();
                        }
                        else{
                            jota.finiquitao();
                        }
                        break;
                    case 7:
                        if(micro.comprobarDown()==true){
                            micro.move();
                        }
                        else{
                            micro.finiquitao();
                        }
                        break;
                }
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        if(imagenCele!=0){
            imagenCele++;
            if(imagenCele>50)
                imagenCele=0;
        }
        super.paint(g);
        ImageIcon Img = new ImageIcon(getClass().getResource("/Images/fondo.png"));
        ImageIcon ImgFlechas = new ImageIcon(getClass().getResource("/Images/up.png"));
        ImageIcon ImgP = new ImageIcon(getClass().getResource("/Images/p.png"));
        ImageIcon ImgPausa = new ImageIcon(getClass().getResource("/Images/pausa.png"));
        ImageIcon ImgFrog = new ImageIcon(getClass().getResource("/Images/frog.gif"));
        g.drawImage(Img.getImage(), -(1920/2)+(Main.anchof/2), -6, this);
        g.setColor(Color.black);
        g.setFont(new Font("Verdana", Font.BOLD, 20));
        g.drawString("Cambio", (Main.anchof/2)-(30/2)-alto*10, 470);
        g.drawImage(ImgFlechas.getImage(),(Main.anchof/2)-(30/2)-alto*12, 450, 30, 30, this);
        g.drawString("Pausar", (Main.anchof/2)-(30/2)-alto*10, 420);
        g.drawImage(ImgP.getImage(), (Main.anchof/2)-(30/2)-alto*12, 400, 30, 30, this);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.GRAY);
        g2d.setFont(new Font("Verdana", Font.BOLD, alto));
        g2d.drawString("Score: "+(puntaje-100), ancho, alto*3/2);
        paintSigPieza(g2d);
        Color fondo=new Color(0,0,0,200);
        g2d.setColor(fondo);
        g2d.fillRect(ancho, alto*2, alto*10, alto*20);
        
        for (int j = 0; j < mapa.length*2; j++) {
            for (int i = 0; i < mapa.length; i++) {
                Color ei=new Color(0,178,255);
                g2d.setColor(ei);
                if(puntaje>record){
                    Color ei2=new Color(72,255,0);
                    g2d.setColor(ei2);
                }
                g.drawLine(Main.anchof/2, Main.altof-100, Main.anchof/2, Main.altof);
                g.drawLine(ancho, Main.altof-60, ancho-70, Main.altof);
                g.drawLine(ancho+alto, Main.altof-60, ancho+alto-60, Main.altof);
                g.drawLine(ancho+alto*2, Main.altof-60, ancho+alto*2-45, Main.altof);
                g.drawLine(ancho+alto*3, Main.altof-60, ancho+alto*3-30, Main.altof);
                g.drawLine(ancho+alto*4, Main.altof-60, ancho+alto*4-15, Main.altof);
                g.drawLine(ancho+alto*6, Main.altof-60, ancho+alto*6+15, Main.altof);
                g.drawLine(ancho+alto*7, Main.altof-60, ancho+alto*7+30, Main.altof);
                g.drawLine(ancho+alto*8, Main.altof-60, ancho+alto*8+45, Main.altof);
                g.drawLine(ancho+alto*9, Main.altof-60, ancho+alto*9+60, Main.altof);
                g.drawLine(ancho+alto*10, Main.altof-60, ancho+alto*10+70, Main.altof);
                g2d.drawRect(i*alto+ancho, j*(alto)+alto*2, alto, alto);
                if(imagenCele!=0){
                g.drawImage(ImgFrog.getImage(), (Main.anchof/2)-(64/2), Main.altof-124, 64, 64, this);
                }
                if(mapa[i][j]=='x'){
                    Color ola=new Color(212,37,0);
                    g.setColor(ola);
                    if(puntaje>record){
                        Color ei2=new Color(55,136,22);
                        g.setColor(ei2);
                    }
                    g.fillRect(i*alto+ancho+1, j*(alto)+alto*2+1, alto-1, alto-1);
                }
                if(mapa[i][j]=='o'){
                    Color puesto=new Color(22,129,210);
                    g.setColor(puesto);
                    if(puntaje>record){
                        Color ei2=new Color(126,27,156);
                        g.setColor(ei2);
                    }
                    g.fillRect(i*alto+ancho+1, j*(alto)+alto*2+1, alto-1, alto-1);
                }
            }
        }
        if(pausa==true){
            g.drawImage(Img.getImage(), -(1920/2)+(Main.anchof/2), -6, this);
            g.drawImage(ImgPausa.getImage(), (Main.anchof/2)-(100/2), (Main.altof/2)-(100/2), 100, 100, this);
        }
    }
    void paintSigPieza(Graphics2D g){
        Color ei=new Color(0,178,255);
        g.setColor(ei);
        if(puntaje>record){
            Color ei2=new Color(72,255,0);
            g.setColor(ei2);
        }
        g.drawRect(anchosp-1, alto*2-1, alto*3+1, alto*4+1);
        Color ola=new Color(212,37,0);
        g.setColor(ola);
        if(puntaje>record){
            Color ei2=new Color(55,136,22);
            g.setColor(ei2);
        }
        switch(siguiente){
            case 1:
                g.fillRect(anchosp+alto, alto*2, alto, alto);
                g.fillRect(anchosp+alto, alto*3, alto, alto);
                g.fillRect(anchosp+alto, alto*4, alto, alto);
                g.fillRect(anchosp+alto, alto*5, alto, alto);
                break;
            case 2:
                g.fillRect(anchosp+alto/2, alto*3, alto, alto);
                g.fillRect(anchosp+alto/2, alto*4, alto, alto);
                g.fillRect(anchosp+alto+alto/2, alto*3, alto, alto);
                g.fillRect(anchosp+alto+alto/2, alto*4, alto, alto);
                break;
            case 3:
                g.fillRect(anchosp, alto*3, alto, alto);
                g.fillRect(anchosp+alto, alto*3, alto, alto);
                g.fillRect(anchosp+alto, alto*4, alto, alto);
                g.fillRect(anchosp+alto*2, alto*4, alto, alto);
                break;
            case 4:
                g.fillRect(anchosp, alto*4, alto, alto);
                g.fillRect(anchosp+alto, alto*3, alto, alto);
                g.fillRect(anchosp+alto, alto*4, alto, alto);
                g.fillRect(anchosp+alto*2, alto*3, alto, alto);
                break;
            case 5:
                g.fillRect(anchosp+alto-alto/2, alto*2+alto/2, alto, alto);
                g.fillRect(anchosp+alto-alto/2, alto*3+alto/2, alto, alto);
                g.fillRect(anchosp+alto-alto/2, alto*4+alto/2, alto, alto);
                g.fillRect(anchosp+alto*2-alto/2, alto*4+alto/2, alto, alto);
                break;
            case 6:
                g.fillRect(anchosp+alto+alto/2, alto*2+alto/2, alto, alto);
                g.fillRect(anchosp+alto+alto/2, alto*3+alto/2, alto, alto);
                g.fillRect(anchosp+alto+alto/2, alto*4+alto/2, alto, alto);
                g.fillRect(anchosp+alto/2, alto*4+alto/2, alto, alto);
                break;
            case 7:
                g.fillRect(anchosp, alto*4, alto, alto);
                g.fillRect(anchosp+alto, alto*3, alto, alto);
                g.fillRect(anchosp+alto, alto*4, alto, alto);
                g.fillRect(anchosp+alto*2, alto*4, alto, alto);
                break;
        }
    }
    void elegirPieza(){
        pieza=siguiente;
        siguiente= (int) (Math.random() * 7) + 1;
        switch(pieza){
            case 1:
                palo=new Palo();
                break;
            case 2:
                cubo=new Cubo();
                break;
            case 3:
                zeta=new Zeta();
                break;
            case 4:
                pato=new Pato();
                break;
            case 5:
                ele=new Ele();
                break;
            case 6:
                jota=new Jota();
                break;
            case 7:
                micro=new Micro();
                break;
        }
    }
    
    void comprobarFilas(){
        boolean completa=true;
        int num=0;
        for (int j = mapa.length*2-1; j>=0; j--) {
            
            for (int i = 0; i < mapa.length; i++) {
                if(mapa[i][j]==' '){
                    completa=false;
                }
            }
            if(completa==true){
                imagenCele++;
                num++;
                for (int i = 0; i < mapa.length; i++) {
                    mapa[i][j]=' ';
                }
                puntaje+=1000;
            }
            for (int i = 0; i < mapa.length; i++) {
                if(mapa[i][j]=='o'){
                    mapa[i][j]=' ';
                    mapa[i][j+num]='o';
                }
            }
            completa=true;
        }
    }
}
