package Modelo;

public class Productos {
    private int codigo;
    private String nombre;
    private String fecha;
    private String urlImagen;
    private String descripcion;

    public Productos() {
    }

    public Productos(int codigo, String nombre, String fecha, String urlImagen, String descripcion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.fecha = fecha;
        this.urlImagen = urlImagen;
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getUrlImagen() {
        return urlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }
}
