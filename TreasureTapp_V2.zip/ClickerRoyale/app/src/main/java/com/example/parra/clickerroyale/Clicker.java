package com.example.parra.clickerroyale;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Objects;

import tyrantgit.explosionfield.ExplosionField;

/**
 * The type Clicker.
 */
public class Clicker extends AppCompatActivity implements View.OnClickListener{

    //region variables

    private DatabaseReference bd = LoginActivity.dbUsers.child(LoginActivity.user.getName());

    static ExplosionField explosionField;

    static ImageView ivChestExplote;

    TextView txtMCapacitySuma;

    static TextView txtAviso;

    static ImageView ivmundo;

    static ImageView ivMoneda;

    static LinearLayout lyCopaSub;

    ImageView ivCarga;

    boolean guardadoManual;

    static DisplayMetrics metrics;

    /**
     * The Hadler.
     */
    Handler hadler = new Handler();
    /**
     * The Runneables.
     */
    Runnable runneable;
    Runnable runneable2;
    Runnable runneable3;
    Runnable runneable4;
    Runnable runneable5;

    /**
     * The constant vidaChest.
     */
//vida cofres
    static int vidaChest;

    static int oro;

    /**
     * The Btn opc 1.
     */
//botones
    Button btnOpc1;
    /**
     * The Btn opc 2.
     */
    Button btnOpc2;
    /**
     * The Btn opc 3.
     */
    Button btnOpc3;
    /**
     * The Btn opc 4.
     */
    Button btnOpc4;
    /**
     * The Iv copa.
     */
    Button ivCopa;
    /**
     * The Iv flecha.
     */
    Button ivFlecha;
    /**
     * The Iv reloj.
     */
    Button ivReloj;
    /**
     * The Btn m damage.
     */
    Button btnMDamage, /**
     * The Btn m speed.
     */
    btnMSpeed, /**
     * The Btn m capacity.
     */
    btnMCapacity, /**
     * The Btn m click damage.
     */
    btnMClickDamage,

    btnMGoldInactive;

    /**
     * The Ly time.
     */
//layouts
    View lyTime;
    /**
     * The Ly flecha.
     */
    View lyFlecha;
    /**
     * The Ly copa.
     */
//View lyAmigos;
    View lyCopa;
    /**
     * The Lycamcon.
     */
    View lycamcon;

    /**
     * The constant txtScore.
     */
//text
    static TextView txtScore;
    /**
     * The Txt vida.
     */
    static TextView txtVida;
    /**
     * The Txt nombre.
     */
    TextView txtNombre;
    /**
     * The Lb n 1.
     */
    static TextView lbN1, /**
     * The Lb n 2.
     */
    lbN2, /**
     * The Lb n 3.
     */
    lbN3, /**
     * The Lb n 4.
     */
    lbN4, /**
     * The Lb n 5.
     */
    lbN5, /**
     * The Lb s 1.
     */
    lbS1, /**
     * The Lb s 2.
     */
    lbS2, /**
     * The Lb s 3.
     */
    lbS3, /**
     * The Lb s 4.
     */
    lbS4, /**
     * The Lb s 5.
     */
    lbS5;
    /**
     * The Txt d act.
     */
    TextView txtDAct, /**
     * The Txt s act.
     */
    txtSAct, /**
     * The Txt c act.
     */
    txtCAct, /**
     * The Txt cd act.
     */
    txtCDAct,

    txtGIAct;
    /**
     * The Passwordact.
     */
    EditText passwordact, /**
     * The Passwordnew.
     */
    passwordnew;


    /**
     * The Iv opciones.
     */
//imagenes
    ImageView ivOpciones;
    /**
     * The Iv chest.
     */
    static ImageView ivChest;


    /**
     * The Opciones ativo.
     */
//booleans controladores
    boolean opcionesAtivo;
    /**
     * The Time activo.
     */
    boolean timeActivo;
    /**
     * The Flecha activo.
     */
    boolean flechaActivo;
    /**
     * The Copa activo.
     */
    boolean copaActivo;
    /**
     * The Camcon activo.
     */
    boolean camconActivo;

    /**
     * The Precio capacity.
     */
//precios
    int precioCapacity;
    /**
     * The Precio damage.
     */
    int precioDamage;
    /**
     * The Precio speed.
     */
    int precioSpeed;
    /**
     * The Precio click damage.
     */
    int precioClickDamage;
    /**
     * The Precio oro inactivo.
     */
    int precioGoldInactive;

    /**
     * The Tarea 2.
     */
    static ParraAsyncTask tarea2;

    //endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicker);

        InitComponents();

        ivChest.setOnClickListener(this);
        ivReloj.setOnClickListener(this);
        ivOpciones.setOnClickListener(this);
        ivFlecha.setOnClickListener(this);
        ivCopa.setOnClickListener(this);


        OroExtraInactivo();
    }

    //region MÉTODOS ÚTILES

    private int CalculoPrecioCapacity(){
        return LoginActivity.user.getCapacity() - (LoginActivity.user.getCapacity()/8);
    }

    private int CalculoPrecioSpeed(){
        return (int) (Math.pow(4,(1000 - LoginActivity.user.getSpeed())/10) + 30);
    }

    private int CalculoPrecioDamage(){
        return (int) (Math.pow(3,LoginActivity.user.getDamage()) + 5);
    }

    private int CalculoPrecioClickDamage(){
        return (int) (Math.pow(3,LoginActivity.user.getClickDamage()) + 34);
    }

    private int CalculoPrecioGoldInactive(){
        return (int) (Math.pow(4,LoginActivity.user.getDpsInactive()) + 100);
    }

    @SuppressLint("SetTextI18n")
    private void InitComponents(){
        vidaChest = Math.round(LoginActivity.user.getCapacity()/10);
        oro = (vidaChest / 5) + 1;
        precioCapacity = CalculoPrecioCapacity();
        precioDamage = CalculoPrecioDamage();
        precioSpeed = CalculoPrecioSpeed();
        precioClickDamage = CalculoPrecioClickDamage();
        precioGoldInactive = CalculoPrecioGoldInactive();
        opcionesAtivo=false;
        timeActivo=false;
        flechaActivo=false;
        copaActivo=false;
        camconActivo=false;
        guardadoManual = true;

        runneable = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(txtVida, "translationY", 500, 0);
                transAnimatio1.setDuration(100).start();
                ObjectAnimator transAnimatio2 = ObjectAnimator.ofFloat(ivChest, "translationY", -500, 0);
                transAnimatio2.setDuration(100).start();
                ivChest.setEnabled(true);
                ivChest.setVisibility(View.VISIBLE);
                txtVida.setVisibility(View.VISIBLE);
                explosionField.clear();
                txtVida.setText(vidaChest + "");
            }
        };

        runneable2 = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                if ((LoginActivity.user.getScore() + oro) <= LoginActivity.user.getCapacity()) {
                    LoginActivity.user.setScore(LoginActivity.user.getScore() + oro);
                    txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                } else {
                    LoginActivity.user.setScore(LoginActivity.user.getCapacity());
                    txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                }
                ivChest.setImageResource(R.drawable.chest);
                ivChest.setVisibility(View.GONE);
                ivmundo.animate().rotation(ivmundo.getRotation()+60).setDuration(200);
            }
        };

        runneable3 = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivmundo, "translationY", 0, 30);
                transAnimatio1.setDuration(50).start();
            }
        };

        runneable4 = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(ivmundo, "translationY", 30, 0);
                transAnimatio1.setDuration(50).start();
            }
        };

        runneable5 = new Runnable() {
            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                txtAviso.setText("");
                btnOpc3.setEnabled(true);
            }
        };

        ivOpciones = findViewById(R.id.ivOpciones);
        ivChest = findViewById(R.id.ivChest);
        ivChestExplote = findViewById(R.id.ivChestExplote);
        ivMoneda = findViewById(R.id.ivMoneda);
        ivCarga = findViewById(R.id.ivCarga);
        ivmundo = findViewById(R.id.mundo);
        txtScore = findViewById(R.id.txtScore);
        txtVida = findViewById(R.id.txtVida);
        txtNombre = findViewById(R.id.txtNombre);
        txtAviso = findViewById(R.id.txtAvisos);
        txtMCapacitySuma = findViewById(R.id.txtMCapacitySuma);
        lbN1 = findViewById(R.id.lbNombre1);
        lbN2 = findViewById(R.id.lbNombre2);
        lbN3 = findViewById(R.id.lbNombre3);
        lbN4 = findViewById(R.id.lbNombre4);
        lbN5 = findViewById(R.id.lbNombre5);
        lbS1 = findViewById(R.id.lbScore1);
        lbS2 = findViewById(R.id.lbScore2);
        lbS3 = findViewById(R.id.lbScore3);
        lbS4 = findViewById(R.id.lbScore4);
        lbS5 = findViewById(R.id.lbScore5);
        txtDAct = findViewById(R.id.txtMDamageAct);
        txtSAct = findViewById(R.id.txtMSpeedAct);
        txtCAct = findViewById(R.id.txtMCapacitydAct);
        txtCDAct = findViewById(R.id.txtMCDamageAct);
        txtGIAct = findViewById(R.id.txtMOInactivoAct);
        btnOpc1 = findViewById(R.id.btnOpciones1);
        btnOpc2 = findViewById(R.id.btnOpciones2);
        btnOpc3 = findViewById(R.id.btnOpciones3);
        btnOpc4 = findViewById(R.id.btnOpciones4);
        lyTime = findViewById(R.id.lyTime);
        lyFlecha = findViewById(R.id.lyFlecha);
        lyCopa = findViewById(R.id.lyCopa);
        lyCopaSub = findViewById(R.id.lyCopaSub);
        lycamcon = findViewById(R.id.lycamcon);
        ivReloj = findViewById(R.id.ivReloj);
        ivFlecha = findViewById(R.id.ivFlecha);
        ivCopa = findViewById(R.id.ivCopa);
        btnMDamage = findViewById(R.id.btnMejoraDamage);
        btnMSpeed = findViewById(R.id.btnMejoraSpeed);
        btnMCapacity = findViewById(R.id.btnMejoraCapacity);
        btnMClickDamage = findViewById(R.id.btnMejoraDanoClick);
        btnMGoldInactive = findViewById(R.id.btnMejoraOroInactivo);
        passwordact = findViewById(R.id.etpassact);
        passwordnew = findViewById(R.id.etpassnew);

        metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
        txtVida.setText(vidaChest+"");
        txtNombre.setText(LoginActivity.user.getName()+"");
        txtDAct.setText("Act: "+LoginActivity.user.getDamage());
        txtSAct.setText("Act: "+LoginActivity.user.getSpeed());
        txtCAct.setText("Act: "+LoginActivity.user.getCapacity());
        txtCDAct.setText("Act: "+LoginActivity.user.getClickDamage());
        txtGIAct.setText("Act: "+LoginActivity.user.getDpsInactive());
        btnMClickDamage.setText(R.string.CostSp +": "+precioClickDamage);
        btnMDamage.setText(R.string.CostSp +": "+precioDamage);
        btnMSpeed.setText(R.string.CostSp +": "+precioSpeed);
        btnMCapacity.setText(R.string.CostSp +": "+precioCapacity);
        btnMGoldInactive.setText(R.string.CostSp +": "+precioGoldInactive);

        explosionField = ExplosionField.attach2Window(this);

        tarea2 = new ParraAsyncTask(this);
    }

    private void OroExtraInactivo(){
        int dineroExtra = compararFechas();
        if(dineroExtra != 0) {
            String mensaje;
            if(dineroExtra > (LoginActivity.user.getCapacity() - LoginActivity.user.getScore())){
                dineroExtra = (LoginActivity.user.getCapacity() - LoginActivity.user.getScore());
                mensaje = "¡Has llenado todo de oro!, por estar inactivo durante " + dineroExtra / LoginActivity.user.getDpsInactive() + " minutos.";
            }
            else
                mensaje = "¡Has ganado " + dineroExtra + " de oro!, por estar inactivo durante " + dineroExtra / LoginActivity.user.getDpsInactive() + " minutos.";

            AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
            dialogo1.setTitle("Oro Inactivo");
            dialogo1.setMessage(mensaje);
            dialogo1.setCancelable(false);
            final int finalDineroExtra = dineroExtra;
            dialogo1.setPositiveButton("Recoger", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    LoginActivity.user.setScore(LoginActivity.user.getScore() + finalDineroExtra);
                    txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                    tarea2.seguir=true;
                    tarea2.execute();
                }
            });
            dialogo1.show();
        }
        else{
            tarea2.seguir=true;
            tarea2.execute();
        }
    }

    private int compararFechas(){
        Calendar calendar;
        calendar = Calendar.getInstance();

        int minutosHoy = calendar.get(Calendar.MINUTE) + (calendar.get(Calendar.HOUR_OF_DAY) * 60) + (calendar.get(Calendar.DAY_OF_YEAR) * 1440) + (calendar.get(Calendar.YEAR) * 525600);
        int minutosUltima = LoginActivity.user.getDate().getMinute() + (LoginActivity.user.getDate().getHour()*60) + (LoginActivity.user.getDate().getDay()*1440) + (LoginActivity.user.getDate().getYear()*525600);

        return ((minutosHoy - minutosUltima) * LoginActivity.user.getDpsInactive());
    }

    //endregion

    //region ON CLICKS MENUS

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {
        if(v.getId()!=R.id.ivChest){
            onClicks();
        }

        //selecciona el boton que estas usando
        switch (v.getId()) {

            //accion del boton copa
            case R.id.ivCopa:
                lyCopa.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                flechaActivo=false;

                if(copaActivo){
                    copaActivo=false;

                }
                else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivCopa.setBackgroundResource(R.drawable.copaact);
                    copaActivo=true;
                    LoginActivity.creacionLeaderboard();
                    ivCarga.animate().rotation(ivCarga.getRotation()+1800).setDuration(10000);
                    lyCopaSub.setVisibility(View.GONE);
                }
                break;

            //accion del boton Flecha
            case R.id.ivFlecha:
                lyFlecha.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                timeActivo=false;
                copaActivo=false;

                if(flechaActivo){
                    flechaActivo=false;
                }else{
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivFlecha.setBackgroundResource(R.drawable.flechaact);
                    flechaActivo=true;
                }
                break;

            //accion del boton del cofre
            case R.id.ivChest:
                if(!camconActivo ) {
                    onClicks();
                    opcionesAtivo = false;
                    timeActivo = false;
                    flechaActivo = false;
                    copaActivo = false;

                    vidaChest = vidaChest - LoginActivity.user.getClickDamage();
                    if (vidaChest <= 0) {
                        vidaChest = Math.round(LoginActivity.user.getCapacity()/10);
                        explosionField.explode(ivChestExplote);
                        explosionField.expandExplosionBound(200,200);
                        hadler.postDelayed(runneable4,600);
                        hadler.postDelayed(runneable3,550);
                        hadler.postDelayed(runneable,500);
                        hadler.postDelayed(runneable2,300);
                        ivChest.setImageResource(R.drawable.chestfinal);
                        ivChest.setEnabled(false);
                        txtVida.setVisibility(View.GONE);
                        ivMoneda.setVisibility(View.VISIBLE);
                        ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(ivMoneda, "translationX", Math.round(metrics.widthPixels/2), 0);
                        ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(ivMoneda, "translationY", Math.round(metrics.heightPixels/2), 0);
                        AnimatorSet animSetXY = new AnimatorSet();
                        animSetXY.playTogether(transAnimationX, transAnimationY);
                        animSetXY.setDuration(300).start();
                    } else {
                        int x = (int) (Math.random() * 41) - 20;
                        int y = 20 - Math.abs(x);

                        ObjectAnimator transAnimationX = ObjectAnimator.ofFloat(v, "translationX", x, 0);
                        ObjectAnimator transAnimationY = ObjectAnimator.ofFloat(v, "translationY", y, 0);
                        AnimatorSet animSetXY = new AnimatorSet();
                        animSetXY.playTogether(transAnimationX, transAnimationY);
                        animSetXY.setDuration(300).start();
                    }
                    txtVida.setText(vidaChest + "");
                }
                break;
            //accion del boton reloj
            case R.id.ivReloj:

                lyTime.setVisibility(View.VISIBLE);
                opcionesAtivo=false;
                flechaActivo=false;
                copaActivo=false;

                if(timeActivo){
                    timeActivo=false;
                }else {
                    ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 1000, 0);
                    transAnimatio1.setDuration(400).start();
                    ivReloj.setBackgroundResource(R.drawable.relojact);
                    timeActivo=true;
                }
                break;

            //accion del boton opciones
            case R.id.ivOpciones:

                btnOpc1.setVisibility(View.VISIBLE);
                btnOpc2.setVisibility(View.VISIBLE);
                btnOpc3.setVisibility(View.VISIBLE);
                if(guardadoManual)
                    btnOpc4.setVisibility(View.VISIBLE);
                timeActivo=false;
                flechaActivo=false;
                copaActivo=false;

                if(opcionesAtivo){
                    opcionesAtivo=false;
                }
                else{
                    ObjectAnimator transAnimation= ObjectAnimator.ofFloat(btnOpc1, "translationX", 1000, 0);
                    transAnimation.setDuration(400).start();
                    ObjectAnimator transAnimationn= ObjectAnimator.ofFloat(btnOpc2, "translationX", 1000, 0);
                    transAnimationn.setDuration(500).start();
                    ObjectAnimator transAnimationnn= ObjectAnimator.ofFloat(btnOpc3, "translationX", 1000, 0);
                    transAnimationnn.setDuration(600).start();
                    if(guardadoManual) {
                        ObjectAnimator transAnimationnnn = ObjectAnimator.ofFloat(btnOpc4, "translationX", 1000, 0);
                        transAnimationnnn.setDuration(700).start();
                    }
                    ivOpciones.animate().rotation(ivOpciones.getRotation()+90).setDuration(200);
                    opcionesAtivo=true;
                }
                break;
            default:
                break;
        }
    }

    /**
     * On clicks.
     */
    public void onClicks(){
        //cierra todos los botones activos si estan activos
        if(opcionesAtivo) {
            ObjectAnimator transAnimation = ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, 1000);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn = ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, 1000);
            transAnimationn.setDuration(500).start();
            ObjectAnimator transAnimationnn= ObjectAnimator.ofFloat(btnOpc3, "translationX", 0, 1000);
            transAnimationnn.setDuration(600).start();
            ObjectAnimator transAnimationnnn = ObjectAnimator.ofFloat(btnOpc4, "translationX", 0, 1000);
            transAnimationnnn.setDuration(700).start();
            ivOpciones.animate().rotation(ivOpciones.getRotation() - 90).setDuration(200);
        }
        if(timeActivo) {
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyTime, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivReloj.setBackgroundResource(R.drawable.reloj);
        }
        if(flechaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyFlecha, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivFlecha.setBackgroundResource(R.drawable.flecha);
        }
        if(copaActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lyCopa, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
            ivCopa.setBackgroundResource(R.drawable.copa);
        }
        if(camconActivo){
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", 0, -1000);
            transAnimatio1.setDuration(400).start();
            camconActivo=false;
        }
    }

    //endregion

    //region ON CLICKS OPCIONES

    /**
     * Cambio contrasena.
     *
     * @param v the v
     */
    public void cambioContrasena(View v){
        lycamcon.setVisibility(View.VISIBLE);
        if(camconActivo){
            camconActivo=false;
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", 0, -1000);
            transAnimatio1.setDuration(400).start();
            if(passwordact.getText().toString().equals(passwordnew.getText().toString())){
                Toast.makeText(this, "son iguales", Toast.LENGTH_SHORT).show();
            }
            else{
                Query contra =LoginActivity.database.getReference("users").child(LoginActivity.user.getName().toString()).child("password");
                contra.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(Objects.equals(dataSnapshot.getValue(), passwordact.getText().toString())){
                            DatabaseReference a =LoginActivity.database.getReference("users").child(LoginActivity.user.getName().toString()).child("password");
                            a.setValue(passwordnew.getText().toString());
                            LoginActivity.user.setPassword(passwordnew.getText().toString());
                            Toast.makeText(getApplicationContext(),"contraseña actualizada",Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"contraseña actual no coincide",Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {}
                });
            }
        }
        else{
            camconActivo=true;
            opcionesAtivo = false;
            ObjectAnimator transAnimation = ObjectAnimator.ofFloat(btnOpc1, "translationX", 0, 1000);
            transAnimation.setDuration(400).start();
            ObjectAnimator transAnimationn = ObjectAnimator.ofFloat(btnOpc2, "translationX", 0, 1000);
            transAnimationn.setDuration(500).start();
            ObjectAnimator transAnimationnn = ObjectAnimator.ofFloat(btnOpc3, "translationX", 0, 1000);
            transAnimationnn.setDuration(600).start();
            ObjectAnimator transAnimationnnn = ObjectAnimator.ofFloat(btnOpc4, "translationX", 0, 1000);
            transAnimationnnn.setDuration(700).start();
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(lycamcon, "translationY", -1000, 0);
            transAnimatio1.setDuration(600).start();
            ivOpciones.animate().rotation(ivOpciones.getRotation() - 90).setDuration(200);
            passwordact.setText("");
            passwordnew.setText("");

        }

    }

    /**
     * Salir on click.
     *
     * @param v the v
     */
    public void salirOnClick(View v){

        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        dialogo1.setTitle(R.string.ImportantSp);
        dialogo1.setMessage(R.string.WantSkipSp);
        dialogo1.setCancelable(true);
        dialogo1.setPositiveButton(R.string.ConfirmSp, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                Intent empezar = new Intent(getApplicationContext(), LoginActivity.class);
                Clicker.tarea2.seguir=false;
                startActivity(empezar);
                finish();
            }
        });
        dialogo1.setNegativeButton(R.string.CancelSp, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {}
        });
        dialogo1.show();
    }

    public void changeSaveOnClick(View v){
        if(guardadoManual){
            guardadoManual=false;
            tarea2.guardado = true;
            hadler.postDelayed(runneable5,1000);
            txtAviso.setText(R.string.AutoSaveSp);
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(btnOpc4, "translationY", 0, 1000);
            transAnimatio1.setDuration(400).start();
        }
        else{
            guardadoManual=true;
            tarea2.guardado = false;
            hadler.postDelayed(runneable5,1000);
            txtAviso.setText(R.string.ManualSaveSp);
            ObjectAnimator transAnimatio1 = ObjectAnimator.ofFloat(btnOpc4, "translationY", 1000, 0);
            transAnimatio1.setDuration(400).start();

        }
        v.setEnabled(false);
    }

    public void save(View v){
        bd.setValue(LoginActivity.user);
        ParraDate date = new ParraDate();
        if(date.getYear()!=LoginActivity.user.getDate().getYear() || date.getDay()!=LoginActivity.user.getDate().getDay() || date.getHour()!=LoginActivity.user.getDate().getHour() || date.getMinute()!=LoginActivity.user.getDate().getMinute()){
            bd.child("date").setValue(date);
            LoginActivity.user.getDate().setYear(date.getYear());
            LoginActivity.user.getDate().setDay(date.getDay());
            LoginActivity.user.getDate().setHour(date.getHour());
            LoginActivity.user.getDate().setMinute(date.getMinute());
        }
        Toast t = Toast.makeText(getApplicationContext(), R.string.SavedSp, Toast.LENGTH_SHORT);
        t.setGravity(Gravity.BOTTOM,0,50);
        t.show();
    }

    //endregion

    //region ON CLICKS MEJORAS

    /**
     * Damage on click.
     *
     * @param v the v
     */
    @SuppressLint("SetTextI18n")
    public void damageOnClick(View v){
        if(LoginActivity.user.getScore()>=precioDamage && LoginActivity.user.getDamage() < vidaChest) {
            LoginActivity.user.setScore(LoginActivity.user.getScore() - precioDamage);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            LoginActivity.user.setDamage(LoginActivity.user.getDamage() + 1);
            txtDAct.setText("Act: " + LoginActivity.user.getDamage());
            precioDamage = CalculoPrecioDamage();
            btnMDamage.setText(R.string.CostSp +": "+precioDamage);

        }
    }

    /**
     * Speed on click.
     *
     * @param v the v
     */
    @SuppressLint("SetTextI18n")
    public void speedOnClick(View v){
        if(LoginActivity.user.getScore()>=precioSpeed && LoginActivity.user.getSpeed()>500) {
            LoginActivity.user.setScore(LoginActivity.user.getScore() - precioSpeed);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            LoginActivity.user.setSpeed(LoginActivity.user.getSpeed() - 10);
            txtSAct.setText("Act: " + LoginActivity.user.getSpeed());
            precioSpeed = CalculoPrecioSpeed();
            btnMSpeed.setText(R.string.CostSp +": "+precioSpeed);
        }
    }

    /**
     * Capacity on click.
     *
     * @param v the v
     */
    @SuppressLint("SetTextI18n")
    public void capacityOnClick(View v){
        if(LoginActivity.user.getScore()>=precioCapacity) {
            AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
            dialogo1.setTitle(R.string.DialogCapacity1Sp);
            dialogo1.setMessage(R.string.DialogCapacity2Sp + " " + LoginActivity.user.getCapacity()/20 + " " + R.string.DialogCapacity3Sp + " " + LoginActivity.user.getCapacity()/100 + ".");
            dialogo1.setCancelable(false);
            dialogo1.setPositiveButton(R.string.ConfirmSp, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    LoginActivity.user.setCapacity(LoginActivity.user.getCapacity() + (LoginActivity.user.getCapacity()/2));
                    txtCAct.setText("Act: " + LoginActivity.user.getCapacity());
                    LoginActivity.user.setScore(LoginActivity.user.getScore()-precioCapacity);
                    txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
                    precioCapacity = CalculoPrecioCapacity();
                    btnMCapacity.setText(R.string.CostSp +": "+precioCapacity);
                    vidaChest = Math.round(LoginActivity.user.getCapacity()/10);
                    oro = (vidaChest / 5) + 1;
                    txtMCapacitySuma.setText("+ " + LoginActivity.user.getCapacity()/2);
                }
            });
            dialogo1.setNegativeButton(R.string.CancelSp, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {

                }
            });
            dialogo1.show();
        }
    }

    /**
     * Clickdamage on click.
     *
     * @param v the v
     */
    @SuppressLint("SetTextI18n")
    public void ClickdamageOnClick(View v){
        if(LoginActivity.user.getScore()>=precioClickDamage && LoginActivity.user.getClickDamage()<vidaChest) {
            LoginActivity.user.setClickDamage(LoginActivity.user.getClickDamage() + 1);
            txtCDAct.setText("Act: " + LoginActivity.user.getClickDamage());
            LoginActivity.user.setScore(LoginActivity.user.getScore()-precioClickDamage);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            precioClickDamage = CalculoPrecioClickDamage();
            btnMClickDamage.setText(R.string.CostSp +": "+precioClickDamage);
        }
    }

    /**
     * GoldInactive on click.
     *
     * @param v the v
     */
    @SuppressLint("SetTextI18n")
    public void GoldInactiveOnClick(View v){
        if(LoginActivity.user.getScore()>=precioGoldInactive) {
            LoginActivity.user.setDpsInactive(LoginActivity.user.getDpsInactive() + 1);
            txtGIAct.setText("Act: " + LoginActivity.user.getDpsInactive());
            LoginActivity.user.setScore(LoginActivity.user.getScore()-precioGoldInactive);
            txtScore.setText(LoginActivity.user.getScore()+" / "+LoginActivity.user.getCapacity());
            precioGoldInactive= CalculoPrecioGoldInactive();
            btnMGoldInactive.setText(R.string.CostSp +": "+precioGoldInactive);
        }
    }

    //endregion

    //region CONTROL SALIDA DE LA APP
    private static final int INTERVALO = 2000; //2 segundos para salir
    private long tiempoPrimerClick;

    @Override
    public void onBackPressed(){
        if(opcionesAtivo || timeActivo || flechaActivo || copaActivo || camconActivo) {
            onClicks();
            opcionesAtivo = false;
            timeActivo = false;
            flechaActivo = false;
            copaActivo = false;
        }
        else{
            if (tiempoPrimerClick + INTERVALO > System.currentTimeMillis()) {
                super.onBackPressed();
                finish();
                tarea2.seguir = false;
                return;
            } else {
                Toast.makeText(this, R.string.OneMoreSkipSp, Toast.LENGTH_SHORT).show();

            }
            tiempoPrimerClick = System.currentTimeMillis();
        }
    }
    //endregion
}
