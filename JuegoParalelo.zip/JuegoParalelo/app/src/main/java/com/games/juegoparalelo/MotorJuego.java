package com.games.juegoparalelo;

import android.content.Context;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;


public class MotorJuego extends SurfaceView implements Runnable{
    public TextView txtScore;
    private Thread hiloJuego = null;

    // Nuestro SurfaceHolder para bloquear la superficie antes de que dibujemos nuestros gráficos
    private SurfaceHolder ourHolder;


    public MotorJuego(Context context, int x, int y){
        super(context);
        System.out.println("constructor MotorJuego");
        // Inicializa los objetos de ourHolder y paint
        ourHolder = getHolder();

        txtScore= (TextView) findViewById(R.id.txtScore);

        hiloJuego = new Thread(this);
        hiloJuego.start();
    }



    @Override
    public void run() {
        System.out.println("Se llama a run desde el hiloJuego");
        System.out.println(MainActivity.score);
        while(MainActivity.score!=-1){
            MainActivity.score=MainActivity.score+MainActivity.dps;
            txtScore.setText(MainActivity.score+"");
            try {
                hiloJuego.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("esto es imposible");
    }
}
